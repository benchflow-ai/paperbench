import gymnasium as gym
import numpy as np
import torch
import torch.optim as optim
import os
import random
import time # For timing critical state generation

from stable_baselines3 import PPO, SAC # Import necessary algos
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import DummyVecEnv, VecEnv, VecEnvWrapper
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.utils import safe_mean
from stable_baselines3.common.buffers import RolloutBuffer # Might need for RND training data
from stable_baselines3.common.policies import ActorCriticPolicy # Needed for dummy MaskNetworkPolicy

# Import components from other files
try:
    from state_mask import MaskNetworkPolicy # Need policy class to load mask net
    from rnd import RNDNetworks, RNDObservationNormalizer, RNDRewardNormalizer
except ImportError as e:
    print(f"WARNING: Could not import state_mask or rnd: {e}. Using dummy classes.")
    # Define dummy classes if import fails, to allow file creation
    class RNDNetworks(torch.nn.Module):
        def __init__(self, *args, **kwargs): super().__init__()
        def forward(self, x): return x, x # Dummy forward
        def compute_loss(self, x): return torch.tensor(0.0) # Dummy loss
        def parameters(self): yield torch.nn.Parameter(torch.tensor(1.0))
        def to(self, device): return self # Dummy device move
    class RNDObservationNormalizer(torch.nn.Module):
        def __init__(self, *args, **kwargs): super().__init__()
        def forward(self, x, update_rms=True): return x # Dummy forward
        def to(self, device): return self
        def train(self): pass
        def eval(self): pass
    class RNDRewardNormalizer:
        def __init__(self, *args, **kwargs): pass
        def __call__(self, x): return x # Dummy call
        def reset(self, dones): pass
    # Need MaskNetworkPolicy structure for loading
    class MaskNetworkPolicy(ActorCriticPolicy):
         def __init__(self, observation_space, action_space, lr_schedule, *args, **kwargs):
             # Provide minimal args to parent constructor if needed
             # Action space for mask is Discrete(2)
             mask_action_space = gym.spaces.Discrete(2)
             super().__init__(observation_space, mask_action_space, lr_schedule, *args, **kwargs)
         def predict_mask_prob(self, *args, **kwargs): return np.zeros(1) # Dummy predict
         def set_training_mode(self, mode): pass


class RNDRewardWrapper(VecEnvWrapper):
    # Calculates RND intrinsic rewards and adds them to the extrinsic rewards.
    # Handles observation normalization for RND input.
    def __init__(self, venv: VecEnv, rnd_nets: RNDNetworks, obs_normalizer: RNDObservationNormalizer,
                 reward_normalizer: RNDRewardNormalizer, lambda_intrinsic: float, update_obs_norm: bool = True):
        super().__init__(venv)
        self.rnd_nets = rnd_nets
        self.obs_normalizer = obs_normalizer
        self.reward_normalizer = reward_normalizer
        self.lambda_intrinsic = lambda_intrinsic
        self.update_obs_norm = update_obs_norm
        self._last_intrinsic_reward = np.zeros(self.num_envs)

    def reset(self):
        return self.venv.reset()

    def step_wait(self):
        obs, rewards, dones, infos = self.venv.step_wait()
        next_obs_tensor = torch.as_tensor(obs, dtype=torch.float32)
        # Assume rnd_nets and obs_normalizer are already on the correct device
        try:
             device = next(self.rnd_nets.parameters()).device
        except StopIteration:
             device = torch.device("cpu") # Fallback if dummy network has no params
        next_obs_tensor = next_obs_tensor.to(device)

        # Normalize observations
        normalized_next_obs = self.obs_normalizer(next_obs_tensor, update_rms=self.update_obs_norm)

        # Calculate RND intrinsic reward
        with torch.no_grad():
            rnd_loss_per_sample = self.rnd_nets.compute_loss(normalized_next_obs)
        intrinsic_rewards = rnd_loss_per_sample.cpu().numpy()

        # Normalize intrinsic rewards
        normalized_intrinsic_rewards = self.reward_normalizer(intrinsic_rewards)

        self._last_intrinsic_reward = normalized_intrinsic_rewards
        for i in range(self.num_envs):
            infos[i]["intrinsic_reward"] = normalized_intrinsic_rewards[i]
            infos[i]["original_reward"] = rewards[i]

        combined_rewards = rewards + self.lambda_intrinsic * normalized_intrinsic_rewards
        self.reward_normalizer.reset(dones)

        return obs, combined_rewards, dones, infos

    @property
    def last_intrinsic_reward(self):
        return self._last_intrinsic_reward


class CriticalStateResetWrapper(VecEnvWrapper):
    # Handles the probabilistic reset to critical states.
    # Requires DummyVecEnv for state setting.
    def __init__(self, venv: VecEnv, p_critical: float):
        if not isinstance(venv, DummyVecEnv):
             print("Warning: CriticalStateResetWrapper works best with DummyVecEnv for state saving/loading.")
        super().__init__(venv)
        self.p_critical = p_critical
        self.critical_states = [None] * self.num_envs
        self.successful_resets = 0
        self.attempted_resets = 0

    def set_critical_states(self, critical_states_list: list):
        # Update the critical states from an external source
        if len(critical_states_list) == self.num_envs:
             self.critical_states = critical_states_list
        else:
             print(f"Warning: Mismatch in critical states ({len(critical_states_list)}) vs num_envs ({self.num_envs})")

    def reset(self):
        # Reset requires handling individual envs if resetting to critical state
        obs_list = []
        for i in range(self.num_envs):
            obs_list.append(self._reset_env(i))
        return np.stack(obs_list)

    def reset_env(self, env_idx: int):
        # Resets a single environment, potentially to a critical state
        return self._reset_env(env_idx)

    def _reset_env(self, env_idx: int):
        # Internal logic to reset a single environment
        if random.random() < self.p_critical and self.critical_states[env_idx] is not None:
            self.attempted_resets += 1
            state_to_load = self.critical_states[env_idx]
            try:
                # Assumes state is (qpos, qvel) for MuJoCo
                if hasattr(self.venv, 'env_method'):
                    qpos, qvel = state_to_load
                    # Call set_state on the specific underlying environment
                    self.venv.env_method("set_state", qpos, qvel, indices=[env_idx])
                    # Get observation AFTER setting state. Using _get_obs directly.
                    obs = self.venv.env_method("_get_obs", indices=[env_idx])[0]
                    self.successful_resets += 1
                    return obs
                else:
                    print(f"Env {env_idx}: Cannot set state (no env_method). Default reset.")
                    return self.venv.env_method("reset", indices=[env_idx])[0]

            except Exception as e:
                print(f"Env {env_idx}: Failed set_state ({e}). Default reset.")
                return self.venv.env_method("reset", indices=[env_idx])[0]
        else:
            # Default reset for this environment
            return self.venv.env_method("reset", indices=[env_idx])[0]


class RICECallback(BaseCallback):
    # Callback for RICE:
    # 1. Trains the RND predictor network.
    # 2. Periodically generates new critical states.
    def __init__(self, rnd_nets: RNDNetworks, obs_normalizer: RNDObservationNormalizer,
                 rnd_optimizer: optim.Optimizer, rollout_buffer: RolloutBuffer,
                 target_policy, mask_policy,
                 reset_wrapper: CriticalStateResetWrapper,
                 critical_state_update_freq: int = 10000,
                 rnd_train_freq: int = 1,
                 rnd_grad_steps: int = 1,
                 rnd_batch_size: int = 64,
                 max_traj_len: int = 1000, # Max steps for critical state trajectory
                 verbose: int = 0):
        super().__init__(verbose)
        self.rnd_nets = rnd_nets
        self.obs_normalizer = obs_normalizer
        self.rnd_optimizer = rnd_optimizer
        self.rollout_buffer = rollout_buffer # Reference to PPO's buffer
        self.target_policy = target_policy
        self.mask_policy = mask_policy
        self.reset_wrapper = reset_wrapper
        self.critical_state_update_freq = critical_state_update_freq
        self.rnd_train_freq = rnd_train_freq
        self.rnd_grad_steps = rnd_grad_steps
        self.rnd_batch_size = rnd_batch_size
        self.max_traj_len = max_traj_len
        self._last_critical_state_update = 0
        self._rollout_count = 0
        self._eval_env = None # For critical state generation
        self.env_id = None

    def _on_training_start(self) -> None:
        self.rnd_nets.to(self.device)
        self.obs_normalizer.to(self.device)
        try:
            self.env_id = self.training_env.envs[0].spec.id
            self._eval_env = gym.make(self.env_id)
            print(f"RICECallback: Created eval_env ({self.env_id})")
        except Exception as e:
            print(f"RICECallback Warning: Failed to create eval_env: {e}")
        # Update critical states at the very beginning
        if self.env_id:
             self._update_critical_states()
        else:
            print("RICECallback: Skipping initial critical state update as eval_env failed.")

    def _on_rollout_start(self) -> None:
        if self.num_timesteps >= self._last_critical_state_update + self.critical_state_update_freq:
             self._update_critical_states()
             self._last_critical_state_update = self.num_timesteps

    def _on_rollout_end(self) -> None:
        self._rollout_count += 1
        if self._rollout_count % self.rnd_train_freq == 0:
             self._train_rnd_predictor()

    def _train_rnd_predictor(self) -> None:
        # Train the RND predictor network
        if not self.rollout_buffer.filled:
             return

        total_loss = 0
        num_samples_processed = 0
        self.rnd_nets.train()
        self.obs_normalizer.train()

        # Fetch data from the buffer
        # We need next_observations (s_{t+1}) corresponding to observations (s_t)
        # SB3 PPO buffer stores `observations`. Let's try to get `next_observations`
        # This might require adjustments based on SB3 version or custom buffer
        try:
            # Access buffer fields directly (might be unstable across SB3 versions)
            # Size is (buffer_size, n_envs, obs_dim)
            observations = self.rollout_buffer.observations
            # Need to reconstruct next_observations carefully
            # obs[t+1] is the next_obs for obs[t], accounting for dones
            next_observations = np.roll(observations, -1, axis=0) # Shift time axis
            # The last next_observation for each env is missing in this simple shift.
            # And episode boundaries are ignored. THIS IS STILL FLAWED.

            # Flatten buffer dimensions: (buffer_size * n_envs, obs_dim)
            num_samples = self.rollout_buffer.buffer_size * self.rollout_buffer.n_envs
            next_observations_flat = next_observations.reshape(num_samples, -1)

        except AttributeError:
             print("RICECallback Error: Could not access rollout buffer data as expected. Cannot train RND.")
             return

        for _ in range(self.rnd_grad_steps):
            indices = np.random.permutation(num_samples)
            for start_idx in range(0, num_samples, self.rnd_batch_size):
                batch_indices = indices[start_idx : start_idx + self.rnd_batch_size]
                if len(batch_indices) == 0: continue

                # Get the corresponding next observations for the batch
                batch_next_obs = next_observations_flat[batch_indices]

                # Handle Dict observation space if necessary (basic placeholder)
                if isinstance(batch_next_obs, dict):
                     if 'observation' in batch_next_obs:
                         batch_next_obs = batch_next_obs['observation']
                     else:
                         print("RICECallback Warning: Cannot extract 'observation' from Dict obs for RND.")
                         continue

                next_obs_tensor = torch.as_tensor(batch_next_obs, dtype=torch.float32, device=self.device)

                # Normalize observations (and update RMS)
                normalized_next_obs = self.obs_normalizer(next_obs_tensor, update_rms=True)

                # Calculate RND loss
                loss = self.rnd_nets.compute_loss(normalized_next_obs).mean()

                # Optimization
                self.rnd_optimizer.zero_grad()
                loss.backward()
                # Gradient clipping might be useful here
                # torch.nn.utils.clip_grad_norm_(self.rnd_nets.predictor_network.parameters(), max_norm=0.5)
                self.rnd_optimizer.step()
                total_loss += loss.item()
                num_samples_processed += len(batch_indices)

        # Switch back to eval mode for normalizers/nets if needed outside training step
        self.obs_normalizer.eval()
        self.rnd_nets.eval()

        if self.verbose > 1 and num_samples_processed > 0:
            avg_loss = total_loss / (num_samples_processed / self.rnd_batch_size)
            print(f"RND Predictor Training: Samples={num_samples_processed}, Avg Loss={avg_loss:.6f}")


    def _update_critical_states(self) -> None:
        # Generate new critical states using target policy and mask network
        if self._eval_env is None:
            print("RICECallback: Cannot update critical states, eval_env not available.")
            return

        if self.verbose > 0:
            print(f"RICECallback: Updating critical states (step {self.num_timesteps})...", flush=True)
        start_time = time.time()

        new_critical_states = [None] * self.reset_wrapper.num_envs
        # Check once if eval_env supports MuJoCo state setting
        can_get_mujoco_state = hasattr(self._eval_env, 'get_state') and hasattr(self._eval_env, 'set_state')

        for env_idx in range(self.reset_wrapper.num_envs):
            try:
                obs, _ = self._eval_env.reset()
                done = False
                trajectory_states = []
                trajectory_qpos_qvel = [] if can_get_mujoco_state else None
                current_step = 0

                with torch.no_grad():
                    self.target_policy.set_training_mode(False)
                    self.mask_policy.set_training_mode(False)

                    while not done and current_step < self.max_traj_len:
                        trajectory_states.append(obs.copy())
                        if can_get_mujoco_state:
                             qpos, qvel = self._eval_env.get_state()
                             trajectory_qpos_qvel.append((qpos.copy(), qvel.copy()))

                        action, _ = self.target_policy.predict(obs, deterministic=False)
                        obs, reward, terminated, truncated, info = self._eval_env.step(action)
                        done = terminated or truncated
                        current_step += 1

                if trajectory_states:
                     states_np = np.array(trajectory_states)
                     # Ensure mask_policy is on CPU if needed for prediction
                     self.mask_policy.to('cpu')
                     mask_probs_1 = self.mask_policy.predict_mask_prob(states_np) # Prob(a^m=1)
                     self.mask_policy.to(self.device) # Move back if needed

                     # Importance score = prob(a^m=0) = 1 - prob(a^m=1)
                     importance_scores = 1.0 - mask_probs_1
                     critical_step_index = np.argmax(importance_scores)

                     if can_get_mujoco_state:
                          critical_state_data = trajectory_qpos_qvel[critical_step_index]
                          new_critical_states[env_idx] = critical_state_data
                     # else: Cannot store state for reset

            except Exception as e:
                print(f"RICECallback: Error generating critical state for env {env_idx}: {e}")
                new_critical_states[env_idx] = None

        self.reset_wrapper.set_critical_states(new_critical_states)

        end_time = time.time()
        if self.verbose > 0:
             valid_states_count = sum(1 for s in new_critical_states if s is not None)
             print(f"RICECallback: Update finished ({end_time - start_time:.2f}s). Usable states: {valid_states_count}/{self.reset_wrapper.num_envs}.", flush=True)


    def _on_step(self) -> bool:
        # Log intrinsic reward and reset stats
        if self.logger is not None:
             try:
                 # Find the RNDRewardWrapper
                 rnd_wrapper = self.training_env
                 while isinstance(rnd_wrapper, VecEnvWrapper) and not isinstance(rnd_wrapper, RNDRewardWrapper):
                     rnd_wrapper = rnd_wrapper.venv
                 if isinstance(rnd_wrapper, RNDRewardWrapper):
                      last_intrinsic = rnd_wrapper.last_intrinsic_reward
                      self.logger.record("rollout/intrinsic_reward_mean", safe_mean(last_intrinsic))

                 # Find the CriticalStateResetWrapper
                 reset_wrapper = self.training_env
                 while isinstance(reset_wrapper, VecEnvWrapper) and not isinstance(reset_wrapper, CriticalStateResetWrapper):
                     reset_wrapper = reset_wrapper.venv
                 if isinstance(reset_wrapper, CriticalStateResetWrapper) and reset_wrapper.attempted_resets > 0:
                      reset_success_rate = reset_wrapper.successful_resets / reset_wrapper.attempted_resets
                      self.logger.record("rollout/critical_reset_rate", reset_success_rate)
             except Exception as e:
                 # Avoid crashing training if logging fails
                 print(f"RICECallback: Error logging stats: {e}")
        return True

# --- Main Training Function ---
def train_rice(
    env_id: str,
    pretrained_policy_path: str,
    pretrained_policy_algo: str,
    mask_network_path: str,
    save_path: str,
    p_critical: float,
    lambda_intrinsic: float,
    total_timesteps: int,
    rnd_output_dim: int = 128,
    rnd_net_arch = None,
    rnd_lr: float = 1e-4,
    ppo_kwargs: dict = None,
    n_envs: int = 4,
    seed: int = 42,
    critical_state_update_freq: int = 10000,
    max_traj_len: int = 1000,
    log_folder: str = "/tmp/rice_logs/"
):
    # Trains an agent using the RICE algorithm.
    print("--- Starting RICE Training Setup ---")
    print(f" Env: {env_id}, Pretrained: {pretrained_policy_path} ({pretrained_policy_algo}), MaskNet: {mask_network_path}")
    print(f" p={p_critical}, lambda={lambda_intrinsic}, Timesteps={total_timesteps}")
    print(f" RND lr={rnd_lr}, RND arch={rnd_net_arch or '[64, 64]'}, RND out_dim={rnd_output_dim}")
    print(f" CritState freq={critical_state_update_freq}, MaxTraj={max_traj_len}")

    # --- Load Policies ---
    print("Loading policies...", flush=True)
    try:
        algo_map = {'PPO': PPO, 'SAC': SAC}
        if pretrained_policy_algo not in algo_map: raise ValueError("Unsupported algo")
        PretrainedAlgoClass = algo_map[pretrained_policy_algo]
        device_load = 'cpu' # Load policies to CPU initially
        pretrained_model = PretrainedAlgoClass.load(pretrained_policy_path, device=device_load)
        target_policy = pretrained_model.policy # Static copy
        target_policy.set_training_mode(False)

        # Load mask model, specifying custom policy class
        mask_model = PPO.load(mask_network_path, device=device_load, custom_objects={'policy_class': MaskNetworkPolicy})
        mask_policy = mask_model.policy
        mask_policy.set_training_mode(False)
        print("Policies loaded.", flush=True)
    except Exception as e:
        print(f"Error loading policies: {e}")
        import traceback; traceback.print_exc()
        return

    # --- Setup Env --- #
    print(f"Creating envs (n={n_envs})...", flush=True)
    try:
        vec_env = make_vec_env(env_id, n_envs=n_envs, seed=seed, vec_env_cls=DummyVecEnv)
    except Exception as e:
        print(f"Error creating env {env_id}: {e}")
        return

    # --- Setup RND --- #
    print("Setting up RND...", flush=True)
    obs_shape = vec_env.observation_space.shape
    if not obs_shape:
         print("Warning: Assuming 1D obs_dim from Discrete space.")
         obs_dim = vec_env.observation_space.n
    else:
        obs_dim = np.prod(obs_shape)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    obs_normalizer = RNDObservationNormalizer(input_shape=obs_dim).to(device)
    # Use the gamma from PPO args for reward normalization
    ppo_gamma = ppo_kwargs.get('gamma', 0.99) if ppo_kwargs else 0.99
    reward_normalizer = RNDRewardNormalizer(num_envs=n_envs, gamma=ppo_gamma)
    rnd_nets = RNDNetworks(input_dim=obs_dim, output_dim=rnd_output_dim, net_arch=rnd_net_arch).to(device)
    # Filter predictor parameters for optimizer
    predictor_params = list(rnd_nets.predictor_network.parameters())
    if not predictor_params:
         print("Warning: RND Predictor network has no parameters?")
         rnd_optimizer = None
    else:
        rnd_optimizer = optim.Adam(predictor_params, lr=rnd_lr)

    # --- Wrap Env --- #
    print("Wrapping env...", flush=True)
    wrapped_env = CriticalStateResetWrapper(vec_env, p_critical=p_critical)
    wrapped_env = RNDRewardWrapper(wrapped_env, rnd_nets, obs_normalizer, reward_normalizer, lambda_intrinsic, update_obs_norm=True)

    # --- Setup PPO Model --- #
    print("Initializing PPO for refinement...", flush=True)
    default_ppo_params = {
        "verbose": 1, "seed": seed, "n_steps": 2048, "batch_size": 64,
        "n_epochs": 10, "gamma": 0.99, "gae_lambda": 0.95, "clip_range": 0.2,
        "ent_coef": 0.0, "vf_coef": 0.5, "max_grad_norm": 0.5,
        "learning_rate": 3e-4,
        "device": device
    }
    if ppo_kwargs:
        default_ppo_params.update(ppo_kwargs)

    # Create new PPO model with weights from pretrained policy
    rice_model = PPO(type(pretrained_model.policy), wrapped_env, tensorboard_log=log_folder, **default_ppo_params)
    rice_model.policy.load_state_dict(pretrained_model.policy.state_dict())
    print("PPO initialized with pretrained weights.", flush=True)

    # --- Setup Callback --- #
    if rnd_optimizer is not None:
        print("Setting up RICE callback...", flush=True)
        # Find the correct reset_wrapper reference (it's wrapped_env.venv)
        reset_wrapper_ref = wrapped_env.venv
        if not isinstance(reset_wrapper_ref, CriticalStateResetWrapper):
             print("ERROR: Could not find CriticalStateResetWrapper in wrapped envs!")
             return

        rice_callback = RICECallback(
            rnd_nets=rnd_nets,
            obs_normalizer=obs_normalizer,
            rnd_optimizer=rnd_optimizer,
            rollout_buffer=rice_model.rollout_buffer,
            target_policy=target_policy,
            mask_policy=mask_policy,
            reset_wrapper=reset_wrapper_ref,
            critical_state_update_freq=critical_state_update_freq,
            max_traj_len=max_traj_len,
            verbose=1
        )
    else:
        print("Warning: RND optimizer not created, cannot create RICE callback.")
        rice_callback = None

    # --- Train (Commented out) --- #
    print(f"--- RICE Training Setup Complete --- ")
    print(f"--- Execute rice_model.learn(...) to train (skipped due to constraints) ---")
    # if rice_callback is not None:
    #     try:
    #         obs_normalizer.train()
    #         rnd_nets.train()
    #         rice_model.learn(
    #             total_timesteps=total_timesteps,
    #             callback=rice_callback,
    #             log_interval=max(1, total_timesteps // (default_ppo_params['n_steps'] * n_envs * 10)),
    #             tb_log_name="RICE_run",
    #             reset_num_timesteps=False
    #         )
    #         print(f"Saving refined RICE model to: {save_path}")
    #         os.makedirs(os.path.dirname(save_path), exist_ok=True)
    #         rice_model.save(save_path)
    #         norm_save_path = os.path.join(os.path.dirname(save_path), "rnd_obs_norm.pt")
    #         torch.save(obs_normalizer.state_dict(), norm_save_path)
    #         print(f"Saved RND observation normalizer to: {norm_save_path}")
    #     except Exception as e:
    #         print(f"Error during RICE training: {e}")
    #         import traceback; traceback.print_exc()
    #     finally:
    #         wrapped_env.close()
    # else:
    #      print("Skipping training as RICE callback could not be created.")

if __name__ == '__main__':
    print("--- RICE Example --- ")
    DUMMY_AGENT_PATH = "/tmp/dummy_ppo_hopper.zip"
    DUMMY_MASK_PATH = "/home/submission/results/hopper_mask_net.zip"

    print(f"Checking for dummy agent: {DUMMY_AGENT_PATH}")
    print(f"Checking for dummy mask net: {DUMMY_MASK_PATH}")
    print("Skipping RICE example execution as prerequisite files likely missing.")

    # Guard to prevent execution attempt
    run_example = False
    if run_example:
        # Ensure files exist before trying to run
        if not os.path.exists(DUMMY_AGENT_PATH) or not os.path.exists(DUMMY_MASK_PATH):
             print("Error: Prerequisite files not found.")
        else:
            print("Dummy agent and mask found, proceeding with RICE setup example.")
            p_hopper = 0.25
            lambda_hopper = 0.001
            rice_timesteps = 50000

            train_rice(
                env_id="Hopper-v3",
                pretrained_policy_path=DUMMY_AGENT_PATH,
                pretrained_policy_algo='PPO',
                mask_network_path=DUMMY_MASK_PATH,
                save_path="/home/submission/results/hopper_rice_refined.zip",
                p_critical=p_hopper,
                lambda_intrinsic=lambda_hopper,
                total_timesteps=rice_timesteps,
                n_envs=4,
                seed=42,
                ppo_kwargs={"n_steps": 1024, "learning_rate": 1e-4},
                critical_state_update_freq=5000
            )

