import os
import sys
import argparse
import gymnasium as gym
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import CheckpointCallback

# Ensure src is in path if running script directly
# This might fail if __file__ is not defined, handle potential NameError
try:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))
except NameError:
    # Fallback if run in an environment where __file__ is not set (like exec)
    sys.path.append('/home/submission/src') # Assume standard location

# Default hyperparameters (can be overridden)
DEFAULT_PPO_PARAMS = {
    "n_steps": 2048,
    "batch_size": 64,
    "n_epochs": 10,
    "gamma": 0.99,
    "gae_lambda": 0.95,
    "clip_range": 0.2,
    "ent_coef": 0.0,
    "vf_coef": 0.5,
    "max_grad_norm": 0.5,
    "learning_rate": 3e-4,
}

DEFAULT_SAC_PARAMS = {
    "buffer_size": 1_000_000,
    "batch_size": 256,
    "gamma": 0.99,
    "tau": 0.005,
    "train_freq": 1,
    "gradient_steps": 1,
    "learning_rate": 3e-4,
    "learning_starts": 10000,
    "ent_coef": 'auto',
}

def train_agent(env_id, algo, total_timesteps, save_dir, seed=42, n_envs=4, params=None):
    ''' Trains a PPO or SAC agent. ''' # Use single quotes for docstring
    print(f"--- Training Pretrained Agent ---")
    print(f" Env: {env_id}, Algo: {algo}, Timesteps: {total_timesteps}")
    print(f" Save Dir: {save_dir}, Seed: {seed}, N_Envs: {n_envs}")

    os.makedirs(save_dir, exist_ok=True)
    log_dir = os.path.join(save_dir, "logs/")
    model_path = os.path.join(save_dir, f"{env_id}_{algo.lower()}_pretrained.zip")

    # Create vectorized environment
    try:
        vec_env = make_vec_env(env_id, n_envs=n_envs, seed=seed)
    except Exception as e:
        print(f"Error creating environment {env_id}: {e}")
        return

    # Select algorithm and parameters
    if algo.upper() == 'PPO':
        AlgoClass = PPO
        default_params = DEFAULT_PPO_PARAMS.copy()
        policy = "MlpPolicy"
    elif algo.upper() == 'SAC':
        AlgoClass = SAC
        default_params = DEFAULT_SAC_PARAMS.copy()
        policy = "MlpPolicy"
    else:
        print(f"Error: Unsupported algorithm: {algo}")
        vec_env.close()
        return

    if params:
        default_params.update(params)

    # Setup model
    try:
        model = AlgoClass(policy, vec_env, verbose=1, seed=seed, tensorboard_log=log_dir, **default_params)
    except Exception as e:
        print(f"Error creating model {algo} for {env_id}: {e}")
        vec_env.close()
        return

    # Setup checkpoint callback
    # Calculate save_freq based on total steps across all envs
    save_freq_per_env = max(10000 // n_envs, total_timesteps // (n_envs * 10))
    checkpoint_callback = CheckpointCallback(
        save_freq=save_freq_per_env,
        save_path=save_dir,
        name_prefix=f"{env_id}_{algo.lower()}_ckpt",
        save_replay_buffer=True, # Important for SAC
        save_vecnormalize=True,
    )

    print(f"Starting training setup... (Execution Skipped)")
    # --- Training (Commented out due to resource constraints) ---
    # try:
    #     model.learn(
    #         total_timesteps=total_timesteps,
    #         callback=checkpoint_callback,
    #         tb_log_name=f"{env_id}_{algo.lower()}_pretrained"
    #     )
    #     print(f"Training finished. Saving final model to {model_path}")
    #     model.save(model_path)
    # except Exception as e:
    #     print(f"Error during training: {e}")
    # finally:
    #     vec_env.close()
    print(f"--- Training Setup Complete (Execution Skipped) ---")
    print(f"--- Final model would be saved to: {model_path} ---")
    # Close env even if training skipped
    vec_env.close()


if __name__ == "__main__":
    # Define default save directory relative to script location if possible
    try:
        # Assumes script is run from /home/submission
        script_dir = os.path.dirname(__file__) if '__file__' in locals() else '/home/submission/scripts'
    except NameError:
        script_dir = '/home/submission/scripts' # Fallback
    default_save_dir = os.path.abspath(os.path.join(script_dir, '..', 'models', 'pretrained'))

    parser = argparse.ArgumentParser()
    parser.add_argument("--env", help="Environment ID", type=str, default="Hopper-v3")
    parser.add_argument("--algo", help="RL Algorithm (PPO or SAC)", type=str, default="PPO")
    parser.add_argument("--timesteps", help="Total training timesteps", type=int, default=1_000_000)
    parser.add_argument("--save-dir", help="Directory to save models and logs", type=str, default=default_save_dir)
    parser.add_argument("--seed", help="Random seed", type=int, default=42)
    parser.add_argument("--n-envs", help="Number of parallel environments", type=int, default=4)
    # Parse known args to allow execution in environments that add extra args
    args, unknown = parser.parse_known_args()

    # Example Usage notes:
    # python scripts/train_pretrained.py --env Hopper-v3 --algo PPO --timesteps 1000000
    # python scripts/train_pretrained.py --env Hopper-v3 --algo SAC --timesteps 1000000

    train_agent(
        env_id=args.env,
        algo=args.algo,
        total_timesteps=args.timesteps,
        save_dir=args.save_dir,
        seed=args.seed,
        n_envs=args.n_envs
    )

