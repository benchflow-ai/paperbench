import gymnasium as gym
import numpy as np
import torch
from torch import nn
import os

from stable_baselines3 import PPO, SAC, TD3, DDPG
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.policies import ActorCriticPolicy
from stable_baselines3.common.torch_layers import BaseFeaturesExtractor, FlattenExtractor
from stable_baselines3.common.vec_env import DummyVecEnv, VecEnv, VecEnvWrapper, is_vecenv_wrapped
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.buffers import RolloutBuffer

class MaskNetworkPolicy(ActorCriticPolicy):
    '''
    A policy network for the mask agent. Outputs probability for binary action (0 or 1).
    Simplified for binary action space.
    '''
    def __init__(self, observation_space, action_space, lr_schedule, net_arch=None, activation_fn=nn.Tanh, **kwargs):
        # Force action space to be Discrete(2) for masking (0: keep, 1: blind)
        mask_action_space = gym.spaces.Discrete(2)

        # Use default MLP architecture if none provided
        if net_arch is None:
             # Small network for the mask
            net_arch = dict(pi=[64, 64], vf=[64, 64])

        super().__init__(
            observation_space,
            mask_action_space, # Use the discrete action space here
            lr_schedule,
            net_arch=net_arch,
            activation_fn=activation_fn,
            **kwargs
        )
        self.action_space = mask_action_space


    def forward(self, obs: torch.Tensor, deterministic: bool = False):
        '''
        Forward pass in actor and critic (value function)
        :param obs: Observation
        :param deterministic: Whether to sample or use the mode
        :return: action, value, log_prob
        '''
        latent_pi, latent_vf, latent_sde = self._get_latent(obs)
        values = self.value_net(latent_vf)
        distribution = self._get_action_dist_from_latent(latent_pi, latent_sde=latent_sde)
        actions = distribution.get_actions(deterministic=deterministic)
        log_prob = distribution.log_prob(actions)
        return actions, values, log_prob

    def predict_mask_action(self, obs: np.ndarray, deterministic: bool = False) -> np.ndarray:
        ''' Predict the mask action (0 or 1). '''
        action, _ = self.predict(obs, deterministic=deterministic)
        return action


    def predict_mask_prob(self, obs: np.ndarray) -> np.ndarray:
        ''' Predict the probability of taking action 1 (blinding). '''
        self.set_training_mode(False)
        obs_tensor, _ = self.obs_to_tensor(obs)

        with torch.no_grad():
            latent_pi, _, latent_sde = self._get_latent(obs_tensor)
            distribution = self._get_action_dist_from_latent(latent_pi, latent_sde=latent_sde)
            probs = distribution.distribution.probs.cpu().numpy()
            if probs.shape[-1] == 2:
                return probs[:, 1]
            else:
                 raise ValueError(f"Unexpected probability shape from MaskNetworkPolicy: {probs.shape}")


class MaskEnvWrapper(VecEnvWrapper):
    ''' Wraps a VecEnv to implement the masking logic for training the MaskNetwork. '''
    def __init__(self, venv: VecEnv, target_policy, alpha: float):
        super().__init__(venv)
        self.target_policy = target_policy
        self.target_policy.set_training_mode(False)
        self.alpha = alpha
        self._last_obs = None
        self._current_mask_actions = None

    def reset(self):
        self._last_obs = self.venv.reset()
        return self._last_obs

    def step_async(self, actions: np.ndarray) -> None:
        self._current_mask_actions = actions # Shape (n_envs,)
        if self._last_obs is None:
            self._last_obs = self.venv.reset()

        with torch.no_grad():
            self.target_policy.set_training_mode(False)
            target_actions, _ = self.target_policy.predict(self._last_obs, deterministic=False)

        random_actions = np.array([self.action_space.sample() for _ in range(self.num_envs)])

        if len(target_actions.shape) > 1:
            mask_actions_reshaped = self._current_mask_actions.reshape(-1, *([1] * (len(target_actions.shape) - 1)))
            final_actions = np.where(mask_actions_reshaped == 1, random_actions, target_actions)
        else:
            final_actions = np.where(self._current_mask_actions == 1, random_actions, target_actions)

        self.venv.step_async(final_actions)

    def step_wait(self):
        obs, rewards, dones, infos = self.venv.step_wait()
        modified_rewards = rewards + self.alpha * self._current_mask_actions

        next_obs = obs.copy()
        for i in range(self.num_envs):
            infos[i]["original_reward"] = rewards[i]
            infos[i]["mask_action"] = self._current_mask_actions[i]
            if dones[i]:
                if 'terminal_observation' in infos[i]:
                    terminal_obs = infos[i]['terminal_observation']
                    infos[i]['final_observation'] = terminal_obs
                    next_obs[i] = terminal_obs
                else:
                    infos[i]['final_observation'] = obs[i]

        self._last_obs = obs
        return next_obs, modified_rewards, dones, infos

# --- Helper function to train the mask network ---
def train_mask_network(
    env_id: str,
    target_policy_path: str,
    target_policy_algo: str,
    alpha: float,
    total_timesteps: int,
    save_path: str,
    policy_kwargs=None,
    ppo_kwargs=None,
    n_envs=4,
    seed=42
):
    ''' Trains the mask network (Algorithm 1) '''
    print(f"--- Starting Mask Network Training ---")
    print(f"Env: {env_id}, Target Policy: {target_policy_path} ({target_policy_algo})")
    print(f"Alpha: {alpha}, Timesteps: {total_timesteps}, Envs: {n_envs}, Seed: {seed}")
    print(f"Save path: {save_path}")

    print(f"Loading target policy...", flush=True)
    try:
        algo_map = {'PPO': PPO, 'SAC': SAC, 'TD3': TD3, 'DDPG': DDPG}
        if target_policy_algo not in algo_map:
            raise ValueError(f"Unsupported target_policy_algo: {target_policy_algo}")
        AlgoClass = algo_map[target_policy_algo]
        device_load = 'cpu' if torch.cuda.is_available() else 'auto'
        target_policy = AlgoClass.load(target_policy_path, device=device_load).policy
        target_policy.set_training_mode(False)
        print("Target policy loaded successfully.", flush=True)
    except Exception as e:
        print(f"Error loading target policy: {e}", flush=True)
        return None

    print(f"Creating {n_envs} parallel environments ({env_id})...", flush=True)
    try:
        vec_env = make_vec_env(env_id, n_envs=n_envs, seed=seed, vec_env_cls=DummyVecEnv)
    except Exception as e:
        print(f"Error creating environment {env_id}: {e}. Check installation (e.g., MuJoCo).", flush=True)
        return None

    wrapped_env = MaskEnvWrapper(vec_env, target_policy, alpha)

    default_ppo_kwargs = {
        "verbose": 0, # Reduce verbosity
        "seed": seed, "n_steps": 2048, "batch_size": 64,
        "n_epochs": 10, "gamma": 0.99, "gae_lambda": 0.95, "clip_range": 0.2,
        "ent_coef": 0.0, "vf_coef": 0.5, "max_grad_norm": 0.5,
        "learning_rate": 3e-4, "device": "auto"
    }
    if ppo_kwargs:
        default_ppo_kwargs.update(ppo_kwargs)

    if policy_kwargs is None:
        policy_kwargs = {} # Use default MaskNetworkPolicy arch

    print(f"Instantiating PPO model for mask network...", flush=True)
    mask_model = PPO(
        MaskNetworkPolicy,
        wrapped_env,
        policy_kwargs=policy_kwargs,
        **default_ppo_kwargs
    )

    print(f"Training mask network for {total_timesteps} timesteps...", flush=True)
    try:
        # Define a simple callback for progress reporting
        class SimpleProgressCallback(BaseCallback):
            def __init__(self, check_freq: int, total_timesteps: int, verbose=1):
                super().__init__(verbose)
                self.check_freq = check_freq
                self.total_timesteps = total_timesteps
            def _on_step(self) -> bool:
                if self.n_calls % self.check_freq == 0:
                    progress = self.n_calls / self.total_timesteps * 100
                    print(f"  Training progress: {progress:.1f}% ({self.n_calls}/{self.total_timesteps} steps)", flush=True)
                return True

        # Calculate check frequency for ~10 updates
        log_interval_steps = max(1024, default_ppo_kwargs['n_steps'] * n_envs)
        check_freq = max(1, total_timesteps // (log_interval_steps * 10)) * log_interval_steps

        callback = SimpleProgressCallback(check_freq=check_freq, total_timesteps=total_timesteps)
        mask_model.learn(total_timesteps=total_timesteps, callback=callback)

    except Exception as e:
        print(f"Error during mask network training: {e}", flush=True)
        wrapped_env.close()
        return None

    print(f"Saving trained mask network to: {save_path}", flush=True)
    try:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        mask_model.save(save_path)
        print("Mask network training complete.", flush=True)
    except Exception as e:
        print(f"Error saving mask model: {e}", flush=True)

    wrapped_env.close()
    print(f"--- Finished Mask Network Training ---")
    return mask_model

if __name__ == '__main__':
    # Example Usage: Train mask for Hopper-v3
    DUMMY_AGENT_PATH = "/tmp/dummy_ppo_hopper.zip"
    if not os.path.exists(DUMMY_AGENT_PATH):
        print(f"Creating dummy pre-trained agent for Hopper-v3 at {DUMMY_AGENT_PATH}...", flush=True)
        try:
            import gymnasium
            dummy_env = make_vec_env("Hopper-v3", n_envs=1)
            dummy_agent = PPO("MlpPolicy", dummy_env, verbose=0, n_steps=2048, batch_size=64, n_epochs=10, seed=42, device='auto')
            dummy_agent.learn(total_timesteps=10000)
            dummy_agent.save(DUMMY_AGENT_PATH)
            dummy_env.close()
            print("Dummy agent created and saved.", flush=True)
        except Exception as e:
             print(f"Failed to create dummy agent: {e}. Check environment setup.", flush=True)
             exit(1)
    else:
        print(f"Dummy pre-trained agent found at {DUMMY_AGENT_PATH}.", flush=True)

#     print("Starting mask network training example for Hopper-v3...", flush=True)
#     results_dir = "/home/submission/results"
#     mask_save_path = os.path.join(results_dir, "hopper_mask_net.zip")

#     alpha_hopper = 0.001
#     mask_timesteps = 20000 # Align with Table 4
#     n_envs_mask = 4

#     train_mask_network(
#         env_id="Hopper-v3",
#         target_policy_path=DUMMY_AGENT_PATH,
#         target_policy_algo='PPO',
#         alpha=alpha_hopper,
#         total_timesteps=mask_timesteps,
#         save_path=mask_save_path,
#         n_envs=n_envs_mask,
#         seed=42,
#         ppo_kwargs={"n_steps": 2048, "device": "auto"}
#     )
#     print("Mask network training example finished.", flush=True)
