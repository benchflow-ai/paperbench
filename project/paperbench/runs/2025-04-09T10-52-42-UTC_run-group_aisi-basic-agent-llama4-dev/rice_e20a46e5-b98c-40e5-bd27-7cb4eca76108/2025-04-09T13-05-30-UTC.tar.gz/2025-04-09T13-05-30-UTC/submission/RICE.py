class RICE:
    def __init__(self):
        pass
    def run_RICE(self):
        pass
