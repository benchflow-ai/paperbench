1. Install the required dependencies
