#!/bin/bash
python RICE.py
