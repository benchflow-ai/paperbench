import os
import sys
import unittest
import numpy as np
import gymnasium as gym
from stable_baselines3 import PPO

from rice.utils.fidelity import compute_fidelity_score, find_critical_segment

class TestFidelity(unittest.TestCase):
    def setUp(self):
        # Create a simple environment for testing
        self.env = gym.make('CartPole-v1')
        
        # Train a simple agent for testing
        self.agent = PPO('MlpPolicy', self.env, verbose=0, seed=0)
        self.agent.learn(total_timesteps=100)  # Just a few steps
    
    def test_find_critical_segment(self):
        # Create some states and importance scores
        states = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        importance_scores = [0.1, 0.2, 0.8, 0.9, 0.7, 0.3, 0.2, 0.1, 0.2, 0.3]
        
        # Find critical segment with window fraction 0.3 (window size 3)
        start_idx, end_idx = find_critical_segment(states, importance_scores, window_fraction=0.3)
        
        # The most important segment should be states [3, 4, 5] with scores [0.8, 0.9, 0.7]
        self.assertEqual(start_idx, 2)
        self.assertEqual(end_idx, 5)
        
        # Test with a smaller window
        start_idx, end_idx = find_critical_segment(states, importance_scores, window_fraction=0.2)
        
        # The most important segment should be states [3, 4] with scores [0.8, 0.9]
        self.assertEqual(start_idx, 2)
        self.assertEqual(end_idx, 4)
    
    def test_compute_fidelity_score(self):
        # Define a simple explanation method
        def random_explanation(states):
            # Return random importance scores
            return np.random.random(len(states))
        
        # Test computing fidelity score with a small number of trajectories
        fidelity_score = compute_fidelity_score(
            agent=self.agent,
            env=self.env,
            explanation_method=random_explanation,
            trajectory_length=10,
            window_fraction=0.3,
            n_trajectories=2
        )
        
        # Check that fidelity score is a scalar
        self.assertIsInstance(fidelity_score, float)
        
        # Test with a deterministic explanation
        def deterministic_explanation(states):
            # Return importance scores that increase linearly
            return np.linspace(0, 1, len(states))
        
        fidelity_score = compute_fidelity_score(
            agent=self.agent,
            env=self.env,
            explanation_method=deterministic_explanation,
            trajectory_length=10,
            window_fraction=0.3,
            n_trajectories=2
        )
        
        # Check that fidelity score is a scalar
        self.assertIsInstance(fidelity_score, float)

if __name__ == '__main__':
    unittest.main()
