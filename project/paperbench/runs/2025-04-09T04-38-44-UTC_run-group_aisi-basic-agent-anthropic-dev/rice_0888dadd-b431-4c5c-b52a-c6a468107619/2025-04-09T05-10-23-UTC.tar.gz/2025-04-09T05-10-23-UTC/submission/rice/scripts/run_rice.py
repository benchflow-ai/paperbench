#!/usr/bin/env python3

import os
import argparse
import time
import torch
from stable_baselines3 import PPO

from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv
from rice.models.state_mask import ImprovedStateMask
from rice.models.rice import RICE
from rice.configs.env_configs import get_config

def parse_args():
    parser = argparse.ArgumentParser(description='Run the full RICE workflow')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to run on')
    
    parser.add_argument('--output-dir', type=str, default='./results',
                        help='Directory to save results')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    parser.add_argument('--skip-training', action='store_true',
                        help='Skip the training phase and use pre-trained models')
    
    parser.add_argument('--agent-path', type=str, default=None,
                        help='Path to pre-trained agent (required if --skip-training)')
    
    parser.add_argument('--mask-path', type=str, default=None,
                        help='Path to trained mask network (required if --skip-training)')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def evaluate_agent(agent, env, n_episodes=10):
    """Evaluate an agent's performance"""
    total_rewards = []
    
    for _ in range(n_episodes):
        obs, _ = env.reset()
        done = False
        total_reward = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            done = terminated or truncated
            
        total_rewards.append(total_reward)
    
    return sum(total_rewards) / len(total_rewards)

def train_agent(env, timesteps=1000000, seed=0):
    """Train a basic agent"""
    agent = PPO(
        policy="MlpPolicy",
        env=env,
        learning_rate=3e-4,
        n_steps=2048,
        batch_size=64,
        n_epochs=10,
        gamma=0.99,
        gae_lambda=0.95,
        clip_range=0.2,
        clip_range_vf=None,
        ent_coef=0.0,
        vf_coef=0.5,
        max_grad_norm=0.5,
        use_sde=False,
        sde_sample_freq=-1,
        target_kl=None,
        tensorboard_log=None,
        policy_kwargs=None,
        verbose=1,
        seed=seed,
        device="auto",
    )
    
    agent.learn(total_timesteps=timesteps)
    return agent

def main():
    args = parse_args()
    
    # Set random seeds
    torch.manual_seed(args.seed)
    
    # Get environment config
    config = get_config(args.env)
    
    # Create environment
    env = create_environment(args.env)
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Train or load agent
    if args.skip_training:
        if args.agent_path is None or args.mask_path is None:
            raise ValueError("When using --skip-training, --agent-path and --mask-path must be provided")
        
        print(f"Loading pre-trained agent from {args.agent_path}")
        agent = PPO.load(args.agent_path, env=env)
        
        print(f"Loading mask network from {args.mask_path}")
        from rice.models.state_mask import MaskNetwork
        mask_net = MaskNetwork(env.observation_space)
        mask_net.load_state_dict(torch.load(args.mask_path))
    else:
        # Step 1: Train a basic agent
        print("Step 1: Training a basic agent...")
        start_time = time.time()
        agent = train_agent(env, timesteps=config['timesteps'], seed=args.seed)
        print(f"Training completed in {time.time() - start_time:.2f} seconds")
        
        # Save the agent
        agent_path = os.path.join(args.output_dir, f"{args.env}_agent.zip")
        agent.save(agent_path)
        print(f"Agent saved to {agent_path}")
        
        # Evaluate the agent
        mean_reward = evaluate_agent(agent, env)
        print(f"Agent performance: {mean_reward:.2f}")
        
        # Step 2: Train the mask network
        print("\nStep 2: Training the mask network...")
        start_time = time.time()
        
        state_mask = ImprovedStateMask(
            target_agent=agent,
            observation_space=env.observation_space,
            action_space=env.action_space,
            mask_bonus=config['mask_bonus'],
        )
        
        mask_net = state_mask.train(env, total_timesteps=config['timesteps'] // 2)
        print(f"Mask network training completed in {time.time() - start_time:.2f} seconds")
        
        # Save the mask network
        mask_path = os.path.join(args.output_dir, f"{args.env}_mask.pt")
        torch.save(mask_net.state_dict(), mask_path)
        print(f"Mask network saved to {mask_path}")
    
    # Step 3: Refine the agent with RICE
    print("\nStep 3: Refining the agent with RICE...")
    start_time = time.time()
    
    rice = RICE(
        pretrained_agent=agent,
        mask_net=mask_net,
        env=env,
        reset_prob=config['reset_prob'],
        exploration_coef=config['exploration_coef'],
    )
    
    refined_agent = rice.refine(total_timesteps=config['timesteps'])
    print(f"Refining completed in {time.time() - start_time:.2f} seconds")
    
    # Save the refined agent
    refined_agent_path = os.path.join(args.output_dir, f"{args.env}_rice_refined.zip")
    refined_agent.save(refined_agent_path)
    print(f"Refined agent saved to {refined_agent_path}")
    
    # Evaluate the refined agent
    refined_mean_reward = evaluate_agent(refined_agent, env)
    original_mean_reward = evaluate_agent(agent, env)
    
    print(f"Original agent performance: {original_mean_reward:.2f}")
    print(f"Refined agent performance: {refined_mean_reward:.2f}")
    print(f"Improvement: {(refined_mean_reward - original_mean_reward):.2f} ({((refined_mean_reward - original_mean_reward) / abs(original_mean_reward)) * 100:.2f}%)")
    
if __name__ == "__main__":
    main()
