#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
from stable_baselines3 import PPO, SAC

from rice.models.state_mask import MaskNetwork, ImprovedStateMask
from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv
from rice.utils.fidelity import compute_fidelity_score
from rice.utils.explanation import random_explanation, identify_critical_states

def parse_args():
    parser = argparse.ArgumentParser(description='Test explanation fidelity')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to test on')
    
    parser.add_argument('--agent-path', type=str, required=True,
                        help='Path to agent to evaluate')
    
    parser.add_argument('--mask-path', type=str, default=None,
                        help='Path to mask network (if None, a new one will be trained)')
    
    parser.add_argument('--algorithm', type=str, default='PPO', choices=['PPO', 'SAC'],
                        help='Algorithm used for the agent(s)')
    
    parser.add_argument('--train-timesteps', type=int, default=10000,
                        help='Number of timesteps to train mask network (if needed)')
    
    parser.add_argument('--mask-bonus', type=float, default=0.01,
                        help='Bonus for masking (if training mask network)')
    
    parser.add_argument('--output-dir', type=str, default='./fidelity_results',
                        help='Directory to save results')
    
    parser.add_argument('--n-trajectories', type=int, default=10,
                        help='Number of trajectories to evaluate fidelity on')
    
    parser.add_argument('--window-fractions', type=str, default='0.1,0.2,0.3,0.4',
                        help='Comma-separated list of window fractions (K in the paper)')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, algorithm, env):
    """Load an agent"""
    if algorithm == 'PPO':
        return PPO.load(agent_path, env=env)
    elif algorithm == 'SAC':
        return SAC.load(agent_path, env=env)
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create environment
    env = create_environment(args.env)
    
    # Load agent
    agent = load_agent(args.agent_path, args.algorithm, env)
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Parse window fractions
    window_fractions = [float(k) for k in args.window_fractions.split(',')]
    
    # Dictionary to store fidelity scores
    fidelity_scores = {
        'random': {},
        'statemask': {},
    }
    
    # Create or load mask network
    if args.mask_path is not None:
        print(f"Loading mask network from {args.mask_path}")
        mask_net = MaskNetwork(env.observation_space)
        mask_net.load_state_dict(torch.load(args.mask_path))
    else:
        print(f"Training new mask network for {args.train_timesteps} timesteps...")
        state_mask = ImprovedStateMask(
            target_agent=agent,
            observation_space=env.observation_space,
            action_space=env.action_space,
            mask_bonus=args.mask_bonus,
        )
        
        mask_net = state_mask.train(env, total_timesteps=args.train_timesteps)
        
        # Save the mask network
        mask_path = os.path.join(args.output_dir, f"{args.env}_mask.pt")
        torch.save(mask_net.state_dict(), mask_path)
        print(f"Saved mask network to {mask_path}")
    
    # Create explanation functions
    def random_explanation_fn(states):
        return random_explanation(states)
    
    def statemask_explanation_fn(states):
        return identify_critical_states(states, mask_net)
    
    # Compute fidelity scores for each window fraction
    for k in window_fractions:
        print(f"\nEvaluating with window fraction K = {k}...")
        
        print("Computing fidelity for random explanation...")
        random_fidelity = compute_fidelity_score(
            agent=agent,
            env=env,
            explanation_method=random_explanation_fn,
            trajectory_length=1000,
            window_fraction=k,
            n_trajectories=args.n_trajectories
        )
        fidelity_scores['random'][k] = random_fidelity
        
        print("Computing fidelity for StateMask explanation...")
        statemask_fidelity = compute_fidelity_score(
            agent=agent,
            env=env,
            explanation_method=statemask_explanation_fn,
            trajectory_length=1000,
            window_fraction=k,
            n_trajectories=args.n_trajectories
        )
        fidelity_scores['statemask'][k] = statemask_fidelity
        
        print(f"K = {k}:")
        print(f"  Random explanation fidelity: {random_fidelity:.4f}")
        print(f"  StateMask explanation fidelity: {statemask_fidelity:.4f}")
    
    # Plot results
    plt.figure(figsize=(10, 6))
    
    x = np.arange(len(window_fractions))
    width = 0.35
    
    random_values = [fidelity_scores['random'][k] for k in window_fractions]
    statemask_values = [fidelity_scores['statemask'][k] for k in window_fractions]
    
    plt.bar(x - width/2, random_values, width, label='Random')
    plt.bar(x + width/2, statemask_values, width, label='StateMask')
    
    plt.xlabel('Window Fraction (K)')
    plt.ylabel('Fidelity Score')
    plt.title(f'Explanation Fidelity Comparison - {args.env}')
    plt.xticks(x, [str(k) for k in window_fractions])
    plt.legend()
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    
    plt.savefig(os.path.join(args.output_dir, f"{args.env}_fidelity_comparison.png"))
    print(f"\nResults saved to {args.output_dir}")
    
    # Save the fidelity scores
    np.save(os.path.join(args.output_dir, f"{args.env}_fidelity_scores.npy"), fidelity_scores)

if __name__ == "__main__":
    main()
