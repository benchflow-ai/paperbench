import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class RNDModel(nn.Module):
    """
    Random Network Distillation model as described in the paper.
    
    Consists of:
    1. A fixed randomly initialized target network that produces embeddings
    2. A predictor network trained to predict the embeddings of the target network
    
    The prediction error is used as an intrinsic reward signal to encourage exploration.
    """
    def __init__(self, input_size, hidden_size=64, output_size=64):
        super(RNDModel, self).__init__()
        
        # Target network (fixed random weights, never updated)
        self.target_network = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size),
            nn.ReLU()
        )
        
        # Predictor network (trained to predict target network outputs)
        self.predictor_network = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size),
            nn.ReLU()
        )
        
        # Initialize the networks - target network is fixed
        for param in self.target_network.parameters():
            param.requires_grad = False
    
    def forward(self, x):
        # Get target and prediction
        target = self.target_network(x)
        prediction = self.predictor_network(x)
        
        return target, prediction


class RND:
    """
    Random Network Distillation exploration strategy.
    
    RND generates an intrinsic reward based on the prediction error of a
    neural network trying to predict the output of a fixed randomly initialized 
    target network. This encourages exploration of novel states.
    """
    def __init__(self, observation_space, device="cpu", learning_rate=1e-4):
        self.device = device
        
        # Determine input size from observation space
        if len(observation_space.shape) == 1:
            input_size = observation_space.shape[0]
        else:
            # For image observations, would need a CNN architecture
            input_size = np.prod(observation_space.shape)
        
        # Initialize the RND model
        self.model = RNDModel(input_size).to(device)
        
        # Initialize optimizer for the predictor network only
        self.optimizer = torch.optim.Adam(self.model.predictor_network.parameters(), lr=learning_rate)
        
        # Running statistics for normalization
        self.obs_rms = RunningMeanStd(shape=(input_size,))
        self.reward_rms = RunningMeanStd()
        
    def compute_intrinsic_reward(self, obs):
        """Compute the intrinsic reward as the prediction error"""
        # Normalize observations
        obs_normalized = self._normalize_obs(obs)
        
        # Convert to tensor
        obs_tensor = torch.FloatTensor(obs_normalized).to(self.device)
        
        # Compute target and prediction
        with torch.no_grad():
            target, prediction = self.model(obs_tensor)
            
            # Compute intrinsic reward as MSE between target and prediction
            intrinsic_reward = F.mse_loss(prediction, target, reduction='none').mean(dim=1).cpu().numpy()
            
            # Normalize the reward
            intrinsic_reward = self._normalize_reward(intrinsic_reward)
            
            return intrinsic_reward
    
    def update(self, obs):
        """Update the predictor network to better predict the target"""
        # Normalize observations
        obs_normalized = self._normalize_obs(obs)
        
        # Convert to tensor
        obs_tensor = torch.FloatTensor(obs_normalized).to(self.device)
        
        # Compute target and prediction
        target, prediction = self.model(obs_tensor)
        
        # Compute loss as MSE between target and prediction
        loss = F.mse_loss(prediction, target)
        
        # Update predictor network
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        return loss.item()
    
    def _normalize_obs(self, obs):
        """Normalize observations using running statistics"""
        self.obs_rms.update(obs)
        return (obs - self.obs_rms.mean) / np.sqrt(self.obs_rms.var + 1e-8)
    
    def _normalize_reward(self, reward):
        """Normalize rewards using running statistics"""
        self.reward_rms.update(reward)
        return reward / np.sqrt(self.reward_rms.var + 1e-8)


class RunningMeanStd:
    """
    Compute running mean and std for normalization.
    
    Adapted from OpenAI baselines.
    """
    def __init__(self, shape=()):
        self.mean = np.zeros(shape, dtype=np.float32)
        self.var = np.ones(shape, dtype=np.float32)
        self.count = 1e-4
        
    def update(self, x):
        batch_mean = np.mean(x, axis=0)
        batch_var = np.var(x, axis=0)
        batch_count = x.shape[0]
        
        self.update_from_moments(batch_mean, batch_var, batch_count)
        
    def update_from_moments(self, batch_mean, batch_var, batch_count):
        delta = batch_mean - self.mean
        
        new_mean = self.mean + delta * batch_count / (self.count + batch_count)
        m_a = self.var * self.count
        m_b = batch_var * batch_count
        M2 = m_a + m_b + np.square(delta) * self.count * batch_count / (self.count + batch_count)
        new_var = M2 / (self.count + batch_count)
        
        self.mean = new_mean
        self.var = new_var
        self.count = self.count + batch_count
