#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
from stable_baselines3 import PPO, SAC

from rice.models.state_mask import MaskNetwork, ImprovedStateMask
from rice.models.rice import RICE
from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv

def parse_args():
    parser = argparse.ArgumentParser(description='Train with RICE algorithm')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to train on')
    
    parser.add_argument('--agent-path', type=str, required=True,
                        help='Path to pre-trained agent')
    
    parser.add_argument('--mask-path', type=str, required=True,
                        help='Path to trained mask network')
    
    parser.add_argument('--save-path', type=str, default='./rice_refined_agents',
                        help='Path to save the refined agent')
    
    parser.add_argument('--algorithm', type=str, default='PPO', choices=['PPO', 'SAC'],
                        help='Algorithm used for the pre-trained agent')
    
    parser.add_argument('--timesteps', type=int, default=100000,
                        help='Number of timesteps to train with RICE')
    
    parser.add_argument('--reset-prob', type=float, default=0.5,
                        help='Probability p of resetting to critical states')
    
    parser.add_argument('--exploration-coef', type=float, default=0.01,
                        help='Coefficient λ for the RND exploration bonus')
    
    parser.add_argument('--eval-interval', type=int, default=10000,
                        help='Interval (in timesteps) between evaluations')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    parser.add_argument('--no-rnd', action='store_true',
                        help='Disable RND exploration')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, algorithm, env):
    """Load a pre-trained agent"""
    if algorithm == 'PPO':
        return PPO.load(agent_path, env=env)
    elif algorithm == 'SAC':
        return SAC.load(agent_path, env=env)
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

def load_mask_network(mask_path, observation_space):
    """Load a trained mask network"""
    # Create mask network with the same architecture
    mask_net = MaskNetwork(observation_space)
    
    # Load weights
    mask_net.load_state_dict(torch.load(mask_path))
    
    return mask_net

def evaluate_agent(agent, env, n_episodes=10):
    """Evaluate an agent's performance"""
    total_rewards = []
    
    for _ in range(n_episodes):
        obs, _ = env.reset()
        done = False
        total_reward = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            done = terminated or truncated
            
        total_rewards.append(total_reward)
    
    return np.mean(total_rewards), np.std(total_rewards)

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create environment
    env = create_environment(args.env)
    
    # Load pre-trained agent
    agent = load_agent(args.agent_path, args.algorithm, env)
    
    # Load mask network
    mask_net = load_mask_network(args.mask_path, env.observation_space)
    
    # Create RICE instance
    exploration_coef = 0.0 if args.no_rnd else args.exploration_coef
    rice = RICE(
        pretrained_agent=agent,
        mask_net=mask_net,
        env=env,
        reset_prob=args.reset_prob,
        exploration_coef=exploration_coef,
    )
    
    # Evaluate pre-trained agent
    mean_reward, std_reward = evaluate_agent(agent, env)
    print(f"Pre-trained agent: mean reward = {mean_reward:.2f} ± {std_reward:.2f}")
    
    # Train with RICE
    print(f"Training with RICE for {args.timesteps} timesteps...")
    refined_agent = rice.refine(total_timesteps=args.timesteps)
    
    # Evaluate refined agent
    mean_reward, std_reward = evaluate_agent(refined_agent, env)
    print(f"Refined agent: mean reward = {mean_reward:.2f} ± {std_reward:.2f}")
    
    # Create save directory if it doesn't exist
    os.makedirs(args.save_path, exist_ok=True)
    
    # Save the refined agent
    save_path = os.path.join(args.save_path, f"{args.env}_rice_refined")
    refined_agent.save(save_path)
    print(f"Saved refined agent to {save_path}")

if __name__ == "__main__":
    main()
