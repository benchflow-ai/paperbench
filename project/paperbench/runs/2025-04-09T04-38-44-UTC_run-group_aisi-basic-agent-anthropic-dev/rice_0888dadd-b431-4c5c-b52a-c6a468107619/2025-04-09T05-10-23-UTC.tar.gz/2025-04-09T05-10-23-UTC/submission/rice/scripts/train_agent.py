#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback, EvalCallback
from stable_baselines3.common.env_util import make_vec_env

from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv
from rice.configs.env_configs import get_config

class RewardCallback(BaseCallback):
    """
    Callback for saving reward history during training.
    """
    def __init__(self, check_freq=1000, log_dir=None, verbose=1):
        super(RewardCallback, self).__init__(verbose)
        self.check_freq = check_freq
        self.log_dir = log_dir
        self.rewards = []
        self.timesteps = []
        self.episode_rewards = []
        self.current_episode_reward = 0
        
        if log_dir is not None:
            os.makedirs(log_dir, exist_ok=True)
    
    def _on_step(self) -> bool:
        # Record reward for this step
        self.current_episode_reward += self.locals["rewards"][0]
        
        # If episode is done, record episode reward
        if self.locals["dones"][0]:
            self.episode_rewards.append(self.current_episode_reward)
            self.current_episode_reward = 0
        
        # Save reward history periodically
        if self.n_calls % self.check_freq == 0:
            # Calculate average reward over last check_freq steps
            if len(self.episode_rewards) > 0:
                avg_reward = np.mean(self.episode_rewards[-100:] if len(self.episode_rewards) >= 100 else self.episode_rewards)
                self.rewards.append(avg_reward)
                self.timesteps.append(self.n_calls)
                
                if self.log_dir is not None:
                    # Save reward history to file
                    np.save(os.path.join(self.log_dir, "rewards.npy"), np.array(self.rewards))
                    np.save(os.path.join(self.log_dir, "timesteps.npy"), np.array(self.timesteps))
                    
                    # Plot reward history
                    plt.figure(figsize=(10, 6))
                    plt.plot(self.timesteps, self.rewards)
                    plt.xlabel("Timesteps")
                    plt.ylabel("Average Episode Reward")
                    plt.title("Training Reward History")
                    plt.grid(True, linestyle='--', alpha=0.7)
                    plt.savefig(os.path.join(self.log_dir, "reward_history.png"))
                    plt.close()
        
        return True

def parse_args():
    parser = argparse.ArgumentParser(description='Train a base agent for RICE')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to train on')
    
    parser.add_argument('--algorithm', type=str, default='PPO', choices=['PPO', 'SAC'],
                        help='RL algorithm to use')
    
    parser.add_argument('--timesteps', type=int, default=1000000,
                        help='Number of timesteps to train for')
    
    parser.add_argument('--learning-rate', type=float, default=3e-4,
                        help='Learning rate')
    
    parser.add_argument('--checkpoint-freq', type=int, default=100000,
                        help='Frequency (in timesteps) to save checkpoints')
    
    parser.add_argument('--eval-freq', type=int, default=20000,
                        help='Frequency (in timesteps) to evaluate the agent')
    
    parser.add_argument('--n-eval-episodes', type=int, default=10,
                        help='Number of episodes for evaluation')
    
    parser.add_argument('--save-final-only', action='store_true',
                        help='Only save the final model, not intermediate checkpoints')
    
    parser.add_argument('--output-dir', type=str, default='./results/base_agents',
                        help='Directory to save the trained agent')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        env = create_env(env_name)
    elif env_name == 'selfish_mining':
        env = SelfishMiningEnv()
    elif env_name == 'network_defense':
        env = NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        env = AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")
        
    return env

def create_agent(algorithm, env, learning_rate=3e-4, seed=0):
    """Create an agent with the specified algorithm"""
    if algorithm == 'PPO':
        # Use environment-specific configs if available
        try:
            config = get_config(env.unwrapped.spec.id)
            
            # Create agent with environment-specific parameters
            agent = PPO(
                policy="MlpPolicy",
                env=env,
                learning_rate=learning_rate,
                n_steps=config.get('n_steps', 2048),
                batch_size=config.get('batch_size', 64),
                n_epochs=config.get('n_epochs', 10),
                gamma=config.get('gamma', 0.99),
                gae_lambda=config.get('gae_lambda', 0.95),
                clip_range=config.get('clip_range', 0.2),
                clip_range_vf=config.get('clip_range_vf', None),
                normalize_advantage=config.get('normalize_advantage', True),
                ent_coef=config.get('ent_coef', 0.0),
                vf_coef=config.get('vf_coef', 0.5),
                max_grad_norm=config.get('max_grad_norm', 0.5),
                use_sde=config.get('use_sde', False),
                sde_sample_freq=config.get('sde_sample_freq', -1),
                target_kl=config.get('target_kl', None),
                tensorboard_log=None,
                policy_kwargs=config.get('policy_kwargs', None),
                verbose=1,
                seed=seed,
                device="auto",
            )
        except:
            # Fallback to default parameters
            agent = PPO(
                policy="MlpPolicy",
                env=env,
                learning_rate=learning_rate,
                n_steps=2048,
                batch_size=64,
                n_epochs=10,
                gamma=0.99,
                gae_lambda=0.95,
                clip_range=0.2,
                clip_range_vf=None,
                normalize_advantage=True,
                ent_coef=0.0,
                vf_coef=0.5,
                max_grad_norm=0.5,
                use_sde=False,
                sde_sample_freq=-1,
                target_kl=None,
                tensorboard_log=None,
                policy_kwargs=None,
                verbose=1,
                seed=seed,
                device="auto",
            )
    elif algorithm == 'SAC':
        # Use environment-specific configs if available
        try:
            config = get_config(env.unwrapped.spec.id)
            
            # Create agent with environment-specific parameters
            agent = SAC(
                policy="MlpPolicy",
                env=env,
                learning_rate=learning_rate,
                buffer_size=config.get('buffer_size', 1000000),
                learning_starts=config.get('learning_starts', 100),
                batch_size=config.get('batch_size', 256),
                tau=config.get('tau', 0.005),
                gamma=config.get('gamma', 0.99),
                train_freq=config.get('train_freq', 1),
                gradient_steps=config.get('gradient_steps', 1),
                action_noise=config.get('action_noise', None),
                replay_buffer_class=config.get('replay_buffer_class', None),
                replay_buffer_kwargs=config.get('replay_buffer_kwargs', None),
                optimize_memory_usage=config.get('optimize_memory_usage', False),
                ent_coef=config.get('ent_coef', 'auto'),
                target_update_interval=config.get('target_update_interval', 1),
                target_entropy=config.get('target_entropy', 'auto'),
                use_sde=config.get('use_sde', False),
                sde_sample_freq=config.get('sde_sample_freq', -1),
                use_sde_at_warmup=config.get('use_sde_at_warmup', False),
                tensorboard_log=None,
                policy_kwargs=config.get('policy_kwargs', None),
                verbose=1,
                seed=seed,
                device="auto",
            )
        except:
            # Fallback to default parameters
            agent = SAC(
                policy="MlpPolicy",
                env=env,
                learning_rate=learning_rate,
                buffer_size=1000000,
                learning_starts=100,
                batch_size=256,
                tau=0.005,
                gamma=0.99,
                train_freq=1,
                gradient_steps=1,
                action_noise=None,
                ent_coef='auto',
                target_update_interval=1,
                target_entropy='auto',
                verbose=1,
                seed=seed,
                device="auto",
            )
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")
    
    return agent

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create output directory
    env_output_dir = os.path.join(args.output_dir, f"{args.env}_{args.algorithm.lower()}")
    os.makedirs(env_output_dir, exist_ok=True)
    
    # Create environment
    env = create_environment(args.env)
    
    # Create agent
    agent = create_agent(args.algorithm, env, args.learning_rate, args.seed)
    
    # Create callbacks
    callbacks = []
    
    # Reward tracking callback
    reward_callback = RewardCallback(
        check_freq=10000,
        log_dir=env_output_dir,
        verbose=1
    )
    callbacks.append(reward_callback)
    
    # Checkpoint callback
    if not args.save_final_only:
        checkpoint_callback = CheckpointCallback(
            save_freq=args.checkpoint_freq,
            save_path=os.path.join(env_output_dir, "checkpoints"),
            name_prefix=f"{args.env}_{args.algorithm.lower()}",
            save_replay_buffer=True,
            save_vecnormalize=True,
            verbose=1
        )
        callbacks.append(checkpoint_callback)
    
    # Evaluation callback
    eval_env = create_environment(args.env)
    eval_callback = EvalCallback(
        eval_env=eval_env,
        n_eval_episodes=args.n_eval_episodes,
        eval_freq=args.eval_freq,
        log_path=os.path.join(env_output_dir, "eval"),
        best_model_save_path=os.path.join(env_output_dir, "best_model"),
        deterministic=True,
        render=False,
        verbose=1
    )
    callbacks.append(eval_callback)
    
    # Train agent
    print(f"Training {args.algorithm} agent on {args.env} for {args.timesteps} timesteps...")
    agent.learn(
        total_timesteps=args.timesteps,
        callback=callbacks,
        log_interval=1000,
        tb_log_name=f"{args.env}_{args.algorithm.lower()}"
    )
    
    # Save final model
    agent.save(os.path.join(env_output_dir, f"{args.env}_agent"))
    print(f"Saved final model to {os.path.join(env_output_dir, f'{args.env}_agent.zip')}")
    
    # Evaluate final model
    print("Evaluating final model...")
    mean_reward, std_reward = evaluate_agent(agent, eval_env, args.n_eval_episodes)
    print(f"Final evaluation: {mean_reward:.2f} ± {std_reward:.2f}")
    
    # Save final evaluation results
    with open(os.path.join(env_output_dir, "final_evaluation.txt"), "w") as f:
        f.write(f"Environment: {args.env}\n")
        f.write(f"Algorithm: {args.algorithm}\n")
        f.write(f"Training timesteps: {args.timesteps}\n")
        f.write(f"Final evaluation (over {args.n_eval_episodes} episodes):\n")
        f.write(f"Mean reward: {mean_reward:.2f}\n")
        f.write(f"Std dev: {std_reward:.2f}\n")
    
    print(f"Training complete. Results saved to {env_output_dir}")

def evaluate_agent(agent, env, n_episodes=10):
    """Evaluate an agent's performance"""
    rewards = []
    
    for i in range(n_episodes):
        obs, _ = env.reset()
        done = False
        total_reward = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            done = terminated or truncated
            
        rewards.append(total_reward)
        print(f"  Episode {i+1}/{n_episodes}: reward = {total_reward:.2f}")
    
    return np.mean(rewards), np.std(rewards)

if __name__ == "__main__":
    main()
