#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
from stable_baselines3 import PPO, SAC

from rice.models.state_mask import MaskNetwork, ImprovedStateMask
from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv
from rice.utils.fidelity import compute_fidelity_score, find_critical_segment

def parse_args():
    parser = argparse.ArgumentParser(description='Evaluate agents and explanations')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to evaluate on')
    
    parser.add_argument('--agent-path', type=str, required=True,
                        help='Path to agent to evaluate')
    
    parser.add_argument('--refined-agent-path', type=str, default=None,
                        help='Path to refined agent (optional)')
    
    parser.add_argument('--mask-path', type=str, default=None,
                        help='Path to mask network (optional)')
    
    parser.add_argument('--algorithm', type=str, default='PPO', choices=['PPO', 'SAC'],
                        help='Algorithm used for the agent(s)')
    
    parser.add_argument('--n-eval-episodes', type=int, default=10,
                        help='Number of episodes to evaluate')
    
    parser.add_argument('--render', action='store_true',
                        help='Render the environment during evaluation')
    
    parser.add_argument('--compute-fidelity', action='store_true',
                        help='Compute fidelity score of the mask network')
    
    parser.add_argument('--output-dir', type=str, default='./results',
                        help='Directory to save results')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, algorithm, env):
    """Load an agent"""
    if algorithm == 'PPO':
        return PPO.load(agent_path, env=env)
    elif algorithm == 'SAC':
        return SAC.load(agent_path, env=env)
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

def load_mask_network(mask_path, observation_space):
    """Load a trained mask network"""
    # Create mask network with the same architecture
    mask_net = MaskNetwork(observation_space)
    
    # Load weights
    mask_net.load_state_dict(torch.load(mask_path))
    
    return mask_net

def evaluate_agent(agent, env, n_episodes=10, render=False):
    """Evaluate an agent's performance"""
    episode_rewards = []
    episode_lengths = []
    
    for ep in range(n_episodes):
        obs, _ = env.reset()
        done = False
        total_reward = 0
        steps = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            steps += 1
            
            if render:
                env.render()
                
            done = terminated or truncated
            
        episode_rewards.append(total_reward)
        episode_lengths.append(steps)
        
        print(f"Episode {ep+1}/{n_episodes}: reward = {total_reward:.2f}, length = {steps}")
    
    mean_reward = np.mean(episode_rewards)
    std_reward = np.std(episode_rewards)
    mean_length = np.mean(episode_lengths)
    
    print(f"Average reward: {mean_reward:.2f} ± {std_reward:.2f}")
    print(f"Average episode length: {mean_length:.1f}")
    
    return mean_reward, std_reward, episode_rewards

def collect_trajectory(agent, env, render=False):
    """Collect a single trajectory from the agent"""
    obs, _ = env.reset()
    states = [obs]
    rewards = []
    dones = []
    
    done = False
    while not done:
        action, _ = agent.predict(obs, deterministic=True)
        next_obs, reward, terminated, truncated, _ = env.step(action)
        
        if render:
            env.render()
            
        states.append(next_obs)
        rewards.append(reward)
        
        obs = next_obs
        done = terminated or truncated
        dones.append(done)
        
    return np.array(states), np.array(rewards), np.array(dones)

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create environment
    env = create_environment(args.env)
    
    # Load agent
    agent = load_agent(args.agent_path, args.algorithm, env)
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Evaluate agent
    print("Evaluating original agent...")
    orig_mean_reward, orig_std_reward, orig_rewards = evaluate_agent(
        agent, env, n_episodes=args.n_eval_episodes, render=args.render
    )
    
    # Evaluate refined agent if provided
    if args.refined_agent_path is not None:
        print("\nEvaluating refined agent...")
        refined_agent = load_agent(args.refined_agent_path, args.algorithm, env)
        refined_mean_reward, refined_std_reward, refined_rewards = evaluate_agent(
            refined_agent, env, n_episodes=args.n_eval_episodes, render=args.render
        )
        
        # Plot comparison
        plt.figure(figsize=(10, 6))
        plt.bar(['Original', 'Refined'], [orig_mean_reward, refined_mean_reward], 
                yerr=[orig_std_reward, refined_std_reward], capsize=10)
        plt.ylabel('Average Reward')
        plt.title(f'Performance Comparison - {args.env}')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.savefig(os.path.join(args.output_dir, f"{args.env}_performance_comparison.png"))
        
        # Calculate improvement
        improvement = ((refined_mean_reward - orig_mean_reward) / abs(orig_mean_reward)) * 100
        print(f"\nImprovement: {improvement:.2f}%")
    
    # Compute fidelity score if requested and mask network is provided
    if args.compute_fidelity and args.mask_path is not None:
        print("\nComputing fidelity score...")
        
        # Load mask network
        mask_net = load_mask_network(args.mask_path, env.observation_space)
        
        # Define explanation function
        def explanation_fn(states):
            with torch.no_grad():
                if not isinstance(states, torch.Tensor):
                    states_tensor = torch.FloatTensor(states)
                else:
                    states_tensor = states
                
                mask_probs = mask_net(states_tensor)
                importance_scores = 1 - mask_probs.squeeze().cpu().numpy()
                
                return importance_scores
        
        # Compute fidelity score
        fidelity_score = compute_fidelity_score(
            agent=agent,
            env=env,
            explanation_method=explanation_fn,
            trajectory_length=1000,
            window_fraction=0.1,
            n_trajectories=5
        )
        
        print(f"Fidelity score: {fidelity_score:.4f}")
        
        # Visualize critical states in a trajectory
        print("\nIdentifying critical states in a trajectory...")
        states, rewards, dones = collect_trajectory(agent, env, render=False)
        importance_scores = explanation_fn(states)
        
        # Find critical segment
        start_idx, end_idx = find_critical_segment(states, importance_scores)
        
        # Plot importance scores
        plt.figure(figsize=(12, 6))
        plt.plot(importance_scores, label='Importance Score')
        plt.axvspan(start_idx, end_idx, color='red', alpha=0.3, label='Critical Segment')
        plt.xlabel('Time Step')
        plt.ylabel('Importance Score')
        plt.title(f'State Importance Scores - {args.env}')
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.tight_layout()
        plt.savefig(os.path.join(args.output_dir, f"{args.env}_importance_scores.png"))
        
        print(f"Critical segment: steps {start_idx} to {end_idx}")

if __name__ == "__main__":
    main()
