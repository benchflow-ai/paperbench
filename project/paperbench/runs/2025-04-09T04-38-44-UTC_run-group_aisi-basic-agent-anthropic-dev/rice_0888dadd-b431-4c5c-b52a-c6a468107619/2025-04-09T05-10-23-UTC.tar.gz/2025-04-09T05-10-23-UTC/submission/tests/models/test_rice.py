import os
import sys
import unittest
import numpy as np
import torch
import gymnasium as gym
from stable_baselines3 import PPO

from rice.models.state_mask import MaskNetwork
from rice.models.rice import RICE

class TestRICE(unittest.TestCase):
    def setUp(self):
        # Create a simple environment for testing
        self.env = gym.make('CartPole-v1')
        
        # Train a simple agent for testing
        self.agent = PPO('MlpPolicy', self.env, verbose=0, seed=0)
        self.agent.learn(total_timesteps=100)  # Just a few steps
        
        # Create a mask network
        self.mask_net = MaskNetwork(self.env.observation_space)
        
        # Initialize RICE
        self.rice = RICE(
            pretrained_agent=self.agent,
            mask_net=self.mask_net,
            env=self.env,
            reset_prob=0.5,
            exploration_coef=0.01,
            device="cpu"
        )
    
    def test_initialization(self):
        # Test that RICE is initialized correctly
        self.assertIsInstance(self.rice, RICE)
        self.assertEqual(self.rice.pretrained_agent, self.agent)
        self.assertEqual(self.rice.mask_net, self.mask_net)
        self.assertEqual(self.rice.env, self.env)
        self.assertEqual(self.rice.reset_prob, 0.5)
        self.assertEqual(self.rice.exploration_coef, 0.01)
        self.assertEqual(self.rice.device, "cpu")
        
        # Check that RND is initialized
        self.assertIsNotNone(self.rice.rnd)
        
        # Check that refined agent is initialized
        self.assertIsNotNone(self.rice.refined_agent)
    
    def test_identify_critical_state(self):
        # Generate a small trajectory
        obs, _ = self.env.reset()
        trajectory = [obs]
        
        for _ in range(5):
            action, _ = self.agent.predict(obs, deterministic=False)
            obs, _, terminated, truncated, _ = self.env.step(action)
            trajectory.append(obs)
            
            if terminated or truncated:
                break
        
        # Test identifying critical state
        critical_state = self.rice.identify_critical_state(trajectory)
        
        # Check that critical state is a numpy array
        self.assertIsInstance(critical_state, np.ndarray)
        
        # Check that critical state has the right shape
        self.assertEqual(critical_state.shape, self.env.observation_space.shape)
    
    def test_collect_trajectory(self):
        # Test collecting a trajectory
        trajectory = self.rice.collect_trajectory()
        
        # Check that trajectory is a list
        self.assertIsInstance(trajectory, list)
        
        # Check that trajectory contains observations
        self.assertTrue(len(trajectory) > 0)
        
        # Check that each observation has the right shape
        for obs in trajectory:
            self.assertEqual(obs.shape, self.env.observation_space.shape)
    
    def test_short_refining(self):
        # Test refining process for a very short period
        # This is just to check that the method runs without errors
        # Full refining testing would be done in integration tests
        refined_agent = self.rice.refine(total_timesteps=10)
        
        # Check that refined agent is returned
        self.assertIsNotNone(refined_agent)
        self.assertIsInstance(refined_agent, PPO)

if __name__ == '__main__':
    unittest.main()
