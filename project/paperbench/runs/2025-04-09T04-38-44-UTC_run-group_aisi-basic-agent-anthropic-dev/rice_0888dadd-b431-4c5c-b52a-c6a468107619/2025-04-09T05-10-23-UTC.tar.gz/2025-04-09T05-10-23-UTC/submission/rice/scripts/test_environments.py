#!/usr/bin/env python3

import argparse
import numpy as np
import gymnasium as gym
import time

from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv

def parse_args():
    parser = argparse.ArgumentParser(description='Test environments for RICE')
    
    parser.add_argument('--render', action='store_true',
                        help='Render the environments')
    
    parser.add_argument('--steps', type=int, default=100,
                        help='Number of steps to run each environment')
    
    parser.add_argument('--env', type=str, default='all',
                        help='Specific environment to test or "all"')
    
    return parser.parse_args()

def test_environment(env_creator, env_name, steps=100, render=False):
    """Test a single environment"""
    print(f"Testing {env_name}...")
    
    try:
        # Create environment
        env = env_creator()
        
        # Check spaces
        print(f"  Observation space: {env.observation_space}")
        print(f"  Action space: {env.action_space}")
        
        # Reset environment
        obs, _ = env.reset()
        print(f"  Initial observation shape: {obs.shape}")
        
        # Run random actions
        total_reward = 0
        start_time = time.time()
        
        for i in range(steps):
            action = env.action_space.sample()
            obs, reward, terminated, truncated, info = env.step(action)
            total_reward += reward
            
            if render:
                env.render()
                
            if terminated or truncated:
                print(f"  Episode ended after {i+1} steps")
                obs, _ = env.reset()
        
        end_time = time.time()
        
        # Report results
        print(f"  Completed {steps} steps in {end_time - start_time:.2f} seconds")
        print(f"  Total reward: {total_reward:.2f}")
        print(f"  Final observation shape: {obs.shape}")
        print(f"  Environment test successful!")
        
        # Close environment
        env.close()
        return True
        
    except Exception as e:
        print(f"  Error testing {env_name}: {str(e)}")
        return False

def main():
    args = parse_args()
    
    # Define all environments to test
    environments = {
        'hopper': lambda: create_env('hopper'),
        'walker2d': lambda: create_env('walker2d'),
        'reacher': lambda: create_env('reacher'),
        'halfcheetah': lambda: create_env('halfcheetah'),
        'sparse_hopper': lambda: create_env('sparse_hopper'),
        'sparse_walker2d': lambda: create_env('sparse_walker2d'),
        'sparse_halfcheetah': lambda: create_env('sparse_halfcheetah'),
        'selfish_mining': lambda: SelfishMiningEnv(),
        'network_defense': lambda: NetworkDefenseEnv(),
        'auto_driving': lambda: AutoDrivingEnv()
    }
    
    # Determine which environments to test
    if args.env == 'all':
        envs_to_test = environments
    elif args.env in environments:
        envs_to_test = {args.env: environments[args.env]}
    else:
        print(f"Unknown environment: {args.env}")
        print(f"Available environments: {', '.join(environments.keys())}")
        return
    
    # Test each environment
    results = {}
    
    for env_name, env_creator in envs_to_test.items():
        success = test_environment(
            env_creator=env_creator,
            env_name=env_name,
            steps=args.steps,
            render=args.render
        )
        results[env_name] = success
        print("")  # Add empty line between environments
    
    # Print summary
    print("Testing Summary:")
    success_count = sum(results.values())
    total_count = len(results)
    
    print(f"Successfully tested {success_count}/{total_count} environments")
    
    if success_count < total_count:
        print("Failed environments:")
        for env_name, success in results.items():
            if not success:
                print(f"  - {env_name}")
    else:
        print("All environments passed the test!")

if __name__ == "__main__":
    main()
