# Utilities Documentation

This document provides detailed documentation for the utility functions in the RICE implementation.

## Random Network Distillation (RND)

The `rnd.py` file contains the implementation of Random Network Distillation (RND) for exploration.

### RNDModel

```python
class RNDModel(nn.Module)
```

The `RNDModel` class implements the neural network architecture for RND. It consists of two networks:
1. A fixed randomly initialized target network that produces embeddings
2. A predictor network trained to predict the embeddings of the target network

The prediction error is used as an intrinsic reward signal to encourage exploration.

#### Key Methods

- `forward(x)`: Forward pass through both networks, returning target and prediction

### RND

```python
class RND
```

The `RND` class implements the RND exploration strategy. It generates an intrinsic reward based on the prediction error of a neural network trying to predict the output of a fixed randomly initialized target network. This encourages exploration of novel states.

#### Key Methods

- `compute_intrinsic_reward(obs)`: Compute the intrinsic reward for a given observation
- `update(obs)`: Update the predictor network to better predict the target

### RunningMeanStd

```python
class RunningMeanStd
```

The `RunningMeanStd` class computes running mean and standard deviation for normalization, which helps stabilize learning.

#### Key Methods

- `update(x)`: Update the running statistics with new data

## Fidelity

The `fidelity.py` file contains functions for computing the fidelity of explanation methods.

### Fidelity Score Calculation

The fidelity score pipeline is:

1. The explanation method generates step-level importance scores for the trajectory
2. A sliding window is applied to find the most critical segment
3. The agent is fast-forwarded to the start of the identified critical segment
4. Random actions are taken for the duration of the segment
5. The agent's policy continues executing until the episode ends
6. The change in reward is measured and normalized to compute the fidelity score

#### Key Functions

- `compute_fidelity_score(agent, env, explanation_method, trajectory_length, window_fraction, n_trajectories)`: Compute the fidelity score of an explanation method
- `find_critical_segment(states, importance_scores, window_fraction)`: Find the most critical segment in a trajectory based on importance scores

### Fidelity Score Formula

The fidelity score is calculated using the formula:

```
Fidelity Score = log(d/d_max) - log(l/L)
```

where:
- `d` is the change in reward after randomizing actions in the critical segment
- `d_max` is the maximum possible reward change
- `l` is the length of the critical segment
- `L` is the total trajectory length

A higher fidelity score indicates that the explanation method has identified steps that are truly critical to the agent's performance.

## Explanation Utilities

The `explanation.py` file contains utility functions for generating and handling explanations.

### Key Functions

- `random_explanation(states)`: Generate random importance scores for a sequence of states
- `identify_critical_states(states, mask_net, device="cpu")`: Identify critical states using a trained mask network
- `sample_from_mixed_distribution(critical_states, original_reset_fn, p=0.5)`: Sample from a mixed initial state distribution
- `sliding_window(importance_scores, window_size)`: Find the most critical segment using a sliding window

### Mixed Initial State Distribution

A key concept in RICE is the mixed initial state distribution, which combines regular initial states with critical states:

- With probability `p`, reset to a critical state
- With probability `1-p`, reset to a default initial state

This approach helps avoid overfitting that can occur when always resetting to critical states, while still allowing the agent to learn from important scenarios.
