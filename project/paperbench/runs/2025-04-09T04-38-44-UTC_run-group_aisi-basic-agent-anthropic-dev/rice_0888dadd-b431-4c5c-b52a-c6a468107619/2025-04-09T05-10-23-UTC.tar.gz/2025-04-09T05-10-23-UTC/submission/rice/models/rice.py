import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.buffers import RolloutBuffer

from rice.utils.rnd import RND

class RICE:
    """
    RICE (Refining scheme for ReInforCement learning with Explanation) implementation.
    
    RICE refines a pre-trained RL agent by:
    1. Using explanation methods to identify critical states
    2. Constructing a mixed initial state distribution
    3. Applying exploration techniques from these states
    """
    def __init__(
        self,
        pretrained_agent,
        mask_net,
        env,
        reset_prob=0.5,  # Probability p of resetting to critical states
        exploration_coef=0.01,  # Coefficient λ for the RND exploration bonus
        device="cpu",
    ):
        self.pretrained_agent = pretrained_agent
        self.mask_net = mask_net
        self.env = env
        self.reset_prob = reset_prob
        self.exploration_coef = exploration_coef
        self.device = device
        
        # Initialize RND model for exploration
        self.rnd = RND(env.observation_space, device=device)
        
        # Storage for critical states found during exploration
        self.critical_states = []
        
        # Initialize the refined PPO agent with the same parameters as the pre-trained agent
        # For simplicity, we'll just create a new PPO agent with the same policy architecture
        self.refined_agent = PPO(
            policy=pretrained_agent.__class__.__name__,
            env=env,
            learning_rate=3e-4,
            n_steps=2048,
            batch_size=64,
            n_epochs=10,
            gamma=0.99,
            gae_lambda=0.95,
            clip_range=0.2,
            clip_range_vf=None,
            ent_coef=0.0,
            vf_coef=0.5,
            max_grad_norm=0.5,
            use_sde=False,
            sde_sample_freq=-1,
            target_kl=None,
            tensorboard_log=None,
            policy_kwargs=pretrained_agent.policy_kwargs,
            verbose=1,
            seed=None,
            device=device,
        )
        
        # Copy the weights from the pre-trained agent to the refined agent
        self.refined_agent.policy.load_state_dict(pretrained_agent.policy.state_dict())
        
    def identify_critical_state(self, trajectory):
        """
        Identify the most critical state in a trajectory using the mask network.
        
        Args:
            trajectory: A list of states from a trajectory
            
        Returns:
            The most critical state based on the mask network's output
        """
        # Convert trajectory to tensor
        if not isinstance(trajectory, torch.Tensor):
            trajectory_tensor = torch.FloatTensor(trajectory).to(self.device)
        else:
            trajectory_tensor = trajectory
            
        # Get importance scores for each state (1 - mask probability)
        with torch.no_grad():
            mask_probs = self.mask_net(trajectory_tensor)
            importance_scores = 1 - mask_probs.squeeze().cpu().numpy()
            
        # Find the state with the highest importance score
        most_critical_idx = np.argmax(importance_scores)
        most_critical_state = trajectory[most_critical_idx]
        
        return most_critical_state
    
    def collect_trajectory(self):
        """Collect a trajectory by running the pre-trained agent"""
        states = []
        obs, _ = self.env.reset()
        done = False
        
        while not done:
            states.append(obs)
            action, _ = self.pretrained_agent.predict(obs, deterministic=False)
            obs, _, terminated, truncated, _ = self.env.step(action)
            done = terminated or truncated
            
        return states
    
    def refine(self, total_timesteps=100000):
        """
        Refine the pre-trained agent using the RICE algorithm.
        
        Algorithm 2 from the paper:
        1. Collect trajectories from the pre-trained agent
        2. Identify critical states using the mask network
        3. Reset to either critical states or default initial states
        4. Add RND exploration bonus to encourage exploring from these states
        5. Train the agent using PPO
        """
        # Create a callback to update the RND model during training
        class RNDCallback(BaseCallback):
            def __init__(self, rnd_model, exploration_coef, verbose=0):
                super(RNDCallback, self).__init__(verbose)
                self.rnd_model = rnd_model
                self.exploration_coef = exploration_coef
                
            def _on_step(self):
                # Add intrinsic reward to the most recent transition
                if len(self.model.rollout_buffer.observations) > 0:
                    idx = len(self.model.rollout_buffer.observations) - 1
                    obs = self.model.rollout_buffer.observations[idx]
                    
                    # Compute intrinsic reward
                    intrinsic_reward = self.rnd_model.compute_intrinsic_reward(obs.cpu().numpy())
                    
                    # Update the reward in the buffer
                    self.model.rollout_buffer.rewards[idx] += self.exploration_coef * intrinsic_reward
                    
                    # Update the RND model
                    self.rnd_model.update(obs.cpu().numpy())
                
                return True
        
        # Create a custom environment wrapper to implement the mixed initial state distribution
        class MixedInitialStateEnv:
            def __init__(self, env, critical_states, reset_prob):
                self.env = env
                self.critical_states = critical_states
                self.reset_prob = reset_prob
                self.observation_space = env.observation_space
                self.action_space = env.action_space
                
            def reset(self):
                # With probability p, reset to a critical state
                if random.random() < self.reset_prob and len(self.critical_states) > 0:
                    # Sample a random critical state
                    critical_state = random.choice(self.critical_states)
                    
                    # Reset the environment to default state first
                    self.env.reset()
                    
                    # Set the environment state to the critical state
                    # Note: This requires environment-specific implementation
                    # For now, we'll just set the observation
                    obs = critical_state
                    
                    return obs, {}
                else:
                    # Reset to default initial state
                    return self.env.reset()
            
            def step(self, action):
                return self.env.step(action)
                
            def render(self):
                return self.env.render()
                
            def close(self):
                return self.env.close()
        
        # Main refining loop
        for iteration in range(total_timesteps // 1000):  # Simplified iteration count
            # Collect a trajectory from the pre-trained agent
            trajectory = self.collect_trajectory()
            
            # Identify the most critical state
            critical_state = self.identify_critical_state(trajectory)
            
            # Add the critical state to our collection
            self.critical_states.append(critical_state)
            
            # Limit the number of stored critical states
            if len(self.critical_states) > 100:
                self.critical_states = self.critical_states[-100:]
                
            # Create the mixed initial state environment
            mixed_env = MixedInitialStateEnv(self.env, self.critical_states, self.reset_prob)
            
            # Update the environment of the refined agent
            self.refined_agent.env = mixed_env
            
            # Create the RND callback for exploration
            rnd_callback = RNDCallback(self.rnd, self.exploration_coef)
            
            # Train the refined agent for a few steps
            self.refined_agent.learn(
                total_timesteps=1000,  # Small number of steps per iteration
                callback=rnd_callback,
                reset_num_timesteps=False,
            )
        
        return self.refined_agent
