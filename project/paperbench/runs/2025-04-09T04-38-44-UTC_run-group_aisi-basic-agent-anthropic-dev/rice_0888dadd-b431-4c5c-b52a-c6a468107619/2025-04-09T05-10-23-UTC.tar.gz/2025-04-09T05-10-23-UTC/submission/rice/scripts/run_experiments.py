#!/usr/bin/env python3

import os
import argparse
import subprocess
import time
from datetime import datetime

def parse_args():
    parser = argparse.ArgumentParser(description='Run RICE experiments across all environments')
    
    parser.add_argument('--output-dir', type=str, default='./results',
                        help='Directory to save results')
    
    parser.add_argument('--num-timesteps', type=int, default=50000,
                        help='Number of timesteps to train for each stage')
    
    parser.add_argument('--environments', type=str, default='all',
                        help='Comma-separated list of environments to run, or "all" for all environments')
    
    parser.add_argument('--skip-training', action='store_true',
                        help='Skip the training phase and use pre-trained models')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    parser.add_argument('--visualize', action='store_true',
                        help='Visualize results after experiments')
    
    return parser.parse_args()

def main():
    args = parse_args()
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Define all available environments
    all_environments = [
        'hopper',
        'walker2d',
        'reacher',
        'halfcheetah',
        'sparse_hopper',
        'sparse_walker2d',
        'sparse_halfcheetah',
        'selfish_mining',
        'network_defense',
        'auto_driving'
    ]
    
    # Determine which environments to run
    if args.environments == 'all':
        environments = all_environments
    else:
        environments = [env.strip() for env in args.environments.split(',')]
        # Validate environments
        for env in environments:
            if env not in all_environments:
                print(f"Warning: Unknown environment '{env}', skipping")
                environments.remove(env)
    
    print(f"Running experiments on the following environments: {', '.join(environments)}")
    print(f"Output directory: {args.output_dir}")
    print(f"Number of timesteps per stage: {args.num_timesteps}")
    print(f"Seed: {args.seed}")
    
    # Record start time
    start_time = time.time()
    
    # Create a log file
    log_file = os.path.join(args.output_dir, 'experiment_log.txt')
    with open(log_file, 'w') as f:
        f.write(f"RICE Experiments Log - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Environments: {', '.join(environments)}\n")
        f.write(f"Number of timesteps per stage: {args.num_timesteps}\n")
        f.write(f"Seed: {args.seed}\n\n")
    
    # Run experiments for each environment
    for env_name in environments:
        env_start_time = time.time()
        print(f"\n{'='*80}\nRunning experiments for {env_name}\n{'='*80}")
        
        # Create environment-specific output directory
        env_output_dir = os.path.join(args.output_dir, env_name)
        os.makedirs(env_output_dir, exist_ok=True)
        
        # Log environment start
        with open(log_file, 'a') as f:
            f.write(f"\n{'='*50}\nStarting {env_name} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{'='*50}\n")
        
        # Run the run_rice.py script
        run_cmd = [
            'python', '-m', 'rice.scripts.run_rice',
            '--env', env_name,
            '--output-dir', env_output_dir,
            '--seed', str(args.seed)
        ]
        
        if args.skip_training:
            run_cmd.append('--skip-training')
            run_cmd.extend(['--agent-path', os.path.join(env_output_dir, f"{env_name}_agent.zip")])
            run_cmd.extend(['--mask-path', os.path.join(env_output_dir, f"{env_name}_mask.pt")])
        
        print(f"Running command: {' '.join(run_cmd)}")
        
        try:
            # Run the command and capture output
            process = subprocess.Popen(run_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            
            # Stream the output to console and log file
            with open(os.path.join(env_output_dir, 'run_log.txt'), 'w') as log:
                for line in process.stdout:
                    print(line.strip())
                    log.write(line)
            
            process.wait()
            
            if process.returncode != 0:
                print(f"Error running experiments for {env_name}. Check the log file for details.")
                with open(log_file, 'a') as f:
                    f.write(f"Error running experiments for {env_name}. Return code: {process.returncode}\n")
        except Exception as e:
            print(f"Exception while running experiments for {env_name}: {str(e)}")
            with open(log_file, 'a') as f:
                f.write(f"Exception while running experiments for {env_name}: {str(e)}\n")
        
        # Log environment completion
        env_elapsed_time = time.time() - env_start_time
        with open(log_file, 'a') as f:
            f.write(f"Completed {env_name} in {env_elapsed_time:.2f} seconds\n")
        
        print(f"Completed experiments for {env_name} in {env_elapsed_time:.2f} seconds")
        
        # Run the compare_refining.py script to compare different refining methods
        print(f"\nComparing refining methods for {env_name}...")
        
        compare_cmd = [
            'python', '-m', 'rice.scripts.compare_refining',
            '--env', env_name,
            '--agent-path', os.path.join(env_output_dir, f"{env_name}_agent.zip"),
            '--mask-path', os.path.join(env_output_dir, f"{env_name}_mask.pt"),
            '--timesteps', str(args.num_timesteps),
            '--output-dir', os.path.join(env_output_dir, 'refining_comparison'),
            '--seed', str(args.seed)
        ]
        
        print(f"Running command: {' '.join(compare_cmd)}")
        
        try:
            # Run the command and capture output
            process = subprocess.Popen(compare_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            
            # Stream the output to console and log file
            with open(os.path.join(env_output_dir, 'compare_log.txt'), 'w') as log:
                for line in process.stdout:
                    print(line.strip())
                    log.write(line)
            
            process.wait()
            
            if process.returncode != 0:
                print(f"Error comparing refining methods for {env_name}. Check the log file for details.")
                with open(log_file, 'a') as f:
                    f.write(f"Error comparing refining methods for {env_name}. Return code: {process.returncode}\n")
        except Exception as e:
            print(f"Exception while comparing refining methods for {env_name}: {str(e)}")
            with open(log_file, 'a') as f:
                f.write(f"Exception while comparing refining methods for {env_name}: {str(e)}\n")
        
        # Run the test_fidelity.py script to evaluate explanation fidelity
        print(f"\nTesting explanation fidelity for {env_name}...")
        
        fidelity_cmd = [
            'python', '-m', 'rice.scripts.test_fidelity',
            '--env', env_name,
            '--agent-path', os.path.join(env_output_dir, f"{env_name}_agent.zip"),
            '--mask-path', os.path.join(env_output_dir, f"{env_name}_mask.pt"),
            '--train-timesteps', str(args.num_timesteps // 2),  # Fewer timesteps for mask training
            '--output-dir', os.path.join(env_output_dir, 'fidelity_results'),
            '--n-trajectories', '5',  # Fewer trajectories for faster evaluation
            '--seed', str(args.seed)
        ]
        
        print(f"Running command: {' '.join(fidelity_cmd)}")
        
        try:
            # Run the command and capture output
            process = subprocess.Popen(fidelity_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            
            # Stream the output to console and log file
            with open(os.path.join(env_output_dir, 'fidelity_log.txt'), 'w') as log:
                for line in process.stdout:
                    print(line.strip())
                    log.write(line)
            
            process.wait()
            
            if process.returncode != 0:
                print(f"Error testing fidelity for {env_name}. Check the log file for details.")
                with open(log_file, 'a') as f:
                    f.write(f"Error testing fidelity for {env_name}. Return code: {process.returncode}\n")
        except Exception as e:
            print(f"Exception while testing fidelity for {env_name}: {str(e)}")
            with open(log_file, 'a') as f:
                f.write(f"Exception while testing fidelity for {env_name}: {str(e)}\n")
    
    # Record end time
    total_elapsed_time = time.time() - start_time
    print(f"\n{'='*80}")
    print(f"All experiments completed in {total_elapsed_time:.2f} seconds")
    print(f"Results saved to {args.output_dir}")
    
    with open(log_file, 'a') as f:
        f.write(f"\n{'='*50}\nAll experiments completed in {total_elapsed_time:.2f} seconds\n")
    
    # Visualize results if requested
    if args.visualize:
        print("\nVisualizing results...")
        
        visualize_cmd = [
            'python', '-m', 'rice.scripts.visualize_results',
            '--results-dir', args.output_dir,
            '--output-dir', os.path.join(args.output_dir, 'figures'),
            '--figure-type', 'all'
        ]
        
        print(f"Running command: {' '.join(visualize_cmd)}")
        
        try:
            # Run the command and capture output
            process = subprocess.run(visualize_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            
            print(process.stdout)
            
            if process.returncode != 0:
                print(f"Error visualizing results. Check the log for details.")
                with open(log_file, 'a') as f:
                    f.write(f"Error visualizing results. Return code: {process.returncode}\n")
        except Exception as e:
            print(f"Exception while visualizing results: {str(e)}")
            with open(log_file, 'a') as f:
                f.write(f"Exception while visualizing results: {str(e)}\n")

if __name__ == "__main__":
    main()
