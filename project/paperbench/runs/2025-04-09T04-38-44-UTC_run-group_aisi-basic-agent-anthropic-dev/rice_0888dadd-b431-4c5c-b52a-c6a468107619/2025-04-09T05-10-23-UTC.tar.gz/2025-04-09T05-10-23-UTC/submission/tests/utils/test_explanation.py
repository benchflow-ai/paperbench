import os
import sys
import unittest
import numpy as np
import torch
import gymnasium as gym

from rice.utils.explanation import random_explanation, identify_critical_states, sliding_window
from rice.models.state_mask import MaskNetwork

class TestExplanationUtils(unittest.TestCase):
    def setUp(self):
        # Create a simple observation space for testing
        self.observation_space = gym.spaces.Box(
            low=-1.0, high=1.0, shape=(4,), dtype=np.float32
        )
        
        # Create a mask network
        self.mask_net = MaskNetwork(self.observation_space)
    
    def test_random_explanation(self):
        # Test random explanation with a list of states
        states = np.random.uniform(-1, 1, size=(10, 4))
        
        # Generate random explanation
        importance_scores = random_explanation(states)
        
        # Check that importance scores have the right shape
        self.assertEqual(len(importance_scores), len(states))
        
        # Check that importance scores are between 0 and 1
        self.assertTrue(np.all((importance_scores >= 0) & (importance_scores <= 1)))
    
    def test_identify_critical_states(self):
        # Test identifying critical states with a list of states
        states = np.random.uniform(-1, 1, size=(10, 4))
        
        # Identify critical states
        importance_scores = identify_critical_states(states, self.mask_net)
        
        # Check that importance scores have the right shape
        self.assertEqual(len(importance_scores), len(states))
        
        # Check that importance scores are between 0 and 1
        self.assertTrue(np.all((importance_scores >= 0) & (importance_scores <= 1)))
    
    def test_sliding_window(self):
        # Test sliding window
        importance_scores = [0.1, 0.2, 0.8, 0.9, 0.7, 0.3, 0.2, 0.1, 0.2, 0.3]
        
        # Find the window with the highest average score
        start_idx, end_idx = sliding_window(importance_scores, window_size=3)
        
        # The most important segment should be [0.8, 0.9, 0.7]
        self.assertEqual(start_idx, 2)
        self.assertEqual(end_idx, 5)
        
        # Test with a different window size
        start_idx, end_idx = sliding_window(importance_scores, window_size=2)
        
        # The most important segment should be [0.8, 0.9]
        self.assertEqual(start_idx, 2)
        self.assertEqual(end_idx, 4)
        
        # Test with a window size larger than the list
        start_idx, end_idx = sliding_window(importance_scores, window_size=15)
        
        # Should return the whole list
        self.assertEqual(start_idx, 0)
        self.assertEqual(end_idx, len(importance_scores))

if __name__ == '__main__':
    unittest.main()
