#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
import gymnasium as gym
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.callbacks import BaseCallback

class SaveRewardCallback(BaseCallback):
    """
    Callback for saving reward history during training.
    """
    def __init__(self, check_freq=1000, log_dir=None, verbose=1):
        super(SaveRewardCallback, self).__init__(verbose)
        self.check_freq = check_freq
        self.log_dir = log_dir
        self.rewards = []
        self.timesteps = []
        self.episode_rewards = []
        self.current_episode_reward = 0
        
        if log_dir is not None:
            os.makedirs(log_dir, exist_ok=True)
    
    def _on_step(self) -> bool:
        # Record reward for this step
        self.current_episode_reward += self.locals["rewards"][0]
        
        # If episode is done, record episode reward
        if self.locals["dones"][0]:
            self.episode_rewards.append(self.current_episode_reward)
            self.current_episode_reward = 0
        
        # Save reward history periodically
        if self.n_calls % self.check_freq == 0:
            # Calculate average reward over last check_freq steps
            if len(self.episode_rewards) > 0:
                avg_reward = np.mean(self.episode_rewards[-100:] if len(self.episode_rewards) >= 100 else self.episode_rewards)
                self.rewards.append(avg_reward)
                self.timesteps.append(self.n_calls)
                
                if self.log_dir is not None:
                    # Save reward history to file
                    np.save(os.path.join(self.log_dir, "rewards.npy"), np.array(self.rewards))
                    np.save(os.path.join(self.log_dir, "timesteps.npy"), np.array(self.timesteps))
                    
                    # Plot reward history
                    plt.figure(figsize=(10, 6))
                    plt.plot(self.timesteps, self.rewards)
                    plt.xlabel("Timesteps")
                    plt.ylabel("Average Episode Reward")
                    plt.title("Training Reward History")
                    plt.savefig(os.path.join(self.log_dir, "reward_history.png"))
                    plt.close()
        
        return True

def parse_args():
    parser = argparse.ArgumentParser(description='Generate training bottleneck examples')
    
    parser.add_argument('--env', type=str, default='sparse_hopper',
                        help='Environment to train on')
    
    parser.add_argument('--algorithm', type=str, default='PPO', choices=['PPO', 'SAC'],
                        help='RL algorithm to use')
    
    parser.add_argument('--timesteps', type=int, default=2000000,
                        help='Number of timesteps to train for')
    
    parser.add_argument('--check-freq', type=int, default=10000,
                        help='Frequency (in timesteps) to check and save rewards')
    
    parser.add_argument('--output-dir', type=str, default='./bottleneck_examples',
                        help='Directory to save results')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    try:
        # Try to import from rice environments first
        from rice.environments.mujoco_envs import create_env
        from rice.environments.selfish_mining import SelfishMiningEnv
        from rice.environments.network_defense import NetworkDefenseEnv
        from rice.environments.auto_driving import AutoDrivingEnv
        
        if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                        'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
            return create_env(env_name)
        elif env_name == 'selfish_mining':
            return SelfishMiningEnv()
        elif env_name == 'network_defense':
            return NetworkDefenseEnv()
        elif env_name == 'auto_driving':
            return AutoDrivingEnv()
        else:
            # Try standard Gym environment
            return gym.make(env_name)
    except ImportError:
        # If rice environments are not available, try standard Gym
        return gym.make(env_name)

def create_agent(algorithm, env, seed=0):
    """Create an agent with the specified algorithm"""
    if algorithm == 'PPO':
        return PPO(
            policy="MlpPolicy",
            env=env,
            learning_rate=3e-4,
            n_steps=2048,
            batch_size=64,
            n_epochs=10,
            gamma=0.99,
            gae_lambda=0.95,
            clip_range=0.2,
            verbose=1,
            seed=seed
        )
    elif algorithm == 'SAC':
        return SAC(
            policy="MlpPolicy",
            env=env,
            learning_rate=3e-4,
            buffer_size=1000000,
            batch_size=256,
            tau=0.005,
            gamma=0.99,
            train_freq=1,
            gradient_steps=1,
            verbose=1,
            seed=seed
        )
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

def detect_bottlenecks(rewards, timesteps, window_size=10):
    """
    Detect training bottlenecks by finding plateaus in the reward curve.
    
    A bottleneck is defined as a period where the reward doesn't improve significantly
    over a window of checkpoints.
    """
    if len(rewards) < window_size + 1:
        return []
    
    bottlenecks = []
    
    for i in range(len(rewards) - window_size):
        # Calculate improvement over the window
        start_reward = rewards[i]
        end_reward = rewards[i + window_size]
        improvement = (end_reward - start_reward) / abs(start_reward) if start_reward != 0 else end_reward
        
        # If improvement is less than 5%, consider it a bottleneck
        if abs(improvement) < 0.05:
            bottleneck = {
                'start_timestep': timesteps[i],
                'end_timestep': timesteps[i + window_size],
                'start_reward': start_reward,
                'end_reward': end_reward,
                'improvement': improvement
            }
            bottlenecks.append(bottleneck)
    
    # Merge adjacent bottlenecks
    merged_bottlenecks = []
    if bottlenecks:
        current_bottleneck = bottlenecks[0]
        
        for i in range(1, len(bottlenecks)):
            if bottlenecks[i]['start_timestep'] <= current_bottleneck['end_timestep']:
                # Merge bottlenecks
                current_bottleneck['end_timestep'] = bottlenecks[i]['end_timestep']
                current_bottleneck['end_reward'] = bottlenecks[i]['end_reward']
            else:
                # Add current bottleneck and start a new one
                merged_bottlenecks.append(current_bottleneck)
                current_bottleneck = bottlenecks[i]
        
        merged_bottlenecks.append(current_bottleneck)
    
    return merged_bottlenecks

def plot_bottlenecks(rewards, timesteps, bottlenecks, output_dir):
    """Plot reward curve with highlighted bottlenecks"""
    plt.figure(figsize=(12, 6))
    
    # Plot reward curve
    plt.plot(timesteps, rewards, label='Reward')
    
    # Highlight bottlenecks
    for i, bottleneck in enumerate(bottlenecks):
        plt.axvspan(
            bottleneck['start_timestep'],
            bottleneck['end_timestep'],
            alpha=0.3,
            color=f'C{(i % 9) + 1}',
            label=f'Bottleneck {i+1}'
        )
    
    plt.xlabel('Timesteps')
    plt.ylabel('Average Episode Reward')
    plt.title('Training Reward History with Bottlenecks')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # Save figure
    plt.savefig(os.path.join(output_dir, 'bottlenecks.png'), dpi=300)
    plt.close()

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create output directory
    env_output_dir = os.path.join(args.output_dir, args.env, args.algorithm)
    os.makedirs(env_output_dir, exist_ok=True)
    
    # Create environment
    env = create_environment(args.env)
    
    # Create agent
    agent = create_agent(args.algorithm, env, args.seed)
    
    # Create callback
    callback = SaveRewardCallback(check_freq=args.check_freq, log_dir=env_output_dir)
    
    # Train agent
    print(f"Training {args.algorithm} agent on {args.env} for {args.timesteps} timesteps...")
    agent.learn(total_timesteps=args.timesteps, callback=callback)
    
    # Save agent
    agent.save(os.path.join(env_output_dir, "agent.zip"))
    
    # Detect bottlenecks
    bottlenecks = detect_bottlenecks(callback.rewards, callback.timesteps)
    
    # Plot bottlenecks
    plot_bottlenecks(callback.rewards, callback.timesteps, bottlenecks, env_output_dir)
    
    # Save bottlenecks
    bottlenecks_file = os.path.join(env_output_dir, "bottlenecks.txt")
    with open(bottlenecks_file, "w") as f:
        f.write(f"Detected {len(bottlenecks)} bottlenecks:\n\n")
        
        for i, bottleneck in enumerate(bottlenecks):
            f.write(f"Bottleneck {i+1}:\n")
            f.write(f"  Start timestep: {bottleneck['start_timestep']}\n")
            f.write(f"  End timestep: {bottleneck['end_timestep']}\n")
            f.write(f"  Start reward: {bottleneck['start_reward']:.2f}\n")
            f.write(f"  End reward: {bottleneck['end_reward']:.2f}\n")
            f.write(f"  Improvement: {bottleneck['improvement'] * 100:.2f}%\n\n")
    
    print(f"Training complete. Results saved to {env_output_dir}")
    print(f"Detected {len(bottlenecks)} bottlenecks. See {bottlenecks_file} for details.")

if __name__ == "__main__":
    main()
