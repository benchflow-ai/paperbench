import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from stable_baselines3.common.buffers import RolloutBuffer

class MaskNetwork(nn.Module):
    """
    The mask network implementation based on the improved StateMask from the paper.
    
    The mask network takes a state as input and outputs the probability of masking
    (blinding) the agent's action at that state. A high probability indicates that
    the state is not critical, while a low probability indicates that the state is
    critical to the agent's performance.
    """
    def __init__(self, observation_space, hidden_sizes=[64, 64]):
        super(MaskNetwork, self).__init__()
        
        # Determine input size from observation space
        if len(observation_space.shape) == 1:
            input_dim = observation_space.shape[0]
        else:
            # For image observations, would need a CNN architecture
            # For simplicity, we'll assume vector observations
            input_dim = np.prod(observation_space.shape)
        
        # Create the network layers
        layers = []
        prev_size = input_dim
        
        for size in hidden_sizes:
            layers.append(nn.Linear(prev_size, size))
            layers.append(nn.ReLU())
            prev_size = size
            
        # Output layer with sigmoid activation
        layers.append(nn.Linear(prev_size, 1))
        layers.append(nn.Sigmoid())
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        # Convert input to tensor if it's not already
        if not isinstance(x, torch.Tensor):
            x = torch.FloatTensor(x)
            
        # Ensure the input has the right shape
        if len(x.shape) == 1:
            x = x.unsqueeze(0)
            
        # Pass through network and return the probability
        return self.network(x)
    
    def sample_action(self, state, deterministic=False):
        """
        Sample a binary action (0 or 1) based on the mask network's output.
        0 means 'don't mask' (state is critical)
        1 means 'mask' (state is not critical)
        """
        prob = self.forward(state)
        
        if deterministic:
            # For deterministic action, choose 1 if prob > 0.5, else 0
            action = (prob > 0.5).float()
        else:
            # For stochastic action, sample from Bernoulli distribution
            dist = torch.distributions.Bernoulli(prob)
            action = dist.sample()
            
        return action, prob


class ImprovedStateMask:
    """
    Implementation of the improved StateMask method from the paper.
    
    Key improvements:
    1. Reformulated objective function to maximize expected reward with masking
    2. Added reward bonus for encouraging blinding
    """
    def __init__(
        self,
        target_agent,
        observation_space,
        action_space,
        device="cpu",
        mask_bonus=0.01,
        learning_rate=3e-4,
        hidden_sizes=[64, 64],
    ):
        self.target_agent = target_agent
        self.observation_space = observation_space
        self.action_space = action_space
        self.device = device
        self.mask_bonus = mask_bonus  # Hyperparameter α from the paper
        
        # Initialize the mask network
        self.mask_net = MaskNetwork(observation_space, hidden_sizes).to(device)
        self.optimizer = optim.Adam(self.mask_net.parameters(), lr=learning_rate)
        
    def train(self, env, total_timesteps=10000, batch_size=64, n_steps=2048, gamma=0.99):
        """
        Train the mask network according to Algorithm 1 in the paper.
        
        The goal is to learn when to mask (blind) the target agent's actions
        without significantly affecting the overall performance.
        """
        # Initialize buffer for storing rollouts
        buffer = RolloutBuffer(
            buffer_size=n_steps,
            observation_space=self.observation_space,
            action_space=torch.distributions.bernoulli.Bernoulli.arg_constraints['probs'].space,
            device=self.device,
            gamma=gamma,
            gae_lambda=0.95,
            n_envs=1
        )
        
        # Training loop
        timestep = 0
        while timestep < total_timesteps:
            # Reset environment
            obs, _ = env.reset()
            
            # Rollout phase
            for step in range(n_steps):
                with torch.no_grad():
                    # Get the target agent's action
                    target_action, _ = self.target_agent.predict(obs, deterministic=False)
                    
                    # Get the mask action (0 or 1)
                    mask_obs = torch.FloatTensor(obs).to(self.device)
                    mask_action, mask_prob = self.mask_net.sample_action(mask_obs)
                    
                    # Combine actions: if mask=1, use random action; if mask=0, use target action
                    if mask_action.item() == 1:
                        # Mask the action (use a random action)
                        final_action = env.action_space.sample()
                    else:
                        # Don't mask (use the target agent's action)
                        final_action = target_action
                    
                    # Step the environment
                    next_obs, reward, done, truncated, info = env.step(final_action)
                    
                    # Modify reward to encourage masking (add bonus for masking)
                    modified_reward = reward + self.mask_bonus * mask_action.item()
                    
                    # Store experience in buffer
                    buffer.add(obs, next_obs, mask_action.item(), modified_reward, done, 
                              {'mask_prob': mask_prob.item(), 'value': 0})
                    
                    # Update observation
                    obs = next_obs
                    
                    timestep += 1
                    
                    if done or truncated:
                        obs, _ = env.reset()
                        
                    if timestep >= total_timesteps:
                        break
            
            # Compute returns and advantages
            buffer.compute_returns_and_advantage()
            
            # Update phase (using PPO-like update)
            for epoch in range(10):  # Multiple epochs of optimization
                # Sample mini-batches
                for batch_idx in range(0, n_steps, batch_size):
                    batch_data = buffer.get(batch_idx, min(batch_idx + batch_size, n_steps))
                    
                    # Extract batch data
                    states = batch_data.observations
                    actions = batch_data.actions
                    returns = batch_data.returns
                    advantages = batch_data.advantages
                    
                    # Get current action probabilities
                    curr_probs = self.mask_net(states)
                    
                    # Calculate log probabilities
                    dist = torch.distributions.Bernoulli(curr_probs.squeeze())
                    log_probs = dist.log_prob(actions.float())
                    
                    # Get entropy for exploration
                    entropy = dist.entropy().mean()
                    
                    # Compute policy loss (using PPO clip objective)
                    ratio = torch.exp(log_probs - batch_data.old_log_prob)
                    clip_range = 0.2
                    policy_loss1 = advantages * ratio
                    policy_loss2 = advantages * torch.clamp(ratio, 1 - clip_range, 1 + clip_range)
                    policy_loss = -torch.min(policy_loss1, policy_loss2).mean()
                    
                    # Compute entropy loss to encourage exploration
                    entropy_loss = -0.01 * entropy
                    
                    # Total loss
                    loss = policy_loss + entropy_loss
                    
                    # Optimize
                    self.optimizer.zero_grad()
                    loss.backward()
                    self.optimizer.step()
            
            # Clear the buffer for the next iteration
            buffer.reset()
            
        return self.mask_net
    
    def explain(self, states):
        """
        Generate explanations for a sequence of states.
        
        Returns the importance scores for each state, where a higher score
        indicates a more critical state (less likely to be masked).
        """
        with torch.no_grad():
            # Convert states to tensor
            if not isinstance(states, torch.Tensor):
                states = torch.FloatTensor(states).to(self.device)
                
            # Get mask probabilities
            mask_probs = self.mask_net(states)
            
            # Importance scores are (1 - mask_prob)
            # Higher scores mean the state is more critical
            importance_scores = 1 - mask_probs.squeeze().cpu().numpy()
            
            return importance_scores
