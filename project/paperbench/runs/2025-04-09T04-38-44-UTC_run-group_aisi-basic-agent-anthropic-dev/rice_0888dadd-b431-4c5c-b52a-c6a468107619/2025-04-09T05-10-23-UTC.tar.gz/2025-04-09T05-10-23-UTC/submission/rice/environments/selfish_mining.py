import gymnasium as gym
from gymnasium import spaces
import numpy as np

class SelfishMiningEnv(gym.Env):
    """
    Selfish Mining Environment based on the paper.
    
    In selfish mining, a miner can choose to either mine on the public chain
    or keep their blocks private. The goal is to maximize the proportion of
    blocks in the final blockchain.
    
    This is a simplified version based on the description in the paper.
    """
    def __init__(self, max_steps=1000, alpha=0.3, gamma=0.0):
        super(SelfishMiningEnv, self).__init__()
        
        # alpha: the computational power of the selfish miner (fraction of total hash power)
        self.alpha = alpha
        
        # gamma: the fraction of honest miners that mine on the selfish chain when a tie occurs
        self.gamma = gamma
        
        # Maximum number of steps per episode
        self.max_steps = max_steps
        
        # State: [lead, fork status (0/1), next_to_reveal]
        # lead: difference between private and public chain lengths
        # fork status: 0 (no fork) or 1 (fork exists)
        # next_to_reveal: the number of blocks to be revealed next
        self.observation_space = spaces.Box(
            low=np.array([0, 0, 0]),
            high=np.array([100, 1, 100]),
            dtype=np.float32
        )
        
        # Action space: 0 (adopt) or 1 (override)
        self.action_space = spaces.Discrete(2)
        
        # Initialize state
        self.lead = 0
        self.fork = 0
        self.next_to_reveal = 0
        
        # Tracking rewards
        self.selfish_blocks = 0
        self.honest_blocks = 0
        self.steps = 0
        
    def reset(self, seed=None):
        """Reset the environment to initial state"""
        super().reset(seed=seed)
        
        self.lead = 0
        self.fork = 0
        self.next_to_reveal = 0
        
        self.selfish_blocks = 0
        self.honest_blocks = 0
        self.steps = 0
        
        # Return initial state
        return np.array([self.lead, self.fork, self.next_to_reveal], dtype=np.float32), {}
    
    def step(self, action):
        """
        Take a step in the environment with the given action.
        
        Actions:
        - 0: Adopt (mine on the public chain)
        - 1: Override (mine on the private chain)
        
        Returns:
            obs: New state
            reward: Reward for this step
            terminated: Whether the episode is over
            truncated: Whether the episode is truncated
            info: Additional information
        """
        self.steps += 1
        
        # Check if action is valid
        if action not in [0, 1]:
            raise ValueError(f"Invalid action: {action}")
        
        # Process the action based on the current state
        reward = 0
        
        if action == 0:  # Adopt
            if self.lead > 0:
                # Adopt the public chain, publish private chain
                reward = self.lead / (self.lead + self.honest_blocks) if (self.lead + self.honest_blocks) > 0 else 0
                self.selfish_blocks += self.lead
                self.lead = 0
                self.fork = 0
                self.next_to_reveal = 0
            else:
                # Mine on public chain
                if np.random.random() < self.alpha:
                    # Selfish miner finds a block
                    self.lead += 1
                else:
                    # Honest miners find a block
                    self.honest_blocks += 1
        
        else:  # Override
            if self.lead > 0:
                # Continue mining on private chain
                if np.random.random() < self.alpha:
                    # Selfish miner finds a block
                    self.lead += 1
                else:
                    # Honest miners find a block
                    if self.lead == 1:
                        # A fork occurs
                        self.fork = 1
                        
                        # With probability gamma, honest miners mine on selfish chain
                        if np.random.random() < self.gamma:
                            self.lead += 1
                        else:
                            self.lead -= 1
                            self.honest_blocks += 1
                            self.fork = 0
                    else:
                        # Honest miners extend public chain
                        self.lead -= 1
            else:
                # Cannot override with no lead
                reward = -0.1  # Penalty for invalid action
        
        # Calculate reward at the end of episode
        if self.steps >= self.max_steps:
            # Final reward is the proportion of blocks in the blockchain
            total_blocks = self.selfish_blocks + self.honest_blocks
            reward = self.selfish_blocks / total_blocks if total_blocks > 0 else 0
        
        # Check if episode is over
        terminated = self.steps >= self.max_steps
        truncated = False
        
        # Create new observation
        obs = np.array([self.lead, self.fork, self.next_to_reveal], dtype=np.float32)
        
        # Additional info
        info = {
            'selfish_blocks': self.selfish_blocks,
            'honest_blocks': self.honest_blocks,
            'lead': self.lead,
            'fork': self.fork,
        }
        
        return obs, reward, terminated, truncated, info
    
    def render(self):
        """Render the environment (simple text-based output)"""
        print(f"Step: {self.steps}")
        print(f"Lead: {self.lead}")
        print(f"Fork: {self.fork}")
        print(f"Selfish blocks: {self.selfish_blocks}")
        print(f"Honest blocks: {self.honest_blocks}")
        
    def close(self):
        """Close the environment"""
        pass
