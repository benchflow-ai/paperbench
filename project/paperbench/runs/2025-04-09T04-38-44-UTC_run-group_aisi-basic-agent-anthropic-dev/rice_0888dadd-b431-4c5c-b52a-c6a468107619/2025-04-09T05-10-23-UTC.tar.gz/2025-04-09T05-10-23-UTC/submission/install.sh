#!/bin/bash

# RICE Installation Script

echo "Installing RICE and dependencies..."

# Create a virtual environment (optional)
if [ "$1" == "--venv" ]; then
    echo "Creating virtual environment..."
    python -m venv rice_venv
    source rice_venv/bin/activate
    echo "Virtual environment created and activated."
fi

# Install base dependencies
echo "Installing base dependencies..."
pip install -U pip setuptools wheel
pip install numpy torch gymnasium stable-baselines3 matplotlib seaborn pandas

# Install MuJoCo dependencies
echo "Installing MuJoCo dependencies..."
pip install 'gymnasium[mujoco]'

# Install the RICE package
echo "Installing RICE package..."
pip install -e .

echo "Installation complete!"
echo "To run a minimal example, use: python -m rice.scripts.minimal_example"
echo "To see all available commands, run: make help"
