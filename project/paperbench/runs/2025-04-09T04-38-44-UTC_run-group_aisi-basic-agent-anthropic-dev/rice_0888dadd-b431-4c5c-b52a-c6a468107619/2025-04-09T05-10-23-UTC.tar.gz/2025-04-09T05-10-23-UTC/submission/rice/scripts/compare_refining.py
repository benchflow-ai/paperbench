#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.callbacks import BaseCallback

from rice.models.state_mask import MaskNetwork
from rice.models.rice import RICE
from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv
from rice.utils.rnd import RND

def parse_args():
    parser = argparse.ArgumentParser(description='Compare different refining methods')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to test on')
    
    parser.add_argument('--agent-path', type=str, required=True,
                        help='Path to pre-trained agent')
    
    parser.add_argument('--mask-path', type=str, required=True,
                        help='Path to trained mask network')
    
    parser.add_argument('--algorithm', type=str, default='PPO', choices=['PPO', 'SAC'],
                        help='Algorithm used for the pre-trained agent')
    
    parser.add_argument('--timesteps', type=int, default=100000,
                        help='Number of timesteps to run each refining method')
    
    parser.add_argument('--reset-prob', type=float, default=0.5,
                        help='Probability p of resetting to critical states for RICE')
    
    parser.add_argument('--exploration-coef', type=float, default=0.01,
                        help='Coefficient λ for the RND exploration bonus for RICE')
    
    parser.add_argument('--output-dir', type=str, default='./refining_comparison',
                        help='Directory to save results')
    
    parser.add_argument('--eval-interval', type=int, default=10000,
                        help='Interval (in timesteps) between evaluations')
    
    parser.add_argument('--n-eval-episodes', type=int, default=5,
                        help='Number of episodes for each evaluation')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, algorithm, env):
    """Load a pre-trained agent"""
    if algorithm == 'PPO':
        return PPO.load(agent_path, env=env)
    elif algorithm == 'SAC':
        return SAC.load(agent_path, env=env)
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

def load_mask_network(mask_path, observation_space):
    """Load a trained mask network"""
    # Create mask network with the same architecture
    mask_net = MaskNetwork(observation_space)
    
    # Load weights
    mask_net.load_state_dict(torch.load(mask_path))
    
    return mask_net

def evaluate_agent(agent, env, n_episodes=5):
    """Evaluate an agent's performance"""
    rewards = []
    
    for _ in range(n_episodes):
        obs, _ = env.reset()
        done = False
        total_reward = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            done = terminated or truncated
            
        rewards.append(total_reward)
    
    return np.mean(rewards)

class EvalCallback(BaseCallback):
    """
    Callback for evaluating and tracking an agent's performance during training.
    """
    def __init__(self, eval_env, n_eval_episodes=5, eval_freq=10000, verbose=1):
        super(EvalCallback, self).__init__(verbose)
        self.eval_env = eval_env
        self.n_eval_episodes = n_eval_episodes
        self.eval_freq = eval_freq
        self.evaluations_rewards = []
        self.evaluations_timesteps = []
        
    def _on_step(self) -> bool:
        if self.n_calls % self.eval_freq == 0:
            mean_reward = evaluate_agent(self.model, self.eval_env, self.n_eval_episodes)
            self.evaluations_rewards.append(mean_reward)
            self.evaluations_timesteps.append(self.n_calls)
            if self.verbose > 0:
                print(f"Step {self.n_calls}: mean reward = {mean_reward:.2f}")
        return True

def refine_ppo_finetuning(agent, env, timesteps, eval_callback):
    """
    Refine the agent using PPO fine-tuning.
    """
    # Clone the agent and continue training with a lower learning rate
    refined_agent = PPO(
        policy="MlpPolicy",
        env=env,
        learning_rate=1e-4,  # Lower learning rate for fine-tuning
        n_steps=2048,
        batch_size=64,
        n_epochs=10,
        gamma=0.99,
        gae_lambda=0.95,
        clip_range=0.2,
        verbose=0,
    )
    
    # Copy the weights from the pre-trained agent
    refined_agent.policy.load_state_dict(agent.policy.state_dict())
    
    # Continue training
    refined_agent.learn(total_timesteps=timesteps, callback=eval_callback)
    
    return refined_agent, eval_callback.evaluations_rewards, eval_callback.evaluations_timesteps

def refine_statemask_reset(agent, env, mask_net, timesteps, eval_callback):
    """
    Refine the agent using StateMask's approach of resetting to critical states.
    """
    # Create a custom environment wrapper for resetting to critical states
    class CriticalStateEnv:
        def __init__(self, env, agent, mask_net):
            self.env = env
            self.agent = agent
            self.mask_net = mask_net
            self.observation_space = env.observation_space
            self.action_space = env.action_space
            self.critical_states = []
            
        def collect_critical_states(self, n=10):
            for _ in range(n):
                # Collect a trajectory
                obs, _ = self.env.reset()
                states = [obs]
                done = False
                
                while not done:
                    action, _ = self.agent.predict(obs, deterministic=False)
                    next_obs, _, terminated, truncated, _ = self.env.step(action)
                    states.append(next_obs)
                    obs = next_obs
                    done = terminated or truncated
                
                # Identify the most critical state
                if len(states) > 1:
                    states_tensor = torch.FloatTensor(states)
                    importance_scores = 1 - self.mask_net(states_tensor).squeeze().detach().numpy()
                    critical_idx = np.argmax(importance_scores)
                    self.critical_states.append(states[critical_idx])
            
        def reset(self):
            # Always reset to a critical state if available
            if len(self.critical_states) > 0:
                # Use a random critical state
                critical_state = np.random.choice(self.critical_states)
                # For simplicity, we'll just set the observation
                # In a real implementation, we'd need to set the full environment state
                return critical_state, {}
            else:
                # Fall back to regular reset if no critical states collected yet
                return self.env.reset()
            
        def step(self, action):
            return self.env.step(action)
    
    # Create the custom environment
    critical_env = CriticalStateEnv(env, agent, mask_net)
    
    # Collect critical states
    critical_env.collect_critical_states(n=20)
    
    # Clone the agent
    refined_agent = PPO(
        policy="MlpPolicy",
        env=critical_env,
        learning_rate=3e-4,
        n_steps=2048,
        batch_size=64,
        n_epochs=10,
        gamma=0.99,
        verbose=0,
    )
    
    # Copy the weights from the pre-trained agent
    refined_agent.policy.load_state_dict(agent.policy.state_dict())
    
    # Continue training
    refined_agent.learn(total_timesteps=timesteps, callback=eval_callback)
    
    return refined_agent, eval_callback.evaluations_rewards, eval_callback.evaluations_timesteps

def refine_rice(agent, env, mask_net, timesteps, reset_prob, exploration_coef, eval_callback):
    """
    Refine the agent using our RICE method.
    """
    # Create RICE instance
    rice = RICE(
        pretrained_agent=agent,
        mask_net=mask_net,
        env=env,
        reset_prob=reset_prob,
        exploration_coef=exploration_coef,
    )
    
    # Set up a modified callback that can access the RICE instance's refined agent
    class RICEEvalCallback(BaseCallback):
        def __init__(self, rice_instance, eval_env, n_eval_episodes=5, eval_freq=10000, verbose=1):
            super(RICEEvalCallback, self).__init__(verbose)
            self.rice_instance = rice_instance
            self.eval_env = eval_env
            self.n_eval_episodes = n_eval_episodes
            self.eval_freq = eval_freq
            self.evaluations_rewards = []
            self.evaluations_timesteps = []
            self.last_eval_time = 0
            
        def _on_step(self) -> bool:
            # Check if enough time has passed since last evaluation
            if self.n_calls - self.last_eval_time >= self.eval_freq:
                mean_reward = evaluate_agent(self.rice_instance.refined_agent, self.eval_env, self.n_eval_episodes)
                self.evaluations_rewards.append(mean_reward)
                self.evaluations_timesteps.append(self.n_calls)
                self.last_eval_time = self.n_calls
                if self.verbose > 0:
                    print(f"Step {self.n_calls}: mean reward = {mean_reward:.2f}")
            return True
    
    # Create the RICE evaluation callback
    rice_eval_callback = RICEEvalCallback(
        rice_instance=rice,
        eval_env=env,
        n_eval_episodes=eval_callback.n_eval_episodes,
        eval_freq=eval_callback.eval_freq,
        verbose=eval_callback.verbose
    )
    
    # Refine the agent using RICE
    # The RICE refine method will use our callback internally
    refined_agent = rice.refine(total_timesteps=timesteps)
    
    return refined_agent, rice_eval_callback.evaluations_rewards, rice_eval_callback.evaluations_timesteps

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create environment
    env = create_environment(args.env)
    eval_env = create_environment(args.env)  # Separate env for evaluation
    
    # Load pre-trained agent
    agent = load_agent(args.agent_path, args.algorithm, env)
    
    # Load mask network
    mask_net = load_mask_network(args.mask_path, env.observation_space)
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Evaluate the original agent
    original_performance = evaluate_agent(agent, eval_env, args.n_eval_episodes)
    print(f"Original agent performance: {original_performance:.2f}")
    
    # Create evaluation callbacks
    ppo_eval_callback = EvalCallback(
        eval_env=eval_env,
        n_eval_episodes=args.n_eval_episodes,
        eval_freq=args.eval_interval,
        verbose=1
    )
    
    statemask_eval_callback = EvalCallback(
        eval_env=eval_env,
        n_eval_episodes=args.n_eval_episodes,
        eval_freq=args.eval_interval,
        verbose=1
    )
    
    rice_eval_callback = EvalCallback(
        eval_env=eval_env,
        n_eval_episodes=args.n_eval_episodes,
        eval_freq=args.eval_interval,
        verbose=1
    )
    
    # Dictionary to store results
    results = {
        'original': original_performance,
        'ppo_finetuning': {
            'agent': None,
            'rewards': [],
            'timesteps': []
        },
        'statemask_reset': {
            'agent': None,
            'rewards': [],
            'timesteps': []
        },
        'rice': {
            'agent': None,
            'rewards': [],
            'timesteps': []
        }
    }
    
    # Refine using PPO fine-tuning
    print("\nRefining with PPO fine-tuning...")
    results['ppo_finetuning']['agent'], results['ppo_finetuning']['rewards'], results['ppo_finetuning']['timesteps'] = (
        refine_ppo_finetuning(agent, env, args.timesteps, ppo_eval_callback)
    )
    
    # Refine using StateMask's reset approach
    print("\nRefining with StateMask reset...")
    results['statemask_reset']['agent'], results['statemask_reset']['rewards'], results['statemask_reset']['timesteps'] = (
        refine_statemask_reset(agent, env, mask_net, args.timesteps, statemask_eval_callback)
    )
    
    # Refine using RICE
    print("\nRefining with RICE...")
    results['rice']['agent'], results['rice']['rewards'], results['rice']['timesteps'] = (
        refine_rice(agent, env, mask_net, args.timesteps, args.reset_prob, args.exploration_coef, rice_eval_callback)
    )
    
    # Evaluate final performance
    print("\nFinal performance evaluation:")
    final_results = {
        'original': original_performance,
        'ppo_finetuning': evaluate_agent(results['ppo_finetuning']['agent'], eval_env, args.n_eval_episodes),
        'statemask_reset': evaluate_agent(results['statemask_reset']['agent'], eval_env, args.n_eval_episodes),
        'rice': evaluate_agent(results['rice']['agent'], eval_env, args.n_eval_episodes),
    }
    
    for method, reward in final_results.items():
        if method == 'original':
            print(f"{method}: {reward:.2f}")
        else:
            improvement = ((reward - original_performance) / abs(original_performance)) * 100
            print(f"{method}: {reward:.2f} (improvement: {improvement:.2f}%)")
    
    # Plot learning curves
    plt.figure(figsize=(10, 6))
    
    plt.axhline(y=original_performance, color='r', linestyle='-', label='Original')
    
    plt.plot(results['ppo_finetuning']['timesteps'], results['ppo_finetuning']['rewards'], 
             label='PPO Fine-tuning')
    
    plt.plot(results['statemask_reset']['timesteps'], results['statemask_reset']['rewards'], 
             label='StateMask Reset')
    
    plt.plot(results['rice']['timesteps'], results['rice']['rewards'], 
             label='RICE')
    
    plt.xlabel('Timesteps')
    plt.ylabel('Mean Reward')
    plt.title(f'Refining Methods Comparison - {args.env}')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    plt.savefig(os.path.join(args.output_dir, f"{args.env}_refining_comparison.png"))
    
    # Save results
    np.save(os.path.join(args.output_dir, f"{args.env}_refining_results.npy"), {
        'original': original_performance,
        'ppo_finetuning': {
            'rewards': results['ppo_finetuning']['rewards'],
            'timesteps': results['ppo_finetuning']['timesteps']
        },
        'statemask_reset': {
            'rewards': results['statemask_reset']['rewards'],
            'timesteps': results['statemask_reset']['timesteps']
        },
        'rice': {
            'rewards': results['rice']['rewards'],
            'timesteps': results['rice']['timesteps']
        }
    })
    
    # Save the final refined agents
    results['ppo_finetuning']['agent'].save(os.path.join(args.output_dir, f"{args.env}_ppo_finetuning.zip"))
    results['statemask_reset']['agent'].save(os.path.join(args.output_dir, f"{args.env}_statemask_reset.zip"))
    results['rice']['agent'].save(os.path.join(args.output_dir, f"{args.env}_rice.zip"))
    
    print(f"\nResults saved to {args.output_dir}")

if __name__ == "__main__":
    main()
