import numpy as np

def compute_fidelity_score(agent, env, explanation_method, trajectory_length, window_fraction=0.1, n_trajectories=10):
    """
    Compute the fidelity score of an explanation method as described in the paper.
    
    The fidelity score measures how well the explanation method identifies critical steps
    in the agent's trajectory by measuring the impact of randomizing actions at those steps.
    
    Args:
        agent: The agent to evaluate
        env: The environment
        explanation_method: Function that takes a trajectory of states and returns importance scores
        trajectory_length: Length of trajectories to collect
        window_fraction: Fraction of trajectory to consider as critical window (K in the paper)
        n_trajectories: Number of trajectories to average over
        
    Returns:
        The fidelity score
    """
    fidelity_scores = []
    
    for _ in range(n_trajectories):
        # Collect a full trajectory without any intervention
        obs, _ = env.reset()
        states = [obs]
        actions = []
        orig_rewards = 0
        
        for t in range(trajectory_length):
            action, _ = agent.predict(obs, deterministic=True)
            actions.append(action)
            next_obs, reward, terminated, truncated, _ = env.step(action)
            orig_rewards += reward
            
            if terminated or truncated:
                break
                
            obs = next_obs
            states.append(obs)
        
        # Compute importance scores for each state in the trajectory
        importance_scores = explanation_method(states)
        
        # Compute window size (l = L * K)
        L = len(states)
        l = max(1, int(L * window_fraction))
        
        # Find the window with the highest average importance score
        max_window_score = -np.inf
        max_window_start = 0
        
        for i in range(L - l + 1):
            window_score = np.mean(importance_scores[i:i+l])
            if window_score > max_window_score:
                max_window_score = window_score
                max_window_start = i
        
        # Rerun the trajectory, but randomize actions in the identified critical window
        obs, _ = env.reset()
        modified_rewards = 0
        
        for t in range(trajectory_length):
            if max_window_start <= t < max_window_start + l:
                # Take random action in the critical window
                action = env.action_space.sample()
            else:
                # Follow original policy
                action = actions[t] if t < len(actions) else agent.predict(obs, deterministic=True)[0]
                
            next_obs, reward, terminated, truncated, _ = env.step(action)
            modified_rewards += reward
            
            if terminated or truncated:
                break
                
            obs = next_obs
        
        # Calculate reward difference
        d = abs(modified_rewards - orig_rewards)
        
        # Determine d_max (maximum possible reward change)
        # This is environment-specific and would need to be adjusted
        d_max = env.spec.reward_threshold if hasattr(env.spec, 'reward_threshold') else 1000
        
        # Compute fidelity score: log(d/d_max) - log(l/L)
        # Add a small epsilon to avoid log(0)
        epsilon = 1e-10
        fidelity_score = np.log((d + epsilon) / (d_max + epsilon)) - np.log((l + epsilon) / (L + epsilon))
        fidelity_scores.append(fidelity_score)
    
    # Return average fidelity score
    return np.mean(fidelity_scores)


def find_critical_segment(states, importance_scores, window_fraction=0.1):
    """
    Find the most critical segment in a trajectory based on importance scores.
    
    Args:
        states: List of states in the trajectory
        importance_scores: Importance scores for each state from an explanation method
        window_fraction: Fraction of trajectory to consider as critical window
        
    Returns:
        start_idx, end_idx: Start and end indices of the critical segment
    """
    L = len(states)
    l = max(1, int(L * window_fraction))
    
    # Find the window with the highest average importance score
    max_window_score = -np.inf
    max_window_start = 0
    
    for i in range(L - l + 1):
        window_score = np.mean(importance_scores[i:i+l])
        if window_score > max_window_score:
            max_window_score = window_score
            max_window_start = i
    
    return max_window_start, max_window_start + l
