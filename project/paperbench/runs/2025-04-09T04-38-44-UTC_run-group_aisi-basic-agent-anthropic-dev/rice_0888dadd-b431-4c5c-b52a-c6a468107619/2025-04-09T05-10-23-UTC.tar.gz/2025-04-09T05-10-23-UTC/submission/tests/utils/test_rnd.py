import os
import sys
import unittest
import numpy as np
import torch
import gymnasium as gym

from rice.utils.rnd import RNDModel, RND, RunningMeanStd

class TestRNDModel(unittest.TestCase):
    def setUp(self):
        # Initialize RND model
        self.input_size = 4
        self.hidden_size = 64
        self.output_size = 64
        self.rnd_model = RNDModel(
            input_size=self.input_size,
            hidden_size=self.hidden_size,
            output_size=self.output_size
        )
    
    def test_initialization(self):
        # Test that the model is initialized correctly
        self.assertIsInstance(self.rnd_model, RNDModel)
        self.assertIsInstance(self.rnd_model.target_network, torch.nn.Sequential)
        self.assertIsInstance(self.rnd_model.predictor_network, torch.nn.Sequential)
        
        # Test that target network parameters are not trainable
        for param in self.rnd_model.target_network.parameters():
            self.assertFalse(param.requires_grad)
        
        # Test that predictor network parameters are trainable
        for param in self.rnd_model.predictor_network.parameters():
            self.assertTrue(param.requires_grad)
    
    def test_forward_pass(self):
        # Test forward pass with a single observation
        obs = torch.FloatTensor(np.random.uniform(-1, 1, size=(1, self.input_size)))
        target, prediction = self.rnd_model(obs)
        
        # Check that outputs are tensors
        self.assertIsInstance(target, torch.Tensor)
        self.assertIsInstance(prediction, torch.Tensor)
        
        # Check that outputs have the right shape
        self.assertEqual(target.shape, torch.Size([1, self.output_size]))
        self.assertEqual(prediction.shape, torch.Size([1, self.output_size]))
    
    def test_batch_forward_pass(self):
        # Test forward pass with a batch of observations
        batch_size = 5
        batch_obs = torch.FloatTensor(np.random.uniform(-1, 1, size=(batch_size, self.input_size)))
        target, prediction = self.rnd_model(batch_obs)
        
        # Check that outputs have the right shape
        self.assertEqual(target.shape, torch.Size([batch_size, self.output_size]))
        self.assertEqual(prediction.shape, torch.Size([batch_size, self.output_size]))

class TestRND(unittest.TestCase):
    def setUp(self):
        # Create a simple environment for testing
        self.env = gym.make('CartPole-v1')
        
        # Initialize RND
        self.rnd = RND(
            observation_space=self.env.observation_space,
            device="cpu",
            learning_rate=1e-4
        )
    
    def test_initialization(self):
        # Test that RND is initialized correctly
        self.assertIsInstance(self.rnd, RND)
        self.assertIsInstance(self.rnd.model, RNDModel)
        self.assertIsInstance(self.rnd.optimizer, torch.optim.Adam)
        self.assertIsInstance(self.rnd.obs_rms, RunningMeanStd)
        self.assertIsInstance(self.rnd.reward_rms, RunningMeanStd)
    
    def test_compute_intrinsic_reward(self):
        # Test computing intrinsic reward
        obs, _ = self.env.reset()
        
        # Compute intrinsic reward
        intrinsic_reward = self.rnd.compute_intrinsic_reward(obs)
        
        # Check that intrinsic reward is a numpy array
        self.assertIsInstance(intrinsic_reward, np.ndarray)
        
        # Check that intrinsic reward has the right shape
        self.assertEqual(intrinsic_reward.shape, (1,))
        
        # Check that intrinsic reward is positive (should be MSE)
        self.assertTrue(intrinsic_reward[0] >= 0)
    
    def test_update(self):
        # Test updating the predictor network
        obs, _ = self.env.reset()
        
        # Initial loss
        initial_loss = self.rnd.update(obs)
        
        # Update again
        updated_loss = self.rnd.update(obs)
        
        # Check that losses are scalars
        self.assertIsInstance(initial_loss, float)
        self.assertIsInstance(updated_loss, float)
        
        # Loss should decrease after update
        self.assertLessEqual(updated_loss, initial_loss)

class TestRunningMeanStd(unittest.TestCase):
    def setUp(self):
        # Initialize running mean and std
        self.rms = RunningMeanStd(shape=(2,))
    
    def test_initialization(self):
        # Test that running mean and std are initialized correctly
        self.assertIsInstance(self.rms, RunningMeanStd)
        self.assertEqual(self.rms.mean.shape, (2,))
        self.assertEqual(self.rms.var.shape, (2,))
        self.assertEqual(self.rms.count, 1e-4)
    
    def test_update(self):
        # Test updating running mean and std
        x = np.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]])
        
        # Initial values
        initial_mean = self.rms.mean.copy()
        initial_var = self.rms.var.copy()
        
        # Update
        self.rms.update(x)
        
        # Mean should be updated
        self.assertFalse(np.array_equal(self.rms.mean, initial_mean))
        
        # Var should be updated
        self.assertFalse(np.array_equal(self.rms.var, initial_var))
        
        # Count should be updated
        self.assertEqual(self.rms.count, 1e-4 + 3)
        
        # Mean should be close to the actual mean of x
        np.testing.assert_allclose(self.rms.mean, np.mean(x, axis=0), rtol=1e-3)

if __name__ == '__main__':
    unittest.main()
