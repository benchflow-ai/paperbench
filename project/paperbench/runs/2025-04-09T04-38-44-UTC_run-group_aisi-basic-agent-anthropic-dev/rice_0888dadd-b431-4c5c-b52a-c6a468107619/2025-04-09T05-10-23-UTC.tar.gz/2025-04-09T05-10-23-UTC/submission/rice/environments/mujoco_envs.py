import gymnasium as gym
import numpy as np

class SparseRewardWrapper(gym.Wrapper):
    """
    Wrapper for creating sparse reward versions of MuJoCo environments.
    
    Transforms dense rewards to sparse rewards based on a threshold.
    The agent receives a reward of +1 if it exceeds the threshold, and 0 otherwise.
    """
    def __init__(self, env, threshold):
        super(SparseRewardWrapper, self).__init__(env)
        self.threshold = threshold
        self.total_reward = 0
        
    def reset(self, **kwargs):
        self.total_reward = 0
        return super().reset(**kwargs)
    
    def step(self, action):
        obs, reward, terminated, truncated, info = super().step(action)
        
        # Accumulate the original dense reward
        self.total_reward += reward
        
        # Convert to sparse reward
        if self.total_reward >= self.threshold:
            sparse_reward = 1.0
            # Reset the accumulated reward to make it truly sparse
            self.total_reward = 0
        else:
            sparse_reward = 0.0
        
        return obs, sparse_reward, terminated, truncated, info


def make_mujoco_env(env_id, sparse=False, threshold=None):
    """
    Create a MuJoCo environment with either dense or sparse rewards.
    
    Args:
        env_id: MuJoCo environment ID (e.g., 'Hopper-v4', 'Walker2d-v4')
        sparse: Whether to use sparse rewards
        threshold: Threshold for sparse reward (if None, use default values)
        
    Returns:
        The created environment
    """
    # Create the base environment
    env = gym.make(env_id)
    
    # Apply sparse reward wrapper if requested
    if sparse:
        # Default thresholds based on the paper's implementation
        default_thresholds = {
            'Hopper-v4': 1.0,
            'Walker2d-v4': 1.0,
            'HalfCheetah-v4': 5.0,
            'Reacher-v4': -1.0,  # For Reacher, lower values are better
        }
        
        # Use provided threshold or default
        if threshold is None:
            if env_id in default_thresholds:
                threshold = default_thresholds[env_id]
            else:
                # Fallback threshold
                threshold = 1.0
                
        env = SparseRewardWrapper(env, threshold)
    
    return env


# Dictionary mapping environment names to their gym IDs
MUJOCO_ENV_IDS = {
    'hopper': 'Hopper-v4',
    'walker2d': 'Walker2d-v4',
    'reacher': 'Reacher-v4',
    'halfcheetah': 'HalfCheetah-v4',
    'sparse_hopper': 'Hopper-v4',  # Will use SparseRewardWrapper
    'sparse_walker2d': 'Walker2d-v4',  # Will use SparseRewardWrapper
    'sparse_halfcheetah': 'HalfCheetah-v4',  # Will use SparseRewardWrapper
}

def create_env(env_name):
    """
    Create an environment based on its name.
    
    Args:
        env_name: Name of the environment to create
        
    Returns:
        The created environment
    """
    if env_name.startswith('sparse_'):
        # Create sparse reward version
        base_name = env_name[len('sparse_'):]
        if base_name in MUJOCO_ENV_IDS:
            return make_mujoco_env(MUJOCO_ENV_IDS[base_name], sparse=True)
        else:
            raise ValueError(f"Unknown environment: {env_name}")
    elif env_name in MUJOCO_ENV_IDS:
        # Create standard version
        return make_mujoco_env(MUJOCO_ENV_IDS[env_name], sparse=False)
    else:
        raise ValueError(f"Unknown environment: {env_name}")
