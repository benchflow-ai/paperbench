# Contributing to RICE

Thank you for considering contributing to RICE! This document provides guidelines and instructions for contributing to the codebase.

## Code of Conduct

Please be respectful and considerate of others when contributing to this project. We aim to foster an inclusive and welcoming community.

## Getting Started

1. Fork the repository on GitHub
2. Clone your fork locally
3. Set up a development environment:
   ```bash
   # Create a virtual environment
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   
   # Install dependencies
   pip install -r requirements.txt
   
   # Install in development mode
   pip install -e .
   ```
4. Create a branch for your changes

## Development Workflow

### Running Tests

Before submitting changes, make sure all tests pass:

```bash
# Run all tests
python -m tests.run_tests

# Run specific test categories
python -m tests.run_tests --category models
python -m tests.run_tests --category environments
python -m tests.run_tests --category utils
```

Or using the Makefile:

```bash
make test_all
make test_models
make test_environments
make test_utils
```

### Adding New Features

When adding new features, please follow these guidelines:

1. **Add Tests**: Write tests for your new features
2. **Update Documentation**: Update the relevant documentation files
3. **Follow Coding Style**: Follow the existing coding style (PEP 8)
4. **Add Type Hints**: Use type hints to make the code more readable and maintainable

### Adding New Environments

To add a new environment:

1. Create a new file in the `rice/environments/` directory
2. Implement the environment as a subclass of `gym.Env`
3. Add the environment to the environment registry in `rice/environments/__init__.py`
4. Add appropriate tests in `tests/environments/`
5. Update the environment documentation in `docs/environments/README.md`

### Adding New Explanation Methods

To add a new explanation method:

1. Add the implementation to `rice/models/` directory
2. Add appropriate tests in `tests/models/`
3. Update the models documentation in `docs/models/README.md`

## Pull Request Process

1. Ensure all tests pass
2. Update documentation as needed
3. Submit a pull request with a clear description of the changes
4. Address any feedback from code reviews

## Style Guidelines

- Follow [PEP 8](https://www.python.org/dev/peps/pep-0008/) for Python code
- Use meaningful variable names
- Include docstrings for all functions, classes, and modules
- Use type hints where appropriate
- Keep functions and methods focused on a single responsibility

## Documentation Guidelines

- Keep documentation up-to-date with code changes
- Follow Markdown formatting guidelines
- Include examples where appropriate
- Use simple language and avoid jargon

## License

By contributing to RICE, you agree that your contributions will be licensed under the same license as the project.

## Contact

If you have any questions or need help with the contribution process, please open an issue on GitHub.
