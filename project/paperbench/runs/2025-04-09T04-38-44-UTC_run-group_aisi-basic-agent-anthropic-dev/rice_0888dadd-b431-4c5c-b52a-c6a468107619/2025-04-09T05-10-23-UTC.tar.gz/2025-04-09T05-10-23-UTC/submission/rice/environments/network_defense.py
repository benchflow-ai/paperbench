import gymnasium as gym
from gymnasium import spaces
import numpy as np
import random

class NetworkDefenseEnv(gym.Env):
    """
    Simplified implementation of the CAGE Challenge 2 network defense environment.
    
    The environment simulates a network with nodes and connections. The defender
    must choose actions to protect the network from attacks.
    """
    def __init__(self, num_nodes=10, max_steps=100):
        super(NetworkDefenseEnv, self).__init__()
        
        self.num_nodes = num_nodes
        self.max_steps = max_steps
        
        # State space: node status (secure/compromised), attack indicators
        # For each node: [status, connection_status, attack_indicator]
        # status: 0 (secure) or 1 (compromised)
        # connection_status: 0 (disconnected) or 1 (connected) to each other node
        # attack_indicator: probability of attack on this node
        state_size = num_nodes * (1 + num_nodes + 1)
        
        self.observation_space = spaces.Box(
            low=0, high=1, 
            shape=(state_size,),
            dtype=np.float32
        )
        
        # Action space: for each node, can perform one of these actions:
        # 0: do nothing
        # 1: isolate node (disconnect from network)
        # 2: patch node (remove compromise)
        # 3: restore node connections
        self.action_space = spaces.Discrete(num_nodes * 4)
        
        # Initialize state
        self.steps = 0
        self.node_status = np.zeros(num_nodes)  # 0: secure, 1: compromised
        self.connection_status = np.ones((num_nodes, num_nodes))  # 1: connected, 0: disconnected
        np.fill_diagonal(self.connection_status, 0)  # No self-connections
        self.attack_indicators = np.zeros(num_nodes)
        
        # Track compromised nodes for reward calculation
        self.total_compromised = 0
        
    def _get_state(self):
        """Convert internal state to observation array"""
        # Flatten the state into a 1D array
        state = np.concatenate([
            self.node_status,
            self.connection_status.flatten(),
            self.attack_indicators
        ])
        return state.astype(np.float32)
    
    def reset(self, seed=None):
        """Reset the environment to initial state"""
        super().reset(seed=seed)
        
        self.steps = 0
        self.node_status = np.zeros(self.num_nodes)
        self.connection_status = np.ones((self.num_nodes, self.num_nodes))
        np.fill_diagonal(self.connection_status, 0)
        self.attack_indicators = np.zeros(self.num_nodes)
        self.total_compromised = 0
        
        # Initialize with some attack indicators
        self.attack_indicators = np.random.random(self.num_nodes) * 0.3
        
        return self._get_state(), {}
    
    def step(self, action):
        """
        Take a step in the environment with the given action.
        
        Actions:
        - For node i: 
          - i*4 + 0: do nothing
          - i*4 + 1: isolate node (disconnect from network)
          - i*4 + 2: patch node (remove compromise)
          - i*4 + 3: restore node connections
        
        Returns:
            obs: New state
            reward: Reward for this step
            terminated: Whether the episode is over
            truncated: Whether the episode is truncated
            info: Additional information
        """
        self.steps += 1
        
        # Decode the action
        node_idx = action // 4
        action_type = action % 4
        
        if node_idx >= self.num_nodes:
            raise ValueError(f"Invalid node index: {node_idx}")
        
        # Process the action
        if action_type == 0:  # Do nothing
            pass
        elif action_type == 1:  # Isolate node
            self.connection_status[node_idx, :] = 0
            self.connection_status[:, node_idx] = 0
        elif action_type == 2:  # Patch node
            self.node_status[node_idx] = 0  # Set to secure
        elif action_type == 3:  # Restore connections
            self.connection_status[node_idx, :] = 1
            self.connection_status[:, node_idx] = 1
            self.connection_status[node_idx, node_idx] = 0  # No self-connection
        
        # Simulate attack progression
        # 1. Increase attack indicators
        self.attack_indicators += np.random.random(self.num_nodes) * 0.1
        self.attack_indicators = np.clip(self.attack_indicators, 0, 1)
        
        # 2. Attacks succeed based on indicators
        for i in range(self.num_nodes):
            if random.random() < self.attack_indicators[i] and self.node_status[i] == 0:
                self.node_status[i] = 1  # Node becomes compromised
                self.total_compromised += 1
        
        # 3. Attacks spread through connections
        spread_matrix = np.zeros_like(self.node_status)
        for i in range(self.num_nodes):
            if self.node_status[i] == 1:  # If compromised
                for j in range(self.num_nodes):
                    if self.connection_status[i, j] == 1 and self.node_status[j] == 0:
                        # Connected nodes have a chance to be compromised
                        if random.random() < 0.2:
                            spread_matrix[j] = 1
        
        # Apply the spread
        for i in range(self.num_nodes):
            if spread_matrix[i] == 1 and self.node_status[i] == 0:
                self.node_status[i] = 1
                self.total_compromised += 1
        
        # Calculate reward
        # Negative reward for compromised nodes
        reward = -np.sum(self.node_status)
        
        # Check if episode is over
        terminated = self.steps >= self.max_steps
        truncated = False
        
        # Create new observation
        obs = self._get_state()
        
        # Additional info
        info = {
            'compromised_nodes': np.sum(self.node_status),
            'total_compromised': self.total_compromised,
            'attack_indicators': self.attack_indicators,
        }
        
        return obs, reward, terminated, truncated, info
    
    def render(self):
        """Render the environment (simple text-based output)"""
        print(f"Step: {self.steps}")
        print(f"Compromised nodes: {np.sum(self.node_status)}/{self.num_nodes}")
        print(f"Attack indicators: {self.attack_indicators}")
        
    def close(self):
        """Close the environment"""
        pass
