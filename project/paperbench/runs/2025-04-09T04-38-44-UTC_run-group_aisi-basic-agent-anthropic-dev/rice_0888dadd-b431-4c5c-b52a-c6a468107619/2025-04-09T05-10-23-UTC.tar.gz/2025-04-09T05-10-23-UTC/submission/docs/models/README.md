# Models Documentation

This document provides detailed documentation for the models in the RICE implementation.

## StateMask

The `state_mask.py` file contains the implementation of the improved StateMask explanation method.

### MaskNetwork

```python
class MaskNetwork(nn.Module)
```

The `MaskNetwork` is a neural network that takes a state as input and outputs the probability of masking (blinding) the agent's action at that state. A high probability indicates that the state is not critical, while a low probability indicates that the state is critical to the agent's performance.

#### Key Methods

- `forward(x)`: Forward pass through the network, returning masking probabilities
- `sample_action(state, deterministic=False)`: Sample a binary action (0 or 1) based on the mask network's output

### ImprovedStateMask

```python
class ImprovedStateMask
```

The `ImprovedStateMask` class implements the improved StateMask method as described in the paper.

#### Key Improvements

1. Reformulated objective function to maximize expected reward with masking
2. Added reward bonus for encouraging blinding

#### Key Methods

- `train(env, total_timesteps=10000, batch_size=64, n_steps=2048, gamma=0.99)`: Train the mask network using the improved objective function
- `explain(states)`: Generate explanations for a sequence of states

### Algorithm

The training algorithm for the mask network consists of the following steps:

1. Sample a trajectory from the target agent
2. At each step, use the mask network to decide whether to mask the agent's action
3. If masked, take a random action; otherwise, take the agent's action
4. Compute a modified reward that includes a bonus for masking
5. Update the mask network using PPO with the modified rewards

## RICE

The `rice.py` file contains the implementation of the RICE algorithm.

### RICE Class

```python
class RICE
```

The `RICE` class implements the RICE refining algorithm as described in the paper.

#### Key Parameters

- `pretrained_agent`: The agent to refine
- `mask_net`: The trained mask network
- `env`: The environment
- `reset_prob`: Probability of resetting to critical states
- `exploration_coef`: Coefficient for the exploration bonus

#### Key Methods

- `identify_critical_state(trajectory)`: Identify the most critical state in a trajectory
- `collect_trajectory()`: Collect a trajectory from the pre-trained agent
- `refine(total_timesteps=100000)`: Refine the pre-trained agent using the RICE algorithm

### Algorithm

The RICE algorithm consists of the following steps:

1. Collect trajectories from the pre-trained agent
2. Identify critical states using the mask network
3. Reset to either critical states or default initial states
4. Add RND exploration bonus to encourage exploring from these states
5. Train the agent using PPO

## Theoretical Basis

RICE introduces a mixed initial state distribution that theoretically leads to a tighter sub-optimality bound for the refined agent. The key insights are:

1. Deterministic state resetting (used in previous methods) can lead to overfitting
2. Mixed initial state distribution (used in RICE) helps avoid overfitting
3. Exploration from critical states helps the agent discover new strategies

For detailed mathematical derivations, please refer to Section 3.4 of the original paper.
