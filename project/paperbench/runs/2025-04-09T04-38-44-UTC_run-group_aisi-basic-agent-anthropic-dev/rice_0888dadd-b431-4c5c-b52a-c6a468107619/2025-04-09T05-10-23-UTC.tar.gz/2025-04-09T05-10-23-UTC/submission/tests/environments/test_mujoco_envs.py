import os
import sys
import unittest
import numpy as np
import gymnasium as gym

from rice.environments.mujoco_envs import create_env, SparseRewardWrapper

class TestMuJoCoEnvironments(unittest.TestCase):
    def test_create_env(self):
        # Test creating standard environments
        env_names = ['hopper', 'walker2d', 'reacher', 'halfcheetah']
        
        for env_name in env_names:
            # Try to create environment
            try:
                env = create_env(env_name)
                
                # Check that environment is created
                self.assertIsNotNone(env)
                
                # Check that environment has observation and action spaces
                self.assertIsNotNone(env.observation_space)
                self.assertIsNotNone(env.action_space)
                
                # Close environment
                env.close()
            except Exception as e:
                # Skip if environment can't be created (might not be installed)
                print(f"Skipping {env_name}: {str(e)}")
                continue
    
    def test_sparse_reward_wrapper(self):
        # Test the sparse reward wrapper
        try:
            # Create a standard environment
            env = gym.make('CartPole-v1')
            
            # Wrap with sparse reward
            sparse_env = SparseRewardWrapper(env, threshold=100)
            
            # Check that wrapper preserves observation and action spaces
            self.assertEqual(sparse_env.observation_space, env.observation_space)
            self.assertEqual(sparse_env.action_space, env.action_space)
            
            # Reset environments
            sparse_obs, _ = sparse_env.reset()
            
            # Check that total reward is initialized to 0
            self.assertEqual(sparse_env.total_reward, 0)
            
            # Take a step
            action = sparse_env.action_space.sample()
            sparse_next_obs, sparse_reward, sparse_terminated, sparse_truncated, sparse_info = sparse_env.step(action)
            
            # Check that sparse reward is 0 (below threshold) or 1 (above threshold)
            self.assertTrue(sparse_reward in [0, 1])
            
            # Close environments
            sparse_env.close()
            env.close()
        except Exception as e:
            # Skip if environment can't be created
            print(f"Skipping sparse reward test: {str(e)}")

if __name__ == '__main__':
    unittest.main()
