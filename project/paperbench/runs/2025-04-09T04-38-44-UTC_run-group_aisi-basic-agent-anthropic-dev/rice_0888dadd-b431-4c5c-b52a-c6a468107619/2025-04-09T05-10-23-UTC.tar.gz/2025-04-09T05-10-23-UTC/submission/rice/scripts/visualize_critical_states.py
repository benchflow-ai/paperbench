#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
from stable_baselines3 import PPO, SAC

from rice.models.state_mask import MaskNetwork
from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv
from rice.utils.fidelity import find_critical_segment
from rice.utils.explanation import identify_critical_states, random_explanation

def parse_args():
    parser = argparse.ArgumentParser(description='Visualize critical states identified by mask network')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to visualize')
    
    parser.add_argument('--agent-path', type=str, required=True,
                        help='Path to the agent')
    
    parser.add_argument('--mask-path', type=str, required=True,
                        help='Path to the trained mask network')
    
    parser.add_argument('--n-trajectories', type=int, default=5,
                        help='Number of trajectories to analyze')
    
    parser.add_argument('--max-steps', type=int, default=1000,
                        help='Maximum number of steps per trajectory')
    
    parser.add_argument('--window-fraction', type=float, default=0.1,
                        help='Window fraction for finding critical segments')
    
    parser.add_argument('--output-dir', type=str, default='./critical_states',
                        help='Directory to save visualizations')
    
    parser.add_argument('--compare-random', action='store_true',
                        help='Compare with random explanation')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, env):
    """Load an agent"""
    try:
        # Try PPO first
        agent = PPO.load(agent_path, env=env)
        return agent, 'PPO'
    except:
        try:
            # Try SAC if PPO fails
            agent = SAC.load(agent_path, env=env)
            return agent, 'SAC'
        except:
            raise ValueError(f"Failed to load agent from {agent_path} using PPO or SAC")

def load_mask_network(mask_path, observation_space):
    """Load a trained mask network"""
    # Create mask network with the same architecture
    mask_net = MaskNetwork(observation_space)
    
    # Load weights
    mask_net.load_state_dict(torch.load(mask_path))
    
    return mask_net

def collect_trajectory(agent, env, max_steps=1000):
    """Collect a trajectory from the agent"""
    obs, _ = env.reset()
    states = [obs]
    rewards = []
    actions = []
    dones = []
    
    for step in range(max_steps):
        action, _ = agent.predict(obs, deterministic=True)
        next_obs, reward, terminated, truncated, _ = env.step(action)
        
        states.append(next_obs)
        rewards.append(reward)
        actions.append(action)
        
        done = terminated or truncated
        dones.append(done)
        
        if done:
            break
            
        obs = next_obs
    
    return {
        'states': np.array(states),
        'rewards': np.array(rewards),
        'actions': np.array(actions) if len(actions) > 0 else np.array([]),
        'dones': np.array(dones),
        'length': len(states)
    }

def analyze_trajectory(trajectory, mask_net, window_fraction=0.1, use_random=False):
    """Analyze a trajectory and identify critical states"""
    states = trajectory['states']
    
    if use_random:
        # Use random explanation
        importance_scores = random_explanation(states)
    else:
        # Use mask network for explanation
        importance_scores = identify_critical_states(states, mask_net)
    
    # Find the most critical segment
    start_idx, end_idx = find_critical_segment(states, importance_scores, window_fraction)
    
    # Calculate statistics
    avg_importance = np.mean(importance_scores)
    avg_importance_critical = np.mean(importance_scores[start_idx:end_idx])
    
    # Calculate correlation with rewards
    reward_corr = np.corrcoef(importance_scores[:-1], trajectory['rewards'])[0, 1] if len(trajectory['rewards']) > 0 else 0
    
    return {
        'importance_scores': importance_scores,
        'start_idx': start_idx,
        'end_idx': end_idx,
        'avg_importance': avg_importance,
        'avg_importance_critical': avg_importance_critical,
        'reward_correlation': reward_corr
    }

def visualize_trajectory(trajectory, analysis, output_path, title="State Importance Analysis"):
    """Visualize a trajectory with critical states highlighted"""
    rewards = trajectory['rewards']
    importance_scores = analysis['importance_scores'][:-1]  # Match length with rewards
    start_idx = analysis['start_idx']
    end_idx = analysis['end_idx']
    
    plt.figure(figsize=(12, 8))
    
    # Plot rewards and importance scores
    plt.subplot(2, 1, 1)
    plt.plot(rewards, color='blue', label='Reward')
    plt.axvspan(start_idx, min(end_idx, len(rewards)), color='red', alpha=0.3, label='Critical Segment')
    plt.xlabel('Step')
    plt.ylabel('Reward')
    plt.title(f'Rewards over Time - {title}')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.subplot(2, 1, 2)
    plt.plot(importance_scores, color='green', label='Importance Score')
    plt.axvspan(start_idx, min(end_idx, len(importance_scores)), color='red', alpha=0.3, label='Critical Segment')
    plt.xlabel('Step')
    plt.ylabel('Importance Score')
    plt.title('State Importance Scores')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()

def visualize_state_features(trajectory, analysis, env_name, output_path):
    """Visualize important state features in critical states"""
    states = trajectory['states']
    importance_scores = analysis['importance_scores']
    
    # Get the most critical state
    critical_idx = start_idx = analysis['start_idx'] + np.argmax(importance_scores[analysis['start_idx']:analysis['end_idx']])
    critical_state = states[critical_idx]
    
    # Get a non-critical state (lowest importance score)
    non_critical_idx = np.argmin(importance_scores)
    non_critical_state = states[non_critical_idx]
    
    # Plot feature comparison
    plt.figure(figsize=(10, 8))
    
    # Determine how to interpret state based on environment
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        # For MuJoCo environments, plot all state dimensions
        n_features = len(critical_state)
        feature_names = [f'Feature {i+1}' for i in range(n_features)]
        
        # Plot each feature
        plt.subplot(2, 1, 1)
        plt.bar(feature_names, critical_state, color='red', alpha=0.7)
        plt.title(f'Critical State (Step {critical_idx}, Importance: {importance_scores[critical_idx]:.4f})')
        plt.xticks(rotation=45, ha='right')
        plt.grid(True, linestyle='--', alpha=0.7)
        
        plt.subplot(2, 1, 2)
        plt.bar(feature_names, non_critical_state, color='blue', alpha=0.7)
        plt.title(f'Non-Critical State (Step {non_critical_idx}, Importance: {importance_scores[non_critical_idx]:.4f})')
        plt.xticks(rotation=45, ha='right')
        plt.grid(True, linestyle='--', alpha=0.7)
    
    elif env_name == 'selfish_mining':
        # For selfish mining, interpret state as [lead, fork, next_to_reveal]
        feature_names = ['Lead', 'Fork', 'Next to Reveal']
        
        # Plot critical state
        plt.subplot(2, 1, 1)
        plt.bar(feature_names, critical_state, color='red', alpha=0.7)
        plt.title(f'Critical State (Step {critical_idx}, Importance: {importance_scores[critical_idx]:.4f})')
        plt.grid(True, linestyle='--', alpha=0.7)
        
        # Plot non-critical state
        plt.subplot(2, 1, 2)
        plt.bar(feature_names, non_critical_state, color='blue', alpha=0.7)
        plt.title(f'Non-Critical State (Step {non_critical_idx}, Importance: {importance_scores[non_critical_idx]:.4f})')
        plt.grid(True, linestyle='--', alpha=0.7)
    
    else:
        # For other environments, generic approach
        n_features = min(10, len(critical_state))  # Show at most 10 features
        feature_names = [f'Feature {i+1}' for i in range(n_features)]
        
        # Plot critical state
        plt.subplot(2, 1, 1)
        plt.bar(feature_names, critical_state[:n_features], color='red', alpha=0.7)
        plt.title(f'Critical State (Step {critical_idx}, Importance: {importance_scores[critical_idx]:.4f})')
        plt.grid(True, linestyle='--', alpha=0.7)
        
        # Plot non-critical state
        plt.subplot(2, 1, 2)
        plt.bar(feature_names, non_critical_state[:n_features], color='blue', alpha=0.7)
        plt.title(f'Non-Critical State (Step {non_critical_idx}, Importance: {importance_scores[non_critical_idx]:.4f})')
        plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create environment
    env = create_environment(args.env)
    
    # Load agent
    agent, algorithm = load_agent(args.agent_path, env)
    print(f"Loaded {algorithm} agent from {args.agent_path}")
    
    # Load mask network
    mask_net = load_mask_network(args.mask_path, env.observation_space)
    print(f"Loaded mask network from {args.mask_path}")
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Analyze trajectories
    all_analyses = []
    random_analyses = []
    
    for i in range(args.n_trajectories):
        print(f"\nAnalyzing trajectory {i+1}/{args.n_trajectories}...")
        
        # Collect trajectory
        trajectory = collect_trajectory(agent, env, args.max_steps)
        print(f"Collected trajectory of length {trajectory['length']} steps")
        
        # Analyze trajectory with mask network
        analysis = analyze_trajectory(trajectory, mask_net, args.window_fraction)
        all_analyses.append(analysis)
        
        # Save visualization
        output_path = os.path.join(args.output_dir, f"trajectory_{i+1}.png")
        visualize_trajectory(trajectory, analysis, output_path)
        
        # Visualize state features
        feature_path = os.path.join(args.output_dir, f"features_{i+1}.png")
        visualize_state_features(trajectory, analysis, args.env, feature_path)
        
        # Print analysis results
        print(f"Critical segment: steps {analysis['start_idx']} to {analysis['end_idx']}")
        print(f"Average importance score: {analysis['avg_importance']:.4f}")
        print(f"Average importance in critical segment: {analysis['avg_importance_critical']:.4f}")
        print(f"Correlation with rewards: {analysis['reward_correlation']:.4f}")
        
        # Compare with random explanation if requested
        if args.compare_random:
            random_analysis = analyze_trajectory(trajectory, None, args.window_fraction, use_random=True)
            random_analyses.append(random_analysis)
            
            # Save random explanation visualization
            random_path = os.path.join(args.output_dir, f"random_{i+1}.png")
            visualize_trajectory(trajectory, random_analysis, random_path, title="Random Explanation")
    
    # Calculate and print summary statistics
    avg_importance = np.mean([a['avg_importance'] for a in all_analyses])
    avg_importance_critical = np.mean([a['avg_importance_critical'] for a in all_analyses])
    avg_reward_corr = np.mean([a['reward_correlation'] for a in all_analyses])
    
    print("\nSummary Statistics:")
    print(f"Average importance score: {avg_importance:.4f}")
    print(f"Average importance in critical segments: {avg_importance_critical:.4f}")
    print(f"Average correlation with rewards: {avg_reward_corr:.4f}")
    
    if args.compare_random:
        avg_random_importance = np.mean([a['avg_importance'] for a in random_analyses])
        avg_random_importance_critical = np.mean([a['avg_importance_critical'] for a in random_analyses])
        avg_random_reward_corr = np.mean([a['reward_correlation'] for a in random_analyses])
        
        print("\nRandom Explanation Statistics:")
        print(f"Average importance score: {avg_random_importance:.4f}")
        print(f"Average importance in critical segments: {avg_random_importance_critical:.4f}")
        print(f"Average correlation with rewards: {avg_random_reward_corr:.4f}")
    
        # Create comparison plot
        plt.figure(figsize=(10, 6))
        
        bars = plt.bar(
            ['Avg Importance', 'Critical Importance', 'Reward Correlation'],
            [avg_importance, avg_importance_critical, avg_reward_corr],
            label='Mask Network'
        )
        
        for i, bar in enumerate(bars):
            plt.text(
                bar.get_x() + bar.get_width()/2,
                bar.get_height() + 0.01,
                f'{[avg_importance, avg_importance_critical, avg_reward_corr][i]:.4f}',
                ha='center', va='bottom'
            )
        
        bars = plt.bar(
            [x + 0.4 for x in range(3)],
            [avg_random_importance, avg_random_importance_critical, avg_random_reward_corr],
            label='Random',
            alpha=0.7
        )
        
        for i, bar in enumerate(bars):
            plt.text(
                bar.get_x() + bar.get_width()/2,
                bar.get_height() + 0.01,
                f'{[avg_random_importance, avg_random_importance_critical, avg_random_reward_corr][i]:.4f}',
                ha='center', va='bottom'
            )
        
        plt.ylabel('Value')
        plt.title('Explanation Method Comparison')
        plt.legend()
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        comparison_path = os.path.join(args.output_dir, "comparison.png")
        plt.savefig(comparison_path, dpi=300)
        plt.close()
    
    print(f"\nVisualizations saved to {args.output_dir}")

if __name__ == "__main__":
    main()
