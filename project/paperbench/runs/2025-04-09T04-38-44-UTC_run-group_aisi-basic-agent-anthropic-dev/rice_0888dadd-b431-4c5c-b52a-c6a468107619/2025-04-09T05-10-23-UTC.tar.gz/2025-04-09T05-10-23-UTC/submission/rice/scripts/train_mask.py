#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
from stable_baselines3 import PPO, SAC

from rice.models.state_mask import ImprovedStateMask
from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv
from rice.utils.fidelity import compute_fidelity_score

def parse_args():
    parser = argparse.ArgumentParser(description='Train mask network for a pre-trained agent')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to train on')
    
    parser.add_argument('--agent-path', type=str, required=True,
                        help='Path to pre-trained agent')
    
    parser.add_argument('--mask-save-path', type=str, default='./trained_masks',
                        help='Path to save the trained mask network')
    
    parser.add_argument('--algorithm', type=str, default='PPO', choices=['PPO', 'SAC'],
                        help='Algorithm used for the pre-trained agent')
    
    parser.add_argument('--timesteps', type=int, default=100000,
                        help='Number of timesteps to train the mask network')
    
    parser.add_argument('--mask-bonus', type=float, default=0.01,
                        help='Bonus reward for masking (α in the paper)')
    
    parser.add_argument('--eval', action='store_true',
                        help='Evaluate the mask network after training')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, algorithm, env):
    """Load a pre-trained agent"""
    if algorithm == 'PPO':
        return PPO.load(agent_path, env=env)
    elif algorithm == 'SAC':
        return SAC.load(agent_path, env=env)
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create environment
    env = create_environment(args.env)
    
    # Load pre-trained agent
    agent = load_agent(args.agent_path, args.algorithm, env)
    
    # Create improved state mask
    state_mask = ImprovedStateMask(
        target_agent=agent,
        observation_space=env.observation_space,
        action_space=env.action_space,
        mask_bonus=args.mask_bonus,
    )
    
    # Train the mask network
    print(f"Training mask network for {args.timesteps} timesteps...")
    mask_net = state_mask.train(env, total_timesteps=args.timesteps)
    
    # Create save directory if it doesn't exist
    os.makedirs(args.mask_save_path, exist_ok=True)
    
    # Save the trained mask network
    save_path = os.path.join(args.mask_save_path, f"{args.env}_mask.pt")
    torch.save(mask_net.state_dict(), save_path)
    print(f"Saved mask network to {save_path}")
    
    # Evaluate if requested
    if args.eval:
        # Define an explanation function that uses the trained mask network
        def explanation_fn(states):
            return state_mask.explain(states)
        
        # Compute fidelity score
        fidelity_score = compute_fidelity_score(
            agent=agent,
            env=env,
            explanation_method=explanation_fn,
            trajectory_length=1000,
            window_fraction=0.1,
            n_trajectories=10
        )
        
        print(f"Fidelity score: {fidelity_score:.4f}")

if __name__ == "__main__":
    main()
