import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical
import gymnasium as gym # Assuming usage of gymnasium interface
import numpy as np # Added for potential continuous action handling/random sampling

# Placeholder for a generic policy network (User needs to provide their pre-trained policy)
# Example structure:
# class TargetPolicy(nn.Module):
#     def __init__(self, state_dim, action_dim):
#         super(TargetPolicy, self).__init__()
#         # ... network layers ...
#     def forward(self, state):
#         # ... return action probabilities or deterministic action ...
#         pass

# Mask Network (Outputs logits for binary mask action)
class MaskNetwork(nn.Module):
    def __init__(self, state_dim):
        super(MaskNetwork, self).__init__()
        # Simple MLP, adjust complexity as needed
        self.fc1 = nn.Linear(state_dim, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc_mask = nn.Linear(64, 2) # Output logits for binary mask action (0=keep, 1=random)

    def forward(self, state):
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        mask_logits = self.fc_mask(x)
        return mask_logits

    def get_action_and_prob(self, state):
        """ Samples action, returns action, log_prob, and probability of action 0 """
        logits = self.forward(state)
        dist = Categorical(logits=logits)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        # Probability of outputting "0" (not blinding) -> Importance Score
        prob_zero = dist.probs[..., 0] # Softmax is implicit in Categorical(logits=...)
        return action, log_prob, prob_zero

# Value Network used by PPO critic for StateMask training
class ValueNetwork(nn.Module):
    def __init__(self, state_dim):
        super(ValueNetwork, self).__init__()
        # Simple MLP, adjust complexity as needed
        self.fc1 = nn.Linear(state_dim, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc_value = nn.Linear(64, 1) # Output single value estimate

    def forward(self, state):
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        value = self.fc_value(x)
        return value

# Rollout buffer for PPO
class RolloutBuffer:
    def __init__(self):
        self.states = []
        self.mask_actions = []       # Action taken by the mask network (0 or 1)
        self.mask_log_probs = []   # Log prob of the mask action
        self.rewards = []          # Modified rewards (R + alpha * a_m) used for PPO
        self.dones = []            # Episode termination flags
        self.values = []           # Value estimates from critic V(s_t)
        self.importance_scores = []# Probability P(a_m=0 | s_t)

    def clear(self):
        del self.states[:]
        del self.mask_actions[:]
        del self.mask_log_probs[:]
        del self.rewards[:]
        del self.dones[:]
        del self.values[:]
        del self.importance_scores[:]

    def add(self, state, mask_action, mask_log_prob, reward, done, value, importance_score):
        # Store states as numpy arrays to avoid potential CUDA memory accumulation if using GPU
        self.states.append(np.array(state))
        self.mask_actions.append(torch.as_tensor(mask_action, dtype=torch.int64))
        self.mask_log_probs.append(torch.as_tensor(mask_log_prob))
        self.rewards.append(torch.as_tensor(reward, dtype=torch.float32))
        self.dones.append(torch.as_tensor(done, dtype=torch.bool))
        self.values.append(value.detach()) # Detach value estimates when storing
        self.importance_scores.append(torch.as_tensor(importance_score))

    def _stack_tensors(self, tensor_list, device):
        # Helper to safely stack potentially empty lists or single tensors
        if not tensor_list:
            # Return an empty tensor with expected dimensions if possible
             if tensor_list is self.states: # States need careful shape handling
                 # If states list is truly empty, we can'\\''t know the state dim. Return shape (0, 0) or similar.
                 # A better approach might be to initialize buffer with state_dim info.
                 # For now, return a simple empty tensor. Caller needs to handle empty data.
                 print("Warning: Attempting to stack empty list of states.")
                 return torch.empty((0, 0)).to(device) # Placeholder shape
             else:
                 # For actions, rewards etc., shape (0) is usually fine
                 return torch.empty(0).to(device)

        if isinstance(tensor_list[0], np.ndarray): # Handle numpy arrays (like states)
            try:
                stacked_np = np.stack(tensor_list)
                return torch.from_numpy(stacked_np).float().to(device)
            except ValueError as e:
                 print(f"Error stacking numpy arrays (likely inconsistent shapes): {e}")
                 # You might want to pad or handle this error more gracefully depending on the cause
                 # For now, raise to signal the problem
                 raise e
        elif torch.is_tensor(tensor_list[0]):
             # Ensure all tensors are detached before stacking
             processed_tensors = [t.detach().to(device) for t in tensor_list]
             try:
                return torch.stack(processed_tensors)
             except RuntimeError as e:
                 print(f"Error stacking tensors: {e}")
                 # Provide more context if possible
                 print(f"Tensor shapes: {[t.shape for t in processed_tensors]}")
                 raise e
        else:
            # Handle other types if necessary
            return torch.tensor(tensor_list).to(device)


    def get_tensors(self, device='\\''cpu'\\''):
        """ Convert stored data to tensors on the specified device. """
        # Use the helper function for robust stacking
        states_t = self._stack_tensors(self.states, device)
        mask_actions_t = self._stack_tensors(self.mask_actions, device)
        mask_log_probs_t = self._stack_tensors(self.mask_log_probs, device)
        rewards_t = self._stack_tensors(self.rewards, device)
        dones_t = self._stack_tensors(self.dones, device)
        values_t = self._stack_tensors(self.values, device)

        return states_t, mask_actions_t, mask_log_probs_t, rewards_t, dones_t, values_t


# PPO Trainer for the Mask Network (Algorithm 1 optimization)
class PPO_MaskTrainer:
    def __init__(self, mask_net: MaskNetwork, value_net: ValueNetwork, lr=3e-4, gamma=0.99, gae_lambda=0.95, clip_epsilon=0.2, ppo_epochs=10, batch_size=64, value_coeff=0.5, entropy_coeff=0.01, device='\\''cpu'\\''):
        self.mask_net = mask_net
        self.value_net = value_net
        self.device = device
        # Combine parameters from both networks for the optimizer
        self.optimizer = optim.Adam(list(mask_net.parameters()) + list(value_net.parameters()), lr=lr)
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.clip_epsilon = clip_epsilon
        self.ppo_epochs = ppo_epochs
        self.batch_size = batch_size
        self.value_coeff = value_coeff
        self.entropy_coeff = entropy_coeff

        self.mask_net.to(self.device)
        self.value_net.to(self.device)

    def compute_gae(self, rewards, dones, values, last_value):
        """ Computes Generalized Advantage Estimation (GAE). """
        advantages = torch.zeros_like(rewards).to(self.device)
        last_gae_lam = 0
        num_steps = len(rewards)

        # Ensure values tensor has the correct shape (N) and includes last_value
        if values.ndim > 1:
            values_squeezed = values.squeeze(-1) # Make sure values is [N]
        else:
            values_squeezed = values
        if last_value.ndim > 1:
             last_value_squeezed = last_value.squeeze(-1) # Make sure last_value is [1] or scalar
        else:
             last_value_squeezed = last_value


        # Check if last_value_squeezed is scalar, if so make it [1] tensor
        if last_value_squeezed.ndim == 0:
            last_value_squeezed = last_value_squeezed.unsqueeze(0)

        # Ensure values_squeezed is not empty
        if num_steps == 0:
             if not torch.is_tensor(last_value_squeezed) or last_value_squeezed.nelement() == 0:
                  print("Warning: compute_gae called with no steps and no valid last_value.")
                  return advantages # Return zeros

             # If only last_value exists, GAE logic doesn'\\''t apply, return zeros
             return advantages


        # Check if values_squeezed is empty but rewards/dones are not (should not happen with buffer logic)
        if values_squeezed.nelement() == 0 and num_steps > 0:
            print("Error: compute_gae called with rewards/dones but empty values tensor.")
            # Handle error: maybe return zeros or raise exception
            return torch.zeros_like(rewards).to(self.device)


        # Proceed only if values_squeezed is not empty
        extended_values = torch.cat((values_squeezed, last_value_squeezed), dim=0)

        for t in reversed(range(num_steps)):
            mask = 1.0 - dones[t].float() # Mask is 0 if terminal, 1 otherwise
            delta = rewards[t] + self.gamma * extended_values[t+1] * mask - extended_values[t]
            last_gae_lam = delta + self.gamma * self.gae_lambda * mask * last_gae_lam
            advantages[t] = last_gae_lam
        return advantages


    def update(self, memory: RolloutBuffer, last_value: torch.Tensor):
        """
        Performs the PPO update based on data collected in the memory buffer.

        Args:
            memory: RolloutBuffer containing trajectory data.
            last_value: Value estimate of the final state in the collected trajectory V(s_T). Should be shape [1] or scalar tensor.
        """
        self.mask_net.train()
        self.value_net.train()

        # 1. Get data and move to device
        states, actions, old_log_probs, rewards, dones, values = memory.get_tensors(self.device)

        # Check if buffer was empty
        if states.shape[0] == 0:
            print("Warning: No samples in buffer for PPO update.")
            return # Cannot update with no data

        # Ensure last_value is on the correct device and detached, match shape if needed
        last_value = last_value.to(self.device).detach()


        # 2. Compute Advantages and Returns (Value Targets) using GAE
        advantages = self.compute_gae(rewards, dones, values, last_value)
        returns = advantages + values.squeeze(-1) # V_target(s_t) = A_GAE(s_t, a_t) + V(s_t)

        # Normalize advantages (optional but recommended)
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        # 3. PPO Update Loop (multiple epochs)
        num_samples = len(states)
        indices = np.arange(num_samples)

        for epoch in range(self.ppo_epochs):
            np.random.shuffle(indices) # Shuffle for mini-batch sampling

            effective_batch_size = min(self.batch_size, num_samples) # Handle cases with < batch_size samples

            for start in range(0, num_samples, effective_batch_size):
                end = start + effective_batch_size
                batch_indices = indices[start:end]

                # Get mini-batch data
                batch_states = states[batch_indices]
                batch_actions = actions[batch_indices]
                batch_old_log_probs = old_log_probs[batch_indices]
                batch_advantages = advantages[batch_indices]
                batch_returns = returns[batch_indices]

                # Evaluate current policy on mini-batch states
                logits = self.mask_net(batch_states)
                dist = Categorical(logits=logits)
                new_log_probs = dist.log_prob(batch_actions)
                entropy = dist.entropy().mean()
                current_values = self.value_net(batch_states).squeeze(-1) # Shape: [batch_size]

                # --- Calculate Policy Loss (Clipped Surrogate Objective) ---
                log_ratio = new_log_probs - batch_old_log_probs
                ratio = torch.exp(log_ratio)

                surr1 = ratio * batch_advantages
                surr2 = torch.clamp(ratio, 1.0 - self.clip_epsilon, 1.0 + self.clip_epsilon) * batch_advantages
                policy_loss = -torch.min(surr1, surr2).mean()

                # --- Calculate Value Loss (MSE) ---
                value_loss = 0.5 * ((current_values - batch_returns) ** 2).mean()

                # --- Calculate Total Loss ---
                loss = policy_loss + self.value_coeff * value_loss - self.entropy_coeff * entropy

                # --- Optimization Step ---
                self.optimizer.zero_grad()
                loss.backward()
                # Optional: Gradient clipping
                torch.nn.utils.clip_grad_norm_(list(self.mask_net.parameters()) + list(self.value_net.parameters()), max_norm=0.5)
                self.optimizer.step()

# Main Class for StateMask Explanation
class StateMaskExplainer:
    """
    Implements the modified StateMask explanation method (Algorithm 1).
    Learns a mask network using PPO to identify critical states by maximizing
    reward R'\\'' = R + alpha * a_m, where a_m=1 means blinding (random action).
    """
    def __init__(self, target_policy: nn.Module, env_name: str, alpha: float = 0.001, device: str = '\\''cpu'\\'', ppo_kwargs: dict = None):
        """
        Initializes the StateMaskExplainer.

        Args:
            target_policy: The pre-trained policy network to explain (MUST be on `device`).
            env_name: The name of the Gymnasium environment.
            alpha: Hyperparameter for the mask bonus reward (encourages blinding).
            device: Torch device ('\\''cpu'\\'' or '\\''cuda'\\'').
            ppo_kwargs: Dictionary of arguments for the PPO trainer (e.g., lr, gamma, epochs).
        """
        self.target_policy = target_policy.to(device)
        self.target_policy.eval() # Ensure target policy is in eval mode
        try:
            # Try creating the environment to check validity and get specs
            temp_env = gym.make(env_name)
            self.state_dim = temp_env.observation_space.shape[0]
             # Determine action space type and dimension for random action sampling
            if isinstance(temp_env.action_space, gym.spaces.Discrete):
                self.action_space_type = '\\''discrete'\\''
                self.action_dim = temp_env.action_space.n
            elif isinstance(temp_env.action_space, gym.spaces.Box):
                self.action_space_type = '\\''continuous'\\''
                self.action_dim = temp_env.action_space.shape[0]
                self.action_low = temp_env.action_space.low
                self.action_high = temp_env.action_space.high
            else:
                 temp_env.close()
                 raise NotImplementedError(f"Unsupported action space type: {type(temp_env.action_space)}")
            temp_env.close() # Close the temporary env
            self.env_name = env_name # Store env name for later use
            self.env = None # Don'\\''t keep env open initially

        except Exception as e:
            print(f"Error during environment ({env_name}) initialization: {e}")
            raise

        self.device = torch.device(device)
        self.alpha = alpha # Bonus for blinding (a_m=1)

        # Initialize Networks
        self.mask_net = MaskNetwork(self.state_dim).to(self.device)
        self.mask_net_old = MaskNetwork(self.state_dim).to(self.device) # For PPO sampling
        self.value_net = ValueNetwork(self.state_dim).to(self.device) # Critic for PPO

        self.mask_net_old.load_state_dict(self.mask_net.state_dict())
        self.mask_net_old.eval() # Old network is only used for sampling

        # Initialize PPO Trainer
        ppo_defaults = {'\\''lr'\\'': 3e-4, '\\''gamma'\\'': 0.99, '\\''gae_lambda'\\'': 0.95, '\\''clip_epsilon'\\'': 0.2, '\\''ppo_epochs'\\'': 10, '\\''batch_size'\\'': 64, '\\''value_coeff'\\'': 0.5, '\\''entropy_coeff'\\'': 0.01}
        if ppo_kwargs:
            ppo_defaults.update(ppo_kwargs)
        self.ppo_trainer = PPO_MaskTrainer(self.mask_net, self.value_net, device=self.device, **ppo_defaults)

        # Initialize Memory Buffer
        self.memory = RolloutBuffer()

        print(f"Initialized StateMaskExplainer for env: {self.env_name} on device: {self.device}")
        print(f"State dim: {self.state_dim}, Action dim: {self.action_dim}, Action type: {self.action_space_type}")
        print(f"Mask bonus alpha: {self.alpha}")
        print(f"PPO args: {ppo_defaults}")

    def _make_env(self):
         """ Creates and returns a new environment instance. """
         try:
             env = gym.make(self.env_name)
             return env
         except Exception as e:
             print(f"Error creating environment {self.env_name} within training: {e}")
             raise

    def _close_env(self):
        """ Closes the environment if it exists. """
        if self.env is not None:
            try:
                self.env.close()
                self.env = None
            except Exception as e:
                print(f"Error closing environment: {e}")


    def _select_target_action(self, state_tensor):
        """ Gets action from the pre-trained target policy. """
        with torch.no_grad():
            action_output = self.target_policy(state_tensor)
            # Handle tuple outputs (e.g., action, log_prob from some policies)
            if isinstance(action_output, tuple):
                action = action_output[0]
            else:
                action = action_output

            if self.action_space_type == '\\''discrete'\\'':
                 # Input to Categorical should be probs or logits
                 if action.ndim > 1 and action.shape[0] == 1:
                     action = action.squeeze(0) # Shape [action_dim]

                 # Heuristic: check if values look like probabilities
                 is_probs = torch.is_floating_point(action) and \\
                            torch.all(action >= 0) and \\
                            torch.allclose(action.sum(), torch.tensor(1.0, device=action.device))

                 if is_probs:
                    dist = Categorical(probs=action)
                 else: # Assume logits
                    dist = Categorical(logits=action)

                 sampled_action = dist.sample()
                 return sampled_action.item()

            elif self.action_space_type == '\\''continuous'\\'':
                 # Assuming policy output is the action directly (e.g., mean of Gaussian)
                 # Clip action to environment bounds just in case
                 action_np = action.squeeze(0).cpu().numpy()
                 return np.clip(action_np, self.action_low, self.action_high)
            else:
                 raise NotImplementedError


    def _select_random_action(self):
        """ Samples a random action from the environment'\\''s action space. """
        # Create a temporary env instance ONLY for sampling if self.env is None
        # This is inefficient but safer if train isn'\\''t running
        if self.env is None:
             temp_env = self._make_env()
             action = temp_env.action_space.sample()
             temp_env.close()
             return action
        else:
             return self.env.action_space.sample()


    def train(self, total_timesteps: int, update_interval: int = 2048, max_ep_len: int = 1000, save_path: str = None, log_interval: int = 10):
        """
        Trains the mask network using Algorithm 1 from the RICE paper.

        Args:
            total_timesteps: Total number of environment steps for training.
            update_interval: Number of steps to collect before performing a PPO update.
            max_ep_len: Maximum length of an episode.
            save_path: Optional path to save the final trained mask model.
            log_interval: Print training logs every N episodes.
        """
        print(f"--- Starting StateMask Training ---")
        print(f"Total timesteps: {total_timesteps}, Update interval: {update_interval}")

        self.env = self._make_env() # Create env for training run

        time_step = 0
        i_episode = 0
        collected_steps = 0
        episode_rewards_orig = [] # Track original env rewards per episode
        episode_rewards_masked = [] # Track R'\\'' rewards used for training mask net

        state, info = self.env.reset()
        current_ep_reward_orig = 0
        current_ep_reward_masked = 0
        ep_len = 0

        while time_step < total_timesteps:
            if not isinstance(state, np.ndarray): state = np.array(state)
            state_tensor = torch.as_tensor(state, dtype=torch.float32).unsqueeze(0).to(self.device)

            # --- Collect Experience (Single Step) ---
            with torch.no_grad():
                value_t = self.value_net(state_tensor) # V(s_t), Shape: [1, 1]
                mask_action_t, mask_log_prob_t, prob_zero_t = self.mask_net_old.get_action_and_prob(state_tensor)
                mask_action = mask_action_t.item()
                mask_log_prob = mask_log_prob_t.item()
                importance_score = prob_zero_t.item() # P(a_m=0 | s_t)

            target_action = self._select_target_action(state_tensor)

            if mask_action == 0: actual_action = target_action
            else: actual_action = self._select_random_action()

            try:
                next_state, reward, terminated, truncated, info = self.env.step(actual_action)
            except Exception as e:
                print(f"Error during env.step with action {actual_action} (type {type(actual_action)}): {e}")
                terminated, truncated = True, True
                reward, next_state = 0, state # Default values on error

            done = terminated or truncated
            modified_reward = reward + self.alpha * mask_action

            # Store transition (use numpy state)
            self.memory.add(state, mask_action, mask_log_prob, modified_reward, done, value_t.squeeze(0), importance_score)

            state = next_state
            time_step += 1
            collected_steps += 1
            ep_len += 1
            current_ep_reward_orig += reward
            current_ep_reward_masked += modified_reward

            # --- Handle Episode End ---
            if done or ep_len >= max_ep_len:
                i_episode += 1
                episode_rewards_orig.append(current_ep_reward_orig)
                episode_rewards_masked.append(current_ep_reward_masked)

                if i_episode % log_interval == 0 and len(episode_rewards_orig) >= log_interval:
                    avg_orig_reward = np.mean(episode_rewards_orig[-log_interval:])
                    avg_masked_reward = np.mean(episode_rewards_masked[-log_interval:])
                    print(f"Episode: {i_episode}, Timestep: {time_step}/{total_timesteps}, Avg Orig Reward: {avg_orig_reward:.2f}, Avg Masked Reward: {avg_masked_reward:.2f}, Last Ep Len: {ep_len}")

                state, info = self.env.reset()
                current_ep_reward_orig, current_ep_reward_masked, ep_len = 0, 0, 0

            # --- Perform PPO Update ---
            if collected_steps >= update_interval:
                print(f"--- Timestep {time_step}: Updating mask network ({len(self.memory.states)} samples) ---")
                with torch.no_grad():
                    if not isinstance(state, np.ndarray): state = np.array(state)
                    final_state_tensor = torch.as_tensor(state, dtype=torch.float32).unsqueeze(0).to(self.device)
                    # Value is 0 if the *last stored transition* was terminal
                    is_last_step_done = self.memory.dones[-1].item() if self.memory.dones else False
                    last_value = self.value_net(final_state_tensor).squeeze(0) if not is_last_step_done else torch.zeros((1), device=self.device)


                self.ppo_trainer.update(self.memory, last_value) # Pass V(s_T)
                self.memory.clear()
                collected_steps = 0 # Reset counter
                self.mask_net_old.load_state_dict(self.mask_net.state_dict())
                self.mask_net_old.eval()

        print("--- StateMask training finished ---")
        self._close_env() # Close the env after training

        if save_path:
            self.save_model(save_path)


    def get_importance_scores(self, trajectory_states):
        """
        Uses the trained mask network to calculate importance scores for states in a trajectory.
        Importance score = P(a_m=0 | s_t), i.e., probability of *not* blinding.

        Args:
            trajectory_states: A list or array/tensor of states from a trajectory.

        Returns:
            A list of importance scores (probabilities) for each state.
        """
        self.mask_net.eval() # Set mask network to evaluation mode
        scores = []
        with torch.no_grad():
            for state in trajectory_states:
                 if not isinstance(state, np.ndarray): state = np.array(state)
                 state_tensor = torch.as_tensor(state, dtype=torch.float32).unsqueeze(0).to(self.device)
                 logits = self.mask_net(state_tensor)
                 prob_zero = torch.softmax(logits, dim=-1)[0, 0].item() # P(action=0)
                 scores.append(prob_zero)
        self.mask_net.train() # Set back to train mode
        return scores

    def save_model(self, filepath):
        """ Saves the trained mask network and optionally the value network weights. """
        try:
            torch.save(self.mask_net.state_dict(), filepath)
            print(f"Saved StateMask (mask network) model to {filepath}")
            # Optional: save value network separately or together in a dict
            # value_filepath = filepath.replace('\\''.pt'\\'', '\\''_value.pt'\\'') # Example naming
            # torch.save(self.value_net.state_dict(), value_filepath)
            # print(f"Saved StateMask (value network) model to {value_filepath}")
        except Exception as e:
            print(f"Error saving model to {filepath}: {e}")


    def load_model(self, filepath):
        """ Loads trained mask network weights and syncs the old network. """
        try:
            self.mask_net.load_state_dict(torch.load(filepath, map_location=self.device))
            self.mask_net_old.load_state_dict(self.mask_net.state_dict())
            self.mask_net.eval()
            self.mask_net_old.eval()
            print(f"Loaded StateMask model from {filepath}")
            # Optional: load value network if saved separately
            # value_filepath = filepath.replace('\\''.pt'\\'', '\\''_value.pt'\\'')
            # if os.path.exists(value_filepath):
            #    self.value_net.load_state_dict(torch.load(value_filepath, map_location=self.device))
            #    self.value_net.eval()
            #    print(f"Loaded StateMask (value network) model from {value_filepath}")

        except FileNotFoundError:
             print(f"Error: Model file not found at {filepath}")
        except Exception as e:
             print(f"Error loading StateMask model from {filepath}: {e}")
