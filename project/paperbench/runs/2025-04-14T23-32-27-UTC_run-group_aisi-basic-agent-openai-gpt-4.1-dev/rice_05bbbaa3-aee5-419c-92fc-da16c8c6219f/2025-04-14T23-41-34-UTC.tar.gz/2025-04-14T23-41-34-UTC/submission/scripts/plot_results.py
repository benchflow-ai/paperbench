import matplotlib.pyplot as plt
import numpy as np

def plot_sweep(x_vals, means, stds, xlabel, ylabel, title, out_file):
    plt.figure()
    means = np.array(means)
    stds = np.array(stds)
    x = np.array(x_vals)
    plt.errorbar(x, means, yerr=stds, fmt='-o')
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.savefig(out_file)
    plt.close()

# Example usage:
# plot_sweep([0,0.1,0.01,0.001], [..], [..], 'lambda', 'Final Reward', 'Lambda Sweep', 'lambda_sweep.png')
