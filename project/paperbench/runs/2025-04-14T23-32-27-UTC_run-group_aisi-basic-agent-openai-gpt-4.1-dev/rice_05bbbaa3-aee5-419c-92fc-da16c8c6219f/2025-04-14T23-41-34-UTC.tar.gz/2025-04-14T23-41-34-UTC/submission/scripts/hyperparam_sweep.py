"""
Sweep the two primary hyperparameters for RICE refinement:
- Figure 7: lambda \in {0, 0.1, 0.01, 0.001}
- Figure 8: p \in {0, 0.25, 0.5, 0.75, 1}
Collect and log final agent reward for each value.
"""
import numpy as np
from rice_refiner import run_rice_refining

def sweep_lambda(agent, env, mask_net, p=0.5, total_timesteps=10000):
    lambdas = [0, 0.1, 0.01, 0.001]
    perf = []
    for lmb in lambdas:
        refined = run_rice_refining(agent, env, mask_net, p=p, lambda_rnd=lmb, total_timesteps=total_timesteps)
        rewards = []
        for _ in range(5):
            obs, _ = env.reset()
            done = False
            ep_reward = 0
            while not done:
                action, _ = refined.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, _ = env.step(action)
                ep_reward += reward
                done = terminated or truncated
            rewards.append(ep_reward)
        perf.append((lmb, np.mean(rewards), np.std(rewards)))
    print('Lambda sweep results:', perf)
    return perf

def sweep_p(agent, env, mask_net, lambda_rnd=0.01, total_timesteps=10000):
    ps = [0, 0.25, 0.5, 0.75, 1]
    perf = []
    for pval in ps:
        refined = run_rice_refining(agent, env, mask_net, p=pval, lambda_rnd=lambda_rnd, total_timesteps=total_timesteps)
        rewards = []
        for _ in range(5):
            obs, _ = env.reset()
            done = False
            ep_reward = 0
            while not done:
                action, _ = refined.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, _ = env.step(action)
                ep_reward += reward
                done = terminated or truncated
            rewards.append(ep_reward)
        perf.append((pval, np.mean(rewards), np.std(rewards)))
    print('p sweep results:', perf)
    return perf
