
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv

def run_rice_refining(pretrained_agent, env, mask_net, p=0.5, lambda_rnd=0.01, total_timesteps=10000):
    """
    Implements the core of Algorithm 2 from RICE: mix initial, RND bonus, PPO finetune
    """
    # NOTE: Not a complete runner, but captures the major logic
    class MixedInitEnv(gym.Wrapper):
        def __init__(self, env, agent, mask_net, p):
            super().__init__(env)
            self.agent = agent
            self.mask_net = mask_net
            self.p = p
        def reset(self, **kwargs):
            if np.random.rand() < self.p:
                # Rollout (sample trajectory), pick critical state
                obs, _ = self.env.reset()
                traj = []
                done = False
                while not done:
                    action, _ = self.agent.predict(obs, deterministic=True)
                    next_obs, reward, terminated, truncated, info = self.env.step(action)
                    traj.append((obs, action, reward))
                    obs = next_obs
                    done = terminated or truncated
                import torch
                # Pick state with max importance from mask_net
                imps = [self.mask_net(torch.tensor(s, dtype=torch.float32).unsqueeze(0)).item() for s, _, _ in traj]
                state_idx = int(np.argmax(imps)) if imps else 0
                # Re-run rollout to init at that state
                obs, _ = self.env.reset()
                for i in range(state_idx):
                    action, _ = self.agent.predict(obs, deterministic=True)
                    obs, _, terminated, truncated, _ = self.env.step(action)
                    if terminated or truncated:
                        obs, _ = self.env.reset()
                        break
                return obs, {}
            else:
                return self.env.reset(**kwargs)

    # RND exploration wrapper (simplified intrinsic reward via random features)
    class RNDWrapper(gym.RewardWrapper):
        def __init__(self, env, lambda_rnd):
            super().__init__(env)
            self.lambda_rnd = lambda_rnd
            obs_space = env.observation_space.shape[0]
            self.target = torch.nn.Linear(obs_space, 32)
            self.predictor = torch.nn.Linear(obs_space, 32)
            self.optimizer = torch.optim.Adam(self.predictor.parameters(), lr=1e-3)
        def reward(self, reward):
            # obs needs to be manually available
            obs = self.observation(self.env.state) if hasattr(self.env, 'state') else None
            if obs is not None:
                obs_t = torch.tensor(obs, dtype=torch.float32)
                tgt = self.target(obs_t)
                pred = self.predictor(obs_t)
                intrinsic = ((tgt - pred)**2).mean().item()
                reward = reward + self.lambda_rnd * intrinsic
                # Predictor update
                self.optimizer.zero_grad()
                loss = ((tgt - pred)**2).mean()
                loss.backward()
                self.optimizer.step()
            return reward

    # Wrap env
    import numpy as np
    import gym
    env = MixedInitEnv(env, pretrained_agent, mask_net, p)
    env = RNDWrapper(env, lambda_rnd)
    vec_env = DummyVecEnv([lambda: env])
    agent = PPO('MlpPolicy', vec_env, verbose=1)
    agent.learn(total_timesteps=total_timesteps)
    return agent
