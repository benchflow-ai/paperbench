import torch

def compute_fidelity_score(env, agent, mask_net, l_frac=0.1, num_episodes=10):
    L = env.spec.max_episode_steps
    l = int(L * l_frac)
    d_total = 0
    d_max = 0
    for episode in range(num_episodes):
        state, _ = env.reset()
        trajectory = []
        reward_orig = 0
        done = False
        # Get original reward and states
        while not done:
            action, _ = agent.predict(state, deterministic=True)
            next_state, reward, terminated, truncated, info = env.step(action)
            trajectory.append((state, action, reward))
            reward_orig += reward
            state = next_state
            done = terminated or truncated
        # Get stepwise importance for whole traj
        importance = []
        for i, (s, _, _) in enumerate(trajectory):
            s_tensor = torch.tensor(s, dtype=torch.float32).unsqueeze(0)
            importance.append(mask_net(s_tensor).item())
        # Find top-l consecutive segment by avg importance
        scores = [sum(importance[i:i + l]) / l for i in range(L - l + 1)]
        if not scores:
            continue
        start_idx = scores.index(max(scores))
        # Fast-forward to start_idx, random actions in segment, then regular
        env.reset()
        state, _ = env.reset()
        reward_blind = 0
        for t in range(L):
            if t < start_idx:
                action, _ = agent.predict(state)
            elif t < start_idx + l:
                action = env.action_space.sample()
            else:
                action, _ = agent.predict(state)
            state, reward, terminated, truncated, info = env.step(action)
            reward_blind += reward
            if terminated or truncated:
                break
        d_ep = abs(reward_orig - reward_blind)
        d_total += d_ep
        d_max = max(d_max, abs(reward_orig)) # Use max orig reward as proxy for max possible change
    eps = 1e-8
    d_mean = d_total / num_episodes
    fidelity = (torch.log(torch.tensor(d_mean / (d_max + eps))) - torch.log(torch.tensor(l / L))).item()
    return fidelity
