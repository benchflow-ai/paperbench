
import torch
import torch.optim as optim
from mask_network import MaskNetwork

def train_mask_network(target_policy, env, state_dim, alpha=0.01, epochs=10, batch_size=64):
    mask_net = MaskNetwork(state_dim)
    optimizer = optim.Adam(mask_net.parameters(), lr=1e-3)
    for epoch in range(epochs):
        state, _ = env.reset()
        done = False
        total_loss = 0
        while not done:
            state_tensor = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
            mask_prob = mask_net(state_tensor)
            mask_action = (mask_prob > 0.5).float()  # Bernoulli sampling can be used for stochasticity
            # Get target policy's action
            with torch.no_grad():
                action, _ = target_policy.predict(state, deterministic=True)
            # If masked, replace action with random
            if mask_action.item() == 1:
                action = env.action_space.sample()
            # Step in env
            next_state, reward, terminated, truncated, info = env.step(action)
            # Reward shaping: add alpha bonus when mask/blind is used
            reward_prime = reward + alpha * mask_action.item()
            # Optimize mask net: maximize reward (minimize -reward_prime)
            loss = -torch.tensor([reward_prime], requires_grad=True)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            state = next_state
            done = terminated or truncated
            total_loss += loss.item()
        print(f"Epoch {epoch}, Total loss: {total_loss}")
    return mask_net
