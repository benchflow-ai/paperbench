import torch
import torch.nn as nn
import torch.nn.functional as F

class MaskNetwork(nn.Module):
    """
    Mask network to generate importance/blinding for each state.
    Output: probability of 'blind' (1) or not (0).
    """
    def __init__(self, state_dim, hidden_sizes=[128, 128], output_dim=1):
        super().__init__()
        layers = []
        layer_sizes = [state_dim] + hidden_sizes
        for i in range(len(layer_sizes) - 1):
            layers.append(nn.Linear(layer_sizes[i], layer_sizes[i+1]))
            layers.append(nn.ReLU())
        layers.append(nn.Linear(hidden_sizes[-1], output_dim))
        self.network = nn.Sequential(*layers)

    def forward(self, state):
        x = self.network(state)
        prob = torch.sigmoid(x)
        # Output is probability of mask '1' (blind)
        return prob
