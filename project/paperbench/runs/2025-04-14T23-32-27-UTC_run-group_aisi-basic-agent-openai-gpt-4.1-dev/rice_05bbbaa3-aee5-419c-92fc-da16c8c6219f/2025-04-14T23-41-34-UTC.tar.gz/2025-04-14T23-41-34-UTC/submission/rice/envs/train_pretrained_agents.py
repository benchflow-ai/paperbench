import gym
from stable_baselines3 import PPO

def make_env_and_agent(env_id, policy='MlpPolicy', total_timesteps=10000):
    env = gym.make(env_id)
    agent = PPO(policy, env, verbose=1)
    agent.learn(total_timesteps=total_timesteps)
    return env, agent

env_list = ['Hopper-v4', 'Walker2d-v4', 'Reacher-v4', 'HalfCheetah-v4']

if __name__ == '__main__':
    for env_id in env_list:
        try:
            print('Training:', env_id)
            env, agent = make_env_and_agent(env_id)
            agent.save(f'pretrained_{env_id}')
            env.close()
        except Exception as e:
            print('Failed:', env_id, e)
