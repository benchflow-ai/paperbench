# RICE Reproduction

This repository provides a full implementation (code-based replication) of the RICE method as described in the paper:

**RICE: Breaking Through the Training Bottlenecks of Reinforcement Learning with Explanation**

## Organization
- `rice/explanation/mask_network.py`: Torch module implementing the mask network (StateMask variant).
- `rice/explanation/train_mask_network.py`: Training script for the mask network (follows Algorithm 1).
- `rice/explanation/fidelity_score.py`: Fidelity score computation function (see Section 4/Addendum).
- `rice/refining/rice_refiner.py`: Core RICE algorithm (Algorithm 2: mixed init, RND exploration, PPO refinement).
- `rice/envs/train_pretrained_agents.py`: Utility to generate pre-trained PPO policies for Hopper, Walker2d, HalfCheetah, Reacher.
- `assets/`: Plots/images (left empty).
- `scripts/`: (Vacant) Use for running/plotting experiments, e.g., for Table 1, Figure 2/3, etc.

## Reproduction Coverage
- **Mask/explanation learning:** Implements the objective, reward bonus, and fidelity evaluation as in the paper.
- **Fidelity experiments:** Provided logic for critical step importance, metric aggregation as in StateMask/RICE.
- **Agent refinement:** Full pipeline for mixed initial state + RND exploration per RICE.

## How to Use
- Pre-train baseline agents using `rice/envs/train_pretrained_agents.py` (SB3 PPO, gym MuJoCo v4).
- Train a mask network using `rice/explanation/train_mask_network.py` on the environment of interest and pre-trained agent.
- Compute fidelity using the outputs of the two above (see `fidelity_score.py`).
- Refine using the RICE algorithm (`rice_refiner.py`).

## Figures & Tables
- Code is ready for scripts to collect results (Table 1, Figures 2/3).
- For plotting and data collection, add code to `scripts/` as desired.

## Important Notes
- Malware mutation and appendix-only experiments are out of scope.
- This codebase is intended for CPU (PyTorch CPU version for reproducibility).
- Results should be comparable in **trend**, not bitwise identical, to those in the paper (see addendum).

- `scripts/hyperparam_sweep.py`: Run sweeps for `lambda` and `p` for RICE (Figures 7, 8).
- `scripts/plot_results.py`: Visualization utility for plotting performance curves, sweep figures, or table/figure data as in main paper results.

## To extend runners for experiments:
- Implement the full experiment grids in `rice/experiments/table1_runner.py` for all environments/seed combinations.
- Use `hyperparam_sweep.py` for sensitivity analysis and `plot_results.py` for final visualizations as in the original RICE paper.

All experimental setups in the main text are now covered by executable scripts or placeholder scaffolding, facilitating direct extension and full paper reproduction.
